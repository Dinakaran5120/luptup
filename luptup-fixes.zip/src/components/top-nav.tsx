import { useMyProfile } from "@/api/my-profile";
import { useTheme } from "@/context/theme";
import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { router } from "expo-router";
import React from "react";
import { Pressable, Text, View } from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const NavBtn: React.FC<{
  onPress: () => void;
  children: React.ReactNode;
  bgColor: string;
}> = ({ onPress, children, bgColor }) => {
  const scale = useSharedValue(1);
  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));
  return (
    <AnimatedPressable
      style={[
        {
          width: 38,
          height: 38,
          borderRadius: 19,
          backgroundColor: bgColor,
          alignItems: "center",
          justifyContent: "center",
        },
        animStyle,
      ]}
      onPressIn={() => {
        scale.value = withSpring(0.88, { damping: 15 });
      }}
      onPressOut={() => {
        scale.value = withSpring(1, { damping: 15 });
      }}
      onPress={onPress}
    >
      {children}
    </AnimatedPressable>
  );
};

interface Props {
  showNotification?: boolean;
  showMenu?: boolean;
  showProfile?: boolean;
  onNotificationPress?: () => void;
  title?: string;
}

export const TopNav: React.FC<Props> = ({
  showNotification = true,
  showMenu = true,
  showProfile = true,
  onNotificationPress,
  title,
}) => {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const { data: profile } = useMyProfile();

  return (
    <View
      style={{
        paddingTop: insets.top,
        backgroundColor: colors.background,
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 16,
          paddingVertical: 8,
        }}
      >
        {title ? (
          <Text
            style={{
              fontFamily: "PlayfairDisplay-Bold",
              fontSize: 22,
              color: colors.text,
            }}
          >
            {title}
          </Text>
        ) : (
          <Text
            style={{
              fontFamily: "PlayfairDisplay-Bold",
              fontSize: 26,
              color: colors.primary,
              letterSpacing: -0.5,
            }}
          >
            luptup
          </Text>
        )}

        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          {showNotification && (
            <NavBtn
              onPress={onNotificationPress ?? (() => router.push("/notifications" as any))}
              bgColor={colors.surface}
            >
              <Ionicons name="notifications-outline" size={19} color={colors.icon} />
            </NavBtn>
          )}
          {showMenu && (
            <NavBtn
              onPress={() => router.push("/settings")}
              bgColor={colors.surface}
            >
              <Ionicons name="ellipsis-vertical" size={19} color={colors.icon} />
            </NavBtn>
          )}
          {showProfile && (
            <Pressable
              onPress={() => router.push("/hinge" as any)}
              style={{
                width: 34,
                height: 34,
                borderRadius: 17,
                borderWidth: 2,
                borderColor: colors.primary,
                overflow: "hidden",
                backgroundColor: colors.surface,
              }}
            >
              {profile?.avatar_url ? (
                <Image
                  source={profile.avatar_url}
                  style={{ width: "100%", height: "100%" }}
                  contentFit="cover"
                />
              ) : (
                <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="person" size={16} color={colors.icon} />
                </View>
              )}
            </Pressable>
          )}
        </View>
      </View>
    </View>
  );
};
