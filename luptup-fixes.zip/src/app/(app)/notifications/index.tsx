import { BRAND, useTheme } from "@/context/theme";
import { MOCK_NOTIFICATIONS, MockNotification, NotifType } from "@/lib/mock-data";
import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { formatDistanceToNow } from "date-fns";
import { router } from "expo-router";
import { useState } from "react";
import {
  FlatList,
  Pressable,
  StatusBar,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const NOTIF_META: Record<NotifType, { icon: string; color: string; bg: string }> = {
  profile_like: { icon: "heart",      color: BRAND.primary,  bg: BRAND.primary + "28" },
  post_like:    { icon: "heart",      color: "#ef4444",      bg: "#ef444428" },
  comment:      { icon: "chatbubble", color: "#3b82f6",      bg: "#3b82f628" },
  message:      { icon: "mail",       color: "#10b981",      bg: "#10b98128" },
};

function NotifRow({ notif }: { notif: MockNotification }) {
  const { colors } = useTheme();
  const meta = NOTIF_META[notif.type];

  return (
    <Pressable
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 14,
        paddingHorizontal: 20,
        paddingVertical: 13,
        backgroundColor: notif.read ? "transparent" : colors.primary + "08",
      }}
    >
      {/* Avatar with badge overlaid */}
      <View style={{ width: 52, height: 52 }}>
        <Image
          source={notif.user_avatar}
          style={{ width: 52, height: 52, borderRadius: 26, backgroundColor: colors.surface }}
        />
        <View
          style={{
            position: "absolute",
            bottom: -2,
            right: -2,
            width: 22,
            height: 22,
            borderRadius: 11,
            backgroundColor: meta.bg,
            borderWidth: 2,
            borderColor: colors.background,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Ionicons name={meta.icon as any} size={10} color={meta.color} />
        </View>
      </View>

      {/* Text content */}
      <View style={{ flex: 1, gap: 2 }}>
        <Text
          style={{
            fontFamily: "Poppins-Regular",
            fontSize: 14,
            color: colors.text,
            lineHeight: 20,
          }}
        >
          <Text style={{ fontFamily: "Poppins-SemiBold" }}>{notif.user_name}</Text>
          {"  "}{notif.preview}
        </Text>
        <Text
          style={{
            fontFamily: "Poppins-Light",
            fontSize: 12,
            color: colors.textMuted,
          }}
        >
          {formatDistanceToNow(new Date(notif.created_at), { addSuffix: true })}
        </Text>
      </View>

      {/* Unread dot */}
      {!notif.read ? (
        <View
          style={{
            width: 9,
            height: 9,
            borderRadius: 5,
            backgroundColor: BRAND.primary,
          }}
        />
      ) : (
        <View style={{ width: 9 }} />
      )}
    </Pressable>
  );
}

function SectionHeader({ label }: { label: string }) {
  const { colors } = useTheme();
  return (
    <View style={{ paddingHorizontal: 20, paddingTop: 16, paddingBottom: 6 }}>
      <Text
        style={{
          fontFamily: "Poppins-SemiBold",
          fontSize: 12,
          color: colors.textMuted,
          textTransform: "uppercase",
          letterSpacing: 0.8,
        }}
      >
        {label}
      </Text>
    </View>
  );
}

export default function NotificationsPage() {
  const { colors, isDark } = useTheme();
  const { top } = useSafeAreaInsets();
  const [notifications, setNotifications] = useState<MockNotification[]>(MOCK_NOTIFICATIONS);

  const unread = notifications.filter((n) => !n.read);
  const read = notifications.filter((n) => n.read);

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const unreadCount = unread.length;

  const sections = [
    ...(unread.length > 0
      ? [
          { type: "header" as const, label: "New" },
          ...unread.map((n) => ({ type: "item" as const, data: n })),
        ]
      : []),
    ...(read.length > 0
      ? [
          { type: "header" as const, label: "Earlier" },
          ...read.map((n) => ({ type: "item" as const, data: n })),
        ]
      : []),
  ];

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      {/* Header */}
      <View
        style={{
          paddingTop: top,
          backgroundColor: colors.background,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            paddingHorizontal: 16,
            paddingVertical: 12,
          }}
        >
          <Pressable
            onPress={() => router.back()}
            style={{
              width: 36,
              height: 36,
              borderRadius: 18,
              backgroundColor: colors.surface,
              alignItems: "center",
              justifyContent: "center",
              marginRight: 10,
            }}
          >
            <Ionicons name="arrow-back" size={20} color={colors.icon} />
          </Pressable>

          <Text
            style={{
              flex: 1,
              fontFamily: "PlayfairDisplay-Bold",
              fontSize: 22,
              color: colors.text,
            }}
          >
            Notifications
            {unreadCount > 0 && (
              <Text
                style={{
                  fontFamily: "Poppins-Regular",
                  fontSize: 16,
                  color: BRAND.primary,
                }}
              >
                {"  "}({unreadCount})
              </Text>
            )}
          </Text>

          {unreadCount > 0 && (
            <Pressable
              onPress={markAllRead}
              style={{
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 16,
                backgroundColor: BRAND.primary + "14",
              }}
            >
              <Text
                style={{
                  fontFamily: "Poppins-SemiBold",
                  fontSize: 12,
                  color: BRAND.primary,
                }}
              >
                Mark all read
              </Text>
            </Pressable>
          )}
        </View>
      </View>

      <FlatList
        data={sections}
        keyExtractor={(_, i) => i.toString()}
        renderItem={({ item }) => {
          if (item.type === "header") return <SectionHeader label={item.label} />;
          return <NotifRow notif={item.data} />;
        }}
        ItemSeparatorComponent={() => (
          <View
            style={{
              height: 1,
              backgroundColor: colors.border,
              marginLeft: 86,
            }}
          />
        )}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 100 }}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingTop: 80, gap: 12 }}>
            <Text style={{ fontSize: 48 }}>🔔</Text>
            <Text
              style={{
                fontFamily: "Poppins-SemiBold",
                fontSize: 18,
                color: colors.text,
              }}
            >
              All caught up!
            </Text>
            <Text
              style={{
                fontFamily: "Poppins-Light",
                fontSize: 14,
                color: colors.textMuted,
              }}
            >
              No new notifications
            </Text>
          </View>
        }
      />
    </View>
  );
}
