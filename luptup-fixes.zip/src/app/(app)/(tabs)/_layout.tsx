import { useMyProfile } from "@/api/my-profile";
import { BRAND, useTheme } from "@/context/theme";
import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { Tabs } from "expo-router";
import { View } from "react-native";
import Svg, { Defs, LinearGradient, Stop, Rect } from "react-native-svg";

const DOT = (color: string) => (
  <View style={{ width: 4, height: 4, borderRadius: 2, backgroundColor: color, marginTop: 2 }} />
);

const TAB_H = 64;

export default function Layout() {
  const { data: profile } = useMyProfile();
  const { colors } = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: {
          backgroundColor: colors.tabBar,
          borderTopColor: colors.tabBarBorder,
          borderTopWidth: 1,
          height: TAB_H,
          paddingBottom: 8,
          paddingTop: 6,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.06,
          shadowRadius: 8,
          elevation: 8,
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.iconMuted,
      }}
    >
      {/* Home */}
      <Tabs.Screen
        name="index"
        options={{
          tabBarIcon: ({ color, focused }) => (
            <View style={{ alignItems: "center" }}>
              <Ionicons name={focused ? "home" : "home-outline"} size={24} color={color} />
              {focused && DOT(colors.primary)}
            </View>
          ),
        }}
      />

      {/* Messages */}
      <Tabs.Screen
        name="matches"
        options={{
          tabBarIcon: ({ color, focused }) => (
            <View style={{ alignItems: "center" }}>
              <Ionicons name={focused ? "chatbubbles" : "chatbubbles-outline"} size={24} color={color} />
              {focused && DOT(colors.primary)}
            </View>
          ),
        }}
      />

      {/* Post — gradient plus button (center) */}
      <Tabs.Screen
        name="post"
        options={{
          tabBarIcon: () => (
            <View
              style={{
                width: 50,
                height: 50,
                borderRadius: 25,
                overflow: "hidden",
                marginBottom: 6,
                shadowColor: BRAND.primary,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.4,
                shadowRadius: 8,
                elevation: 8,
              }}
            >
              <Svg width={50} height={50}>
                <Defs>
                  <LinearGradient id="plusGrad" x1="0" y1="0" x2="1" y2="1">
                    <Stop offset="0%" stopColor={BRAND.primary} />
                    <Stop offset="100%" stopColor={BRAND.secondary} />
                  </LinearGradient>
                </Defs>
                <Rect width={50} height={50} fill="url(#plusGrad)" rx={25} />
              </Svg>
              <View style={{ position: "absolute", inset: 0, alignItems: "center", justifyContent: "center" }}>
                <Ionicons name="add" size={28} color="#fff" />
              </View>
            </View>
          ),
        }}
      />

      {/* Explore (was likes) */}
      <Tabs.Screen
        name="likes"
        options={{
          tabBarIcon: ({ color, focused }) => (
            <View style={{ alignItems: "center" }}>
              <Ionicons name={focused ? "compass" : "compass-outline"} size={26} color={color} />
              {focused && DOT(colors.primary)}
            </View>
          ),
        }}
      />

      {/* Community */}
      <Tabs.Screen
        name="community"
        options={{
          tabBarIcon: ({ color, focused }) => (
            <View style={{ alignItems: "center" }}>
              <Ionicons name={focused ? "people" : "people-outline"} size={24} color={color} />
              {focused && DOT(colors.primary)}
            </View>
          ),
        }}
      />

      {/* Account tab — hidden from bar, still registered for routing */}
      <Tabs.Screen
        name="hinge"
        options={{
          href: null,
        }}
      />
    </Tabs>
  );
}
