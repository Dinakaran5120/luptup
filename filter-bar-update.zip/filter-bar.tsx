import { BRAND, useTheme } from "@/context/theme";
import { Ionicons } from "@expo/vector-icons";
import { Slider } from "@miblanchard/react-native-slider";
import React, { useEffect, useState } from "react";
import {
  Modal,
  ScrollView,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

// ─── State types ──────────────────────────────────────────────────────────────

interface FilterState {
  online: boolean;
  minAge: number;
  maxAge: number;
  orientation: string;
  lookingFor: string;
  distance: number;
}

type FilterKey = "filters" | "minAge" | "online" | "orientation" | "lookingFor" | "distance";

const DEFAULT: FilterState = {
  online: false,
  minAge: 18,
  maxAge: 30,
  orientation: "All Orientations",
  lookingFor: "All",
  distance: 50,
};

// ─── Options ──────────────────────────────────────────────────────────────────

const ORIENTATION_OPTIONS = [
  { value: "All Orientations", icon: "earth-outline" },
  { value: "Straight",         icon: "male-female-outline" },
  { value: "Gay",              icon: "male-outline" },
  { value: "Lesbian",          icon: "female-outline" },
  { value: "Bisexual",         icon: "git-branch-outline" },
  { value: "Pansexual",        icon: "infinite-outline" },
  { value: "Asexual",          icon: "remove-circle-outline" },
  { value: "Other",            icon: "ellipsis-horizontal-circle-outline" },
];

const LOOKING_FOR_OPTIONS = [
  { value: "All",           icon: "heart-outline" },
  { value: "Relationship",  icon: "rose-outline" },
  { value: "Casual Dating", icon: "cafe-outline" },
  { value: "Friendship",    icon: "people-outline" },
  { value: "Not Sure Yet",  icon: "help-circle-outline" },
];

// ─── Pill component ───────────────────────────────────────────────────────────

const Pill: React.FC<{
  label: string;
  active: boolean;       // filter has a non-default value
  isOpen: boolean;       // this pill's sheet is currently open
  hasDropdown?: boolean;
  leftIcon?: string;
  greenDot?: boolean;
  onPress: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
}> = ({ label, active, isOpen, hasDropdown = true, leftIcon, greenDot, onPress, colors }) => {
  // open → highlighted border; active → filled background; default → plain
  const bg    = active ? BRAND.primary : isOpen ? colors.surfaceAlt : colors.surface;
  const bc    = active ? BRAND.primary : isOpen ? BRAND.primary       : colors.border;
  const tCol  = active ? "#fff"        : isOpen ? BRAND.primary       : colors.textMuted;

  return (
    <TouchableOpacity
      activeOpacity={0.75}
      onPress={onPress}
      style={{
        paddingHorizontal: 12,
        paddingVertical: 7,
        borderRadius: 20,
        backgroundColor: bg,
        borderWidth: isOpen && !active ? 1.5 : 1,
        borderColor: bc,
        flexDirection: "row",
        alignItems: "center",
        gap: 5,
      }}
    >
      {leftIcon && <Ionicons name={leftIcon as any} size={14} color={tCol} />}
      {greenDot && (
        <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: active ? "#fff" : "#22c55e" }} />
      )}
      <Text style={{ fontFamily: "Poppins-Medium", fontSize: 13, color: tCol }}>
        {label}
      </Text>
      {hasDropdown && (
        <Ionicons name={isOpen ? "chevron-up" : "chevron-down"} size={11} color={tCol} />
      )}
    </TouchableOpacity>
  );
};

// ─── Single select row inside a sheet ────────────────────────────────────────

const SelectRow: React.FC<{
  icon: string;
  label: string;
  selected: boolean;
  onPress: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
}> = ({ icon, label, selected, onPress, colors }) => (
  <TouchableOpacity
    activeOpacity={0.7}
    onPress={onPress}
    style={{
      flexDirection: "row",
      alignItems: "center",
      gap: 14,
      paddingHorizontal: 20,
      paddingVertical: 14,
      borderRadius: 14,
      backgroundColor: selected ? BRAND.primary + "15" : colors.surface,
      borderWidth: 1.5,
      borderColor: selected ? BRAND.primary : colors.border,
      marginBottom: 8,
    }}
  >
    <View style={{
      width: 38,
      height: 38,
      borderRadius: 12,
      backgroundColor: selected ? BRAND.primary + "22" : colors.background,
      alignItems: "center",
      justifyContent: "center",
      borderWidth: 1,
      borderColor: selected ? BRAND.primary + "44" : colors.border,
    }}>
      <Ionicons name={icon as any} size={18} color={selected ? BRAND.primary : colors.textMuted} />
    </View>
    <Text style={{ flex: 1, fontFamily: "Poppins-Medium", fontSize: 14, color: selected ? BRAND.primary : colors.text }}>
      {label}
    </Text>
    {selected && <Ionicons name="checkmark-circle" size={22} color={BRAND.primary} />}
  </TouchableOpacity>
);

// ─── Bottom sheet ─────────────────────────────────────────────────────────────

const FilterSheet: React.FC<{
  visible: boolean;
  activeKey: FilterKey | null;
  filters: FilterState;
  onClose: () => void;
  onApply: (patch: Partial<FilterState>) => void;
}> = ({ visible, activeKey, filters, onClose, onApply }) => {
  const { colors } = useTheme();
  const [local, setLocal] = useState<FilterState>(filters);

  useEffect(() => { if (visible) setLocal(filters); }, [visible]);

  const handleApply = () => { onApply(local); onClose(); };
  const handleReset = () => { setLocal(DEFAULT); };

  const sliderTrack = {
    minimumTrackTintColor: BRAND.primary,
    maximumTrackTintColor: colors.border,
    thumbTintColor: BRAND.primary,
  };

  const renderBody = () => {
    switch (activeKey) {

      // ── "Filters" pill → comprehensive sheet ──
      case "filters":
        return (
          <View style={{ paddingHorizontal: 20, paddingBottom: 8, gap: 20 }}>
            <Text style={{ fontFamily: "Poppins-Bold", fontSize: 18, color: colors.text }}>All Filters</Text>

            {/* Age range */}
            <View style={{ gap: 10 }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: colors.text }}>Age Range</Text>
                <View style={{ backgroundColor: BRAND.primary + "18", paddingHorizontal: 12, paddingVertical: 5, borderRadius: 16, borderWidth: 1, borderColor: BRAND.primary + "44" }}>
                  <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: BRAND.primary }}>
                    {local.minAge} – {local.maxAge} yrs
                  </Text>
                </View>
              </View>
              <Slider
                value={[local.minAge, local.maxAge]}
                minimumValue={18} maximumValue={60} step={1}
                onValueChange={(v: number[]) => setLocal({ ...local, minAge: v[0], maxAge: v[1] ?? v[0] })}
                {...sliderTrack}
              />
              <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                <Text style={{ fontFamily: "Poppins-Light", fontSize: 11, color: colors.textMuted }}>18 yrs</Text>
                <Text style={{ fontFamily: "Poppins-Light", fontSize: 11, color: colors.textMuted }}>60 yrs</Text>
              </View>
            </View>

            {/* Distance */}
            <View style={{ gap: 10 }}>
              <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: colors.text }}>Distance</Text>
                <View style={{ backgroundColor: BRAND.primary + "18", paddingHorizontal: 12, paddingVertical: 5, borderRadius: 16, borderWidth: 1, borderColor: BRAND.primary + "44" }}>
                  <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: BRAND.primary }}>
                    {local.distance} km
                  </Text>
                </View>
              </View>
              <Slider
                value={local.distance}
                minimumValue={1} maximumValue={200} step={1}
                onValueChange={(v: number[]) => setLocal({ ...local, distance: v[0] })}
                {...sliderTrack}
              />
              <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
                <Text style={{ fontFamily: "Poppins-Light", fontSize: 11, color: colors.textMuted }}>1 km</Text>
                <Text style={{ fontFamily: "Poppins-Light", fontSize: 11, color: colors.textMuted }}>200 km</Text>
              </View>
            </View>

            {/* Online only */}
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 16, borderRadius: 14, backgroundColor: colors.surface, borderWidth: 1, borderColor: local.online ? BRAND.primary : colors.border }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: "#22c55e" }} />
                <View>
                  <Text style={{ fontFamily: "Poppins-Medium", fontSize: 14, color: colors.text }}>Online only</Text>
                  <Text style={{ fontFamily: "Poppins-Light", fontSize: 11, color: colors.textMuted }}>Show active users</Text>
                </View>
              </View>
              <Switch value={local.online} onValueChange={(v) => setLocal({ ...local, online: v })}
                trackColor={{ false: colors.border, true: BRAND.primary }} thumbColor="#fff" />
            </View>
          </View>
        );

      // ── Age pill ──
      case "minAge":
        return (
          <View style={{ paddingHorizontal: 20, paddingBottom: 8, gap: 16 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <Text style={{ fontFamily: "Poppins-Bold", fontSize: 18, color: colors.text }}>Age Range</Text>
              <View style={{ backgroundColor: BRAND.primary + "18", paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: BRAND.primary + "44" }}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: BRAND.primary }}>
                  {local.minAge} – {local.maxAge} yrs
                </Text>
              </View>
            </View>
            <Slider
              value={[local.minAge, local.maxAge]}
              minimumValue={18} maximumValue={60} step={1}
              onValueChange={(v: number[]) => setLocal({ ...local, minAge: v[0], maxAge: v[1] ?? v[0] })}
              {...sliderTrack}
            />
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>18 yrs (min)</Text>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>60 yrs (max)</Text>
            </View>

            {/* Quick presets */}
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: colors.textMuted, marginTop: 4 }}>Quick Presets</Text>
            <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
              {[{ label: "18–25", min: 18, max: 25 }, { label: "25–35", min: 25, max: 35 }, { label: "30–45", min: 30, max: 45 }, { label: "40–60", min: 40, max: 60 }].map((p) => {
                const sel = local.minAge === p.min && local.maxAge === p.max;
                return (
                  <TouchableOpacity
                    key={p.label} activeOpacity={0.7}
                    onPress={() => setLocal({ ...local, minAge: p.min, maxAge: p.max })}
                    style={{ paddingHorizontal: 14, paddingVertical: 7, borderRadius: 16, backgroundColor: sel ? BRAND.primary : colors.surface, borderWidth: 1.5, borderColor: sel ? BRAND.primary : colors.border }}
                  >
                    <Text style={{ fontFamily: "Poppins-Medium", fontSize: 13, color: sel ? "#fff" : colors.text }}>{p.label}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
        );

      // ── Online pill ──
      case "online":
        return (
          <View style={{ paddingHorizontal: 20, paddingBottom: 8, gap: 16 }}>
            <Text style={{ fontFamily: "Poppins-Bold", fontSize: 18, color: colors.text }}>Online Status</Text>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => setLocal({ ...local, online: !local.online })}
              style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 18, borderRadius: 16, backgroundColor: local.online ? BRAND.primary + "12" : colors.surface, borderWidth: 1.5, borderColor: local.online ? BRAND.primary : colors.border }}
            >
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12 }}>
                <View style={{ width: 44, height: 44, borderRadius: 13, backgroundColor: local.online ? BRAND.primary + "22" : colors.background, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: local.online ? BRAND.primary + "55" : colors.border }}>
                  <View style={{ width: 14, height: 14, borderRadius: 7, backgroundColor: local.online ? "#22c55e" : colors.border }} />
                </View>
                <View>
                  <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: local.online ? BRAND.primary : colors.text }}>Show online users only</Text>
                  <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>Filter by active status</Text>
                </View>
              </View>
              <Switch value={local.online} onValueChange={(v) => setLocal({ ...local, online: v })}
                trackColor={{ false: colors.border, true: BRAND.primary }} thumbColor="#fff" />
            </TouchableOpacity>
          </View>
        );

      // ── Orientation pill ──
      case "orientation":
        return (
          <View style={{ paddingHorizontal: 20, paddingBottom: 8, gap: 12 }}>
            <Text style={{ fontFamily: "Poppins-Bold", fontSize: 18, color: colors.text }}>Sexual Orientation</Text>
            <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: colors.textMuted, marginTop: -4 }}>
              Show profiles matching this orientation
            </Text>
            {ORIENTATION_OPTIONS.map((opt) => (
              <SelectRow
                key={opt.value}
                icon={opt.icon}
                label={opt.value}
                selected={local.orientation === opt.value}
                onPress={() => setLocal({ ...local, orientation: opt.value })}
                colors={colors}
              />
            ))}
          </View>
        );

      // ── Looking For pill ──
      case "lookingFor":
        return (
          <View style={{ paddingHorizontal: 20, paddingBottom: 8, gap: 12 }}>
            <Text style={{ fontFamily: "Poppins-Bold", fontSize: 18, color: colors.text }}>Looking For</Text>
            <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: colors.textMuted, marginTop: -4 }}>
              What type of connection are you seeking?
            </Text>
            {LOOKING_FOR_OPTIONS.map((opt) => (
              <SelectRow
                key={opt.value}
                icon={opt.icon}
                label={opt.value}
                selected={local.lookingFor === opt.value}
                onPress={() => setLocal({ ...local, lookingFor: opt.value })}
                colors={colors}
              />
            ))}
          </View>
        );

      // ── Distance pill ──
      case "distance":
        return (
          <View style={{ paddingHorizontal: 20, paddingBottom: 8, gap: 16 }}>
            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
              <Text style={{ fontFamily: "Poppins-Bold", fontSize: 18, color: colors.text }}>Distance</Text>
              <View style={{ backgroundColor: BRAND.primary + "18", paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, borderWidth: 1, borderColor: BRAND.primary + "44" }}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: BRAND.primary }}>
                  {local.distance} km
                </Text>
              </View>
            </View>
            <Slider
              value={local.distance}
              minimumValue={1} maximumValue={200} step={1}
              onValueChange={(v: number[]) => setLocal({ ...local, distance: v[0] })}
              {...sliderTrack}
            />
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>1 km</Text>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>200 km</Text>
            </View>
          </View>
        );

      default:
        return null;
    }
  };

  return (
    <Modal visible={visible} transparent animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      {/* Backdrop */}
      <TouchableOpacity
        activeOpacity={1}
        style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.52)", justifyContent: "flex-end" }}
        onPress={onClose}
      >
        {/* Sheet */}
        <TouchableOpacity
          activeOpacity={1}
          style={{
            backgroundColor: colors.background,
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            maxHeight: "85%",
          }}
        >
          {/* Handle */}
          <View style={{ alignItems: "center", paddingTop: 14, paddingBottom: 10 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border }} />
          </View>

          {/* Scrollable body */}
          <ScrollView showsVerticalScrollIndicator={false} bounces={false}>
            {renderBody()}
            <View style={{ height: 16 }} />
          </ScrollView>

          {/* Footer: Reset + Apply */}
          <View style={{
            flexDirection: "row",
            gap: 12,
            paddingHorizontal: 20,
            paddingVertical: 16,
            borderTopWidth: 1,
            borderTopColor: colors.border,
          }}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={handleReset}
              style={{
                flex: 1,
                height: 50,
                borderRadius: 25,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: colors.surface,
                borderWidth: 1.5,
                borderColor: colors.border,
              }}
            >
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: colors.textMuted }}>Reset</Text>
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.85}
              onPress={handleApply}
              style={{
                flex: 2,
                height: 50,
                borderRadius: 25,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: BRAND.primary,
                shadowColor: BRAND.primary,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.35,
                shadowRadius: 10,
                elevation: 6,
              }}
            >
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: "#fff" }}>Apply Filter</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
};

// ─── FilterBar ────────────────────────────────────────────────────────────────

export const FilterBar: React.FC = () => {
  const { colors } = useTheme();
  const [openKey, setOpenKey] = useState<FilterKey | null>(null);
  const [filters, setFilters] = useState<FilterState>(DEFAULT);

  const toggle = (key: FilterKey) => setOpenKey((prev) => (prev === key ? null : key));

  // Active = any non-default value set
  const anyFilterActive =
    filters.online ||
    filters.minAge !== DEFAULT.minAge ||
    filters.maxAge !== DEFAULT.maxAge ||
    filters.orientation !== DEFAULT.orientation ||
    filters.lookingFor !== DEFAULT.lookingFor ||
    filters.distance !== DEFAULT.distance;

  const ageActive      = filters.minAge !== DEFAULT.minAge || filters.maxAge !== DEFAULT.maxAge;
  const oriActive      = filters.orientation !== DEFAULT.orientation;
  const lookingActive  = filters.lookingFor !== DEFAULT.lookingFor;
  const onlineActive   = filters.online;

  const ageLabel     = `Age ${filters.minAge}–${filters.maxAge}`;
  const oriLabel     = oriActive ? filters.orientation : "All Orientations";
  const lookingLabel = lookingActive ? filters.lookingFor : "Looking For";

  return (
    <>
      <View style={{
        flexDirection: "row",
        alignItems: "center",
        paddingVertical: 9,
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
      }}>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 12, gap: 8, flexDirection: "row", alignItems: "center" }}
        >
          {/* ≡ Filters */}
          <Pill
            label="Filters"
            active={anyFilterActive}
            isOpen={openKey === "filters"}
            hasDropdown={false}
            leftIcon="options-outline"
            onPress={() => toggle("filters")}
            colors={colors}
          />

          {/* Age */}
          <Pill
            label={ageLabel}
            active={ageActive}
            isOpen={openKey === "minAge"}
            onPress={() => toggle("minAge")}
            colors={colors}
          />

          {/* Orientation */}
          <Pill
            label={oriLabel}
            active={oriActive}
            isOpen={openKey === "orientation"}
            onPress={() => toggle("orientation")}
            colors={colors}
          />

          {/* Looking For */}
          <Pill
            label={lookingLabel}
            active={lookingActive}
            isOpen={openKey === "lookingFor"}
            onPress={() => toggle("lookingFor")}
            colors={colors}
          />

          {/* Online */}
          <Pill
            label="Online"
            active={onlineActive}
            isOpen={openKey === "online"}
            greenDot
            onPress={() => toggle("online")}
            colors={colors}
          />
        </ScrollView>

        {/* ⚙ sliders icon — fixed right */}
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={() => toggle("filters")}
          style={{
            marginRight: 12,
            width: 36,
            height: 36,
            borderRadius: 18,
            backgroundColor: anyFilterActive ? BRAND.primary + "18" : colors.surface,
            borderWidth: 1.5,
            borderColor: anyFilterActive ? BRAND.primary : colors.border,
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Ionicons name="options" size={18} color={anyFilterActive ? BRAND.primary : colors.textMuted} />
        </TouchableOpacity>
      </View>

      <FilterSheet
        visible={openKey !== null}
        activeKey={openKey}
        filters={filters}
        onClose={() => setOpenKey(null)}
        onApply={(patch) => setFilters((prev) => ({ ...prev, ...patch }))}
      />
    </>
  );
};
