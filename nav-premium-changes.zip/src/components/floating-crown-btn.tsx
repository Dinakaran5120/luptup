import { router } from "expo-router";
import { Pressable, Text } from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withRepeat,
  withSequence,
  withTiming,
} from "react-native-reanimated";
import { useEffect } from "react";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export const FloatingCrownBtn: React.FC = () => {
  const scale = useSharedValue(1);
  const glow = useSharedValue(1);

  // Subtle pulse animation
  useEffect(() => {
    glow.value = withRepeat(
      withSequence(
        withTiming(1.08, { duration: 900 }),
        withTiming(1, { duration: 900 })
      ),
      -1,
      true
    );
  }, []);

  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value * glow.value }],
  }));

  return (
    <AnimatedPressable
      style={[
        {
          position: "absolute",
          bottom: 90, // sits just above the tab bar
          right: 18,
          width: 50,
          height: 50,
          borderRadius: 25,
          backgroundColor: "#f59e0b",
          alignItems: "center",
          justifyContent: "center",
          shadowColor: "#f59e0b",
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.55,
          shadowRadius: 14,
          elevation: 12,
          zIndex: 999,
          borderWidth: 2,
          borderColor: "#fde68a",
        },
        animStyle,
      ]}
      onPressIn={() => { scale.value = withSpring(0.87, { damping: 10 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 10 }); }}
      onPress={() => router.push("/premium" as any)}
    >
      <Text style={{ fontSize: 22 }}>👑</Text>
    </AnimatedPressable>
  );
};
