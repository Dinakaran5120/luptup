import { BRAND, useTheme } from "@/context/theme";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import { useState } from "react";
import {
  Alert,
  Pressable,
  ScrollView,
  StatusBar,
  Text,
  View,
} from "react-native";
import Svg, { Defs, LinearGradient, Stop, Rect } from "react-native-svg";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

// ─── Data ─────────────────────────────────────────────────────────────────────

const FEATURES = [
  { icon: "heart",                  label: "See Who\nLikes You",    color: "#e879f9" },
  { icon: "infinite",               label: "Unlimited\nLikes",      color: BRAND.primary },
  { icon: "flash",                  label: "Priority\nMatches",     color: "#818cf8" },
  { icon: "rocket-outline",         label: "Profile\nBoost",        color: "#34d399" },
  { icon: "shield-checkmark",       label: "Verified\nBadge",       color: "#60a5fa" },
  { icon: "glasses-outline",        label: "Incognito\nBadge",      color: "#f472b6" },
];

type CoinPack = {
  id: string;
  coins: number;
  price: string;
  off?: number;
  bestValue?: boolean;
  emoji: string;
};

const COIN_PACKS: CoinPack[] = [
  { id: "c1", coins: 100,  price: "₹89.00",     emoji: "🪙" },
  { id: "c2", coins: 250,  price: "₹199.00",    off: 10,  emoji: "💰" },
  { id: "c3", coins: 550,  price: "₹399.00",    off: 20,  emoji: "💰" },
  { id: "c4", coins: 1200, price: "₹799.00",    off: 30,  emoji: "💎" },
  { id: "c5", coins: 2500, price: "₹1,499.00",  off: 40,  bestValue: true, emoji: "🏆" },
  { id: "c6", coins: 5000, price: "₹2,499.00",  off: 50,  emoji: "💎" },
];

// ─── Coin card ────────────────────────────────────────────────────────────────

const CoinCard: React.FC<{ pack: CoinPack; colors: ReturnType<typeof useTheme>["colors"] }> = ({ pack, colors }) => {
  const scale = useSharedValue(1);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <AnimatedPressable
      style={[
        {
          flex: 1,
          minWidth: "30%",
          maxWidth: "32%",
          borderRadius: 16,
          overflow: "visible",
          padding: 12,
          alignItems: "center",
          gap: 4,
          backgroundColor: pack.bestValue ? BRAND.primary + "18" : colors.surface,
          borderWidth: pack.bestValue ? 2 : 1,
          borderColor: pack.bestValue ? BRAND.primary : colors.border,
          shadowColor: pack.bestValue ? BRAND.primary : "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: pack.bestValue ? 0.3 : 0.08,
          shadowRadius: 8,
          elevation: pack.bestValue ? 6 : 2,
        },
        anim,
      ]}
      onPressIn={() => { scale.value = withSpring(0.94, { damping: 12 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 12 }); }}
      onPress={() => Alert.alert("Purchase", `Buy ${pack.coins} coins for ${pack.price}?`, [
        { text: "Cancel", style: "cancel" },
        { text: "Buy Now", style: "default" },
      ])}
    >
      {/* BEST VALUE banner */}
      {pack.bestValue && (
        <View
          style={{
            position: "absolute",
            top: -11,
            left: 0,
            right: 0,
            alignItems: "center",
            zIndex: 10,
          }}
        >
          <View
            style={{
              backgroundColor: BRAND.primary,
              paddingHorizontal: 10,
              paddingVertical: 3,
              borderRadius: 10,
            }}
          >
            <Text style={{ fontFamily: "Poppins-Bold", fontSize: 9, color: "#fff", letterSpacing: 0.5 }}>
              BEST VALUE
            </Text>
          </View>
        </View>
      )}

      {/* % OFF badge */}
      {pack.off && (
        <View
          style={{
            position: "absolute",
            top: 8,
            right: 8,
            backgroundColor: "#ef4444",
            borderRadius: 10,
            paddingHorizontal: 5,
            paddingVertical: 2,
          }}
        >
          <Text style={{ fontFamily: "Poppins-Bold", fontSize: 8, color: "#fff" }}>
            {pack.off}% OFF
          </Text>
        </View>
      )}

      {/* Coin emoji */}
      <Text style={{ fontSize: 30, marginTop: pack.bestValue ? 8 : 0 }}>{pack.emoji}</Text>

      {/* Coin count */}
      <Text style={{ fontFamily: "Poppins-Bold", fontSize: 14, color: pack.bestValue ? BRAND.primary : colors.text }}>
        {pack.coins.toLocaleString()}
      </Text>
      <Text style={{ fontFamily: "Poppins-Light", fontSize: 11, color: colors.textMuted }}>Coins</Text>

      {/* Price */}
      <View
        style={{
          marginTop: 4,
          backgroundColor: pack.bestValue ? BRAND.primary : colors.background,
          borderRadius: 10,
          paddingHorizontal: 8,
          paddingVertical: 4,
          width: "100%",
          alignItems: "center",
        }}
      >
        <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 12, color: pack.bestValue ? "#fff" : colors.text }}>
          {pack.price}
        </Text>
      </View>
    </AnimatedPressable>
  );
};

// ─── Feature icon ─────────────────────────────────────────────────────────────

const FeatureIcon: React.FC<{
  feature: (typeof FEATURES)[0];
  colors: ReturnType<typeof useTheme>["colors"];
}> = ({ feature, colors }) => (
  <View style={{ alignItems: "center", gap: 8, width: 72 }}>
    <View
      style={{
        width: 52,
        height: 52,
        borderRadius: 26,
        backgroundColor: feature.color + "22",
        alignItems: "center",
        justifyContent: "center",
        borderWidth: 1,
        borderColor: feature.color + "44",
      }}
    >
      <Ionicons name={feature.icon as any} size={24} color={feature.color} />
    </View>
    <Text style={{ fontFamily: "Poppins-Regular", fontSize: 10, color: colors.text, textAlign: "center", lineHeight: 14 }}>
      {feature.label}
    </Text>
  </View>
);

// ─── Page ─────────────────────────────────────────────────────────────────────

export default function PremiumPage() {
  const { colors, isDark } = useTheme();
  const { top, bottom } = useSafeAreaInsets();
  const [activeDot, setActiveDot] = useState(0);

  const MY_COINS = 125;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar barStyle="light-content" />

      {/* Header */}
      <View
        style={{
          paddingTop: top + 10,
          paddingBottom: 14,
          paddingHorizontal: 20,
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: colors.background,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <Pressable onPress={() => router.back()} style={{ position: "absolute", left: 20, top: top + 10, padding: 4 }}>
          <Ionicons name="arrow-back" size={24} color={colors.icon} />
        </Pressable>
        <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 17, color: colors.text }}>
          Lup Tup Premium
        </Text>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: bottom + 100 }}>

        {/* ── Hero Banner ── */}
        <View style={{ margin: 16, borderRadius: 20, overflow: "hidden" }}>
          <Svg width="100%" height={160} style={{ position: "absolute" }}>
            <Defs>
              <LinearGradient id="heroG" x1="0" y1="0" x2="1" y2="1">
                <Stop offset="0%" stopColor="#1a0533" />
                <Stop offset="60%" stopColor="#2d0a5c" />
                <Stop offset="100%" stopColor="#0d0d1a" />
              </LinearGradient>
            </Defs>
            <Rect width="100%" height={160} fill="url(#heroG)" rx={20} />
          </Svg>

          <View style={{ flexDirection: "row", alignItems: "center", padding: 20, height: 160 }}>
            {/* Text */}
            <View style={{ flex: 1, gap: 4 }}>
              <Text style={{ fontFamily: "Poppins-Bold", fontSize: 22, color: "#fff", lineHeight: 28 }}>
                Go Premium,{"\n"}Get Noticed 💜
              </Text>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: "rgba(255,255,255,0.7)", lineHeight: 18 }}>
                Unlock exclusive features and{"\n"}stand out from the crowd.
              </Text>
            </View>
            {/* Crown */}
            <Text style={{ fontSize: 72, marginRight: 4 }}>👑</Text>
          </View>
        </View>

        {/* ── Features row ── */}
        <View
          style={{
            marginHorizontal: 16,
            borderRadius: 20,
            backgroundColor: colors.surface,
            borderWidth: 1,
            borderColor: colors.border,
            paddingVertical: 20,
            paddingHorizontal: 12,
          }}
        >
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            onScroll={(e) => {
              const idx = Math.round(e.nativeEvent.contentOffset.x / 72);
              setActiveDot(Math.min(idx, FEATURES.length - 1));
            }}
            scrollEventThrottle={16}
            contentContainerStyle={{ gap: 12, paddingHorizontal: 4 }}
          >
            {FEATURES.map((f) => (
              <FeatureIcon key={f.label} feature={f} colors={colors} />
            ))}
          </ScrollView>

          {/* Dot indicator */}
          <View style={{ flexDirection: "row", justifyContent: "center", gap: 5, marginTop: 14 }}>
            {FEATURES.map((_, i) => (
              <View
                key={i}
                style={{
                  width: i === activeDot ? 16 : 6,
                  height: 6,
                  borderRadius: 3,
                  backgroundColor: i === activeDot ? BRAND.primary : colors.border,
                }}
              />
            ))}
          </View>
        </View>

        {/* ── My Coins row ── */}
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-between",
            marginHorizontal: 16,
            marginTop: 20,
          }}
        >
          {/* Left: coins */}
          <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
            <View
              style={{
                width: 44,
                height: 44,
                borderRadius: 22,
                backgroundColor: "#f59e0b22",
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: "#f59e0b44",
              }}
            >
              <Text style={{ fontSize: 22 }}>🪙</Text>
            </View>
            <View>
              <Text style={{ fontFamily: "Poppins-Bold", fontSize: 22, color: colors.text, lineHeight: 26 }}>
                {MY_COINS}
              </Text>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>
                My Coins
              </Text>
            </View>
          </View>

          {/* Right: Transaction history */}
          <Pressable
            onPress={() => Alert.alert("Transaction History", "No transactions yet.")}
            style={{ flexDirection: "row", alignItems: "center", gap: 4 }}
          >
            <Text style={{ fontFamily: "Poppins-Medium", fontSize: 13, color: BRAND.primary }}>
              Transaction History
            </Text>
            <Ionicons name="chevron-forward" size={14} color={BRAND.primary} />
          </Pressable>
        </View>

        {/* ── Buy Coins ── */}
        <View style={{ marginHorizontal: 16, marginTop: 20 }}>
          <Text style={{ fontFamily: "Poppins-Bold", fontSize: 17, color: colors.text }}>
            Buy Coins
          </Text>
          <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: colors.textMuted, marginTop: 2 }}>
            Use coins to send gifts, boost profile and more.
          </Text>

          {/* Grid: 3 columns × 2 rows */}
          <View style={{ marginTop: 14, gap: 14 }}>
            {/* Row 1 */}
            <View style={{ flexDirection: "row", gap: 10 }}>
              {COIN_PACKS.slice(0, 3).map((pack) => (
                <CoinCard key={pack.id} pack={pack} colors={colors} />
              ))}
            </View>
            {/* Row 2 */}
            <View style={{ flexDirection: "row", gap: 10, marginTop: 6 }}>
              {COIN_PACKS.slice(3, 6).map((pack) => (
                <CoinCard key={pack.id} pack={pack} colors={colors} />
              ))}
            </View>
          </View>
        </View>

        {/* ── Secure payments note ── */}
        <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 6, marginTop: 18 }}>
          <Ionicons name="lock-closed-outline" size={13} color={colors.textMuted} />
          <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>
            Secure payments
          </Text>
          <Text style={{ color: colors.border }}>•</Text>
          <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>
            Cancel anytime
          </Text>
        </View>

        {/* ── Premium Membership card ── */}
        <View
          style={{
            marginHorizontal: 16,
            marginTop: 20,
            borderRadius: 20,
            overflow: "hidden",
          }}
        >
          <Svg width="100%" height={90} style={{ position: "absolute" }}>
            <Defs>
              <LinearGradient id="pmG" x1="0" y1="0" x2="1" y2="0">
                <Stop offset="0%" stopColor="#1a0533" />
                <Stop offset="100%" stopColor="#2d0a5c" />
              </LinearGradient>
            </Defs>
            <Rect width="100%" height={90} fill="url(#pmG)" rx={20} />
          </Svg>

          <View style={{ flexDirection: "row", alignItems: "center", padding: 16, gap: 12, height: 90 }}>
            {/* Crown */}
            <View
              style={{
                width: 48,
                height: 48,
                borderRadius: 14,
                backgroundColor: "#f59e0b22",
                alignItems: "center",
                justifyContent: "center",
                borderWidth: 1,
                borderColor: "#f59e0b55",
              }}
            >
              <Text style={{ fontSize: 26 }}>👑</Text>
            </View>

            {/* Text */}
            <View style={{ flex: 1, gap: 2 }}>
              <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: "#fff" }}>
                  Premium Membership
                </Text>
                <View style={{ backgroundColor: "#f59e0b", paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8 }}>
                  <Text style={{ fontFamily: "Poppins-Bold", fontSize: 9, color: "#fff" }}>Most Popular</Text>
                </View>
              </View>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 11, color: "rgba(255,255,255,0.65)" }}>
                Unlimited coins + all premium features
              </Text>
            </View>

            {/* View Plans button */}
            <Pressable
              onPress={() => Alert.alert("Premium Plans", "Coming soon!")}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 4,
                backgroundColor: BRAND.primary,
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderRadius: 14,
              }}
            >
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 12, color: "#fff" }}>View Plans</Text>
              <Ionicons name="chevron-forward" size={13} color="#fff" />
            </Pressable>
          </View>
        </View>

        {/* ── Footer ── */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
            paddingHorizontal: 20,
            marginTop: 20,
          }}
        >
          <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
            <Ionicons name="help-circle-outline" size={16} color={colors.textMuted} />
            <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: colors.textMuted }}>
              Need help with payment?
            </Text>
          </View>
          <Pressable
            onPress={() => Alert.alert("Contact Support", "support@luptup.com")}
            style={{ flexDirection: "row", alignItems: "center", gap: 3 }}
          >
            <Text style={{ fontFamily: "Poppins-Medium", fontSize: 13, color: BRAND.primary }}>
              Contact Support
            </Text>
            <Ionicons name="chevron-forward" size={13} color={BRAND.primary} />
          </Pressable>
        </View>

      </ScrollView>
    </View>
  );
}
