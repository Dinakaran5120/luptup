import { BRAND, useTheme } from "@/context/theme";
import { FloatingCrownBtn } from "@/components/floating-crown-btn";
import { Ionicons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { Text, View } from "react-native";
import Svg, { Defs, LinearGradient, Stop, Rect } from "react-native-svg";

const TAB_H = 70;
const CHAT_BADGE = 3;

export default function Layout() {
  const { colors } = useTheme();

  return (
    <View style={{ flex: 1 }}>
      <Tabs
        screenOptions={{
          headerShown: false,
          tabBarShowLabel: true,
          tabBarStyle: {
            backgroundColor: colors.tabBar,
            borderTopColor: colors.tabBarBorder,
            borderTopWidth: 1,
            height: TAB_H,
            paddingBottom: 10,
            paddingTop: 8,
          },
          tabBarActiveTintColor: colors.primary,
          tabBarInactiveTintColor: colors.iconMuted,
          tabBarLabelStyle: {
            fontFamily: "Poppins-Medium",
            fontSize: 11,
            marginTop: 2,
          },
        }}
      >
        {/* 1 — Discover */}
        <Tabs.Screen
          name="index"
          options={{
            title: "Discover",
            tabBarIcon: ({ color, focused }) => (
              <Ionicons name={focused ? "heart" : "heart-outline"} size={24} color={color} />
            ),
          }}
        />

        {/* 2 — Mood (explore) */}
        <Tabs.Screen
          name="likes"
          options={{
            title: "Mood",
            tabBarIcon: ({ color, focused }) => (
              <Ionicons name={focused ? "happy" : "happy-outline"} size={24} color={color} />
            ),
          }}
        />

        {/* 3 — Post / Upload (centre + button) */}
        <Tabs.Screen
          name="post"
          options={{
            title: "",
            tabBarIcon: () => (
              <View
                style={{
                  width: 52,
                  height: 52,
                  borderRadius: 26,
                  overflow: "hidden",
                  marginBottom: 8,
                  shadowColor: BRAND.primary,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.45,
                  shadowRadius: 10,
                  elevation: 10,
                }}
              >
                <Svg width={52} height={52}>
                  <Defs>
                    <LinearGradient id="plusG" x1="0" y1="0" x2="1" y2="1">
                      <Stop offset="0%" stopColor={BRAND.primary} />
                      <Stop offset="100%" stopColor={BRAND.secondary} />
                    </LinearGradient>
                  </Defs>
                  <Rect width={52} height={52} fill="url(#plusG)" rx={26} />
                </Svg>
                <View style={{ position: "absolute", inset: 0, alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name="add" size={30} color="#fff" />
                </View>
              </View>
            ),
          }}
        />

        {/* 4 — Chats */}
        <Tabs.Screen
          name="matches"
          options={{
            title: "Chats",
            tabBarIcon: ({ color, focused }) => (
              <View>
                <Ionicons name={focused ? "chatbubble" : "chatbubble-outline"} size={24} color={color} />
                <View
                  style={{
                    position: "absolute",
                    top: -4,
                    right: -10,
                    backgroundColor: "#ef4444",
                    borderRadius: 8,
                    minWidth: 18,
                    height: 18,
                    alignItems: "center",
                    justifyContent: "center",
                    paddingHorizontal: 3,
                  }}
                >
                  <Text style={{ color: "#fff", fontSize: 10, fontFamily: "Poppins-SemiBold", lineHeight: 14 }}>
                    {CHAT_BADGE}
                  </Text>
                </View>
              </View>
            ),
          }}
        />

        {/* 5 — Groups */}
        <Tabs.Screen
          name="community"
          options={{
            title: "Groups",
            tabBarIcon: ({ color, focused }) => (
              <Ionicons name={focused ? "people" : "people-outline"} size={24} color={color} />
            ),
          }}
        />

        {/* Hidden — Profile accessible via hamburger */}
        <Tabs.Screen name="hinge" options={{ href: null }} />
      </Tabs>

      {/* Floating crown button — renders above all tabs */}
      <FloatingCrownBtn />
    </View>
  );
}
