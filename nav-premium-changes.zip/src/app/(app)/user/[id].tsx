import { BRAND, useTheme } from "@/context/theme";
import { MOCK_DISCOVER_PROFILES, MOCK_LIKES, MOCK_PROFILES, DiscoverProfile } from "@/lib/mock-data";
import { FloatingCrownBtn } from "@/components/floating-crown-btn";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import { Image } from "expo-image";
import { router, useLocalSearchParams } from "expo-router";
import { useMemo, useState } from "react";
import {
  Alert,
  Modal,
  Pressable,
  ScrollView,
  StatusBar,
  Text,
  View,
} from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const INTEREST_ICONS: Record<string, string> = {
  Travel: "airplane-outline",
  Coffee: "cafe-outline",
  Music: "musical-notes-outline",
  Photography: "camera-outline",
  Dogs: "paw-outline",
  Cats: "paw-outline",
  Books: "book-outline",
  "Book lover": "book-outline",
  Art: "color-palette-outline",
  Fitness: "barbell-outline",
  Movies: "film-outline",
  "Road Trips": "car-outline",
  Cooking: "restaurant-outline",
};

// ─── Settings bottom sheet ────────────────────────────────────────────────────

const SettingsSheet: React.FC<{
  visible: boolean;
  name: string;
  onClose: () => void;
}> = ({ visible, name, onClose }) => {
  const { colors } = useTheme();

  const OPTIONS = [
    { key: "block",   icon: "ban-outline",        label: "Block",   color: "#ef4444" },
    { key: "report",  icon: "flag-outline",        label: "Report",  color: "#f59e0b" },
    { key: "archive", icon: "archive-outline",     label: "Archive", color: colors.textMuted },
  ];

  const handleAction = (key: string) => {
    onClose();
    const msgs: Record<string, string> = {
      block:   `${name} has been blocked.`,
      report:  `${name} has been reported. We'll review this shortly.`,
      archive: `${name} has been archived.`,
    };
    setTimeout(() => Alert.alert("Done", msgs[key] ?? ""), 300);
  };

  return (
    <Modal visible={visible} transparent animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.55)", justifyContent: "flex-end" }} onPress={onClose}>
        <Pressable
          style={{
            backgroundColor: colors.background,
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            paddingBottom: 44,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: -4 },
            shadowOpacity: 0.2,
            shadowRadius: 20,
            elevation: 20,
          }}
          onPress={() => {}}
        >
          {/* Handle */}
          <View style={{ alignItems: "center", paddingTop: 14, paddingBottom: 8 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border }} />
          </View>
          <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: colors.text, textAlign: "center", paddingBottom: 8 }}>
            Options
          </Text>

          {OPTIONS.map((opt, i) => (
            <View key={opt.key}>
              <Pressable
                style={{ flexDirection: "row", alignItems: "center", gap: 16, paddingHorizontal: 24, paddingVertical: 18 }}
                onPress={() => handleAction(opt.key)}
              >
                <View style={{ width: 44, height: 44, borderRadius: 14, backgroundColor: opt.color + "18", alignItems: "center", justifyContent: "center" }}>
                  <Ionicons name={opt.icon as any} size={20} color={opt.color} />
                </View>
                <Text style={{ fontFamily: "Poppins-Medium", fontSize: 15, color: opt.color }}>{opt.label}</Text>
              </Pressable>
              {i < OPTIONS.length - 1 && (
                <View style={{ height: 1, backgroundColor: colors.border, marginLeft: 84 }} />
              )}
            </View>
          ))}
        </Pressable>
      </Pressable>
    </Modal>
  );
};

// ─── Locked profile overlay ───────────────────────────────────────────────────

const LockedProfileView: React.FC<{
  profile: DiscoverProfile;
  onBack: () => void;
  onSettings: () => void;
  isDark: boolean;
  colors: ReturnType<typeof useTheme>["colors"];
  insetTop: number;
}> = ({ profile, onBack, onSettings, isDark, colors, insetTop }) => {
  const [requested, setRequested] = useState(false);

  return (
    <View style={{ flex: 1, backgroundColor: colors.background, alignItems: "center" }}>
      {/* Top bar */}
      <View
        style={{
          width: "100%",
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 20,
          paddingTop: insetTop + 10,
          paddingBottom: 12,
        }}
      >
        <Pressable onPress={onBack} style={{ padding: 4 }}>
          <Ionicons name="arrow-back" size={24} color={colors.icon} />
        </Pressable>
        <Pressable onPress={onSettings} style={{ padding: 4 }}>
          <Ionicons name="settings-outline" size={22} color={colors.icon} />
        </Pressable>
      </View>

      {/* Blurred circular photo */}
      <View
        style={{
          width: 130,
          height: 130,
          borderRadius: 65,
          overflow: "hidden",
          marginTop: 20,
          borderWidth: 3,
          borderColor: colors.border,
        }}
      >
        <Image source={profile.photo} style={{ width: "100%", height: "100%" }} contentFit="cover" />
        <BlurView
          intensity={60}
          tint={isDark ? "dark" : "light"}
          style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}
        />
        <View style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0, alignItems: "center", justifyContent: "center", backgroundColor: "rgba(0,0,0,0.3)" }}>
          <Ionicons name="lock-closed" size={36} color="#fff" />
        </View>
      </View>

      {/* Name + verified */}
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8, marginTop: 18 }}>
        <Text style={{ fontFamily: "Poppins-Bold", fontSize: 24, color: colors.text }}>
          {profile.name}, {profile.age}
        </Text>
        <Ionicons name="checkmark-circle" size={22} color="#3b82f6" />
      </View>

      {/* Badge */}
      {profile.badge && (
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 4,
            backgroundColor: profile.badge === "Popular" ? "#f59e0b22" : BRAND.secondary + "22",
            paddingHorizontal: 12,
            paddingVertical: 5,
            borderRadius: 16,
            marginTop: 8,
            borderWidth: 1,
            borderColor: profile.badge === "Popular" ? "#f59e0b55" : BRAND.secondary + "55",
          }}
        >
          {profile.badge === "Popular" && <Ionicons name="star" size={13} color="#f59e0b" />}
          <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: profile.badge === "Popular" ? "#f59e0b" : BRAND.secondary }}>
            {profile.badge}
          </Text>
        </View>
      )}

      <Text style={{ fontFamily: "Poppins-Regular", fontSize: 14, color: colors.textMuted, marginTop: 12, paddingHorizontal: 32, textAlign: "center" }}>
        This profile is private. Send a request to unlock.
      </Text>

      {/* Location */}
      <View style={{ flexDirection: "row", alignItems: "center", gap: 6, marginTop: 10 }}>
        <Ionicons name="location-outline" size={15} color={colors.textMuted} />
        <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: colors.textMuted }}>{profile.location}</Text>
      </View>

      {/* Send Request button */}
      <Pressable
        onPress={() => setRequested((p) => !p)}
        style={{
          marginTop: 32,
          height: 54,
          width: "80%",
          borderRadius: 27,
          backgroundColor: requested ? colors.surface : BRAND.primary,
          borderWidth: requested ? 1.5 : 0,
          borderColor: BRAND.primary,
          alignItems: "center",
          justifyContent: "center",
          shadowColor: requested ? "transparent" : BRAND.primary,
          shadowOffset: { width: 0, height: 6 },
          shadowOpacity: 0.35,
          shadowRadius: 12,
          elevation: requested ? 0 : 6,
          flexDirection: "row",
          gap: 8,
        }}
      >
        <Ionicons
          name={requested ? "checkmark-circle" : "person-add-outline"}
          size={20}
          color={requested ? BRAND.primary : "#fff"}
        />
        <Text
          style={{
            fontFamily: "Poppins-SemiBold",
            fontSize: 16,
            color: requested ? BRAND.primary : "#fff",
          }}
        >
          {requested ? "Request Sent" : "Send Request"}
        </Text>
      </Pressable>

      {/* Coin unlock option */}
      {profile.unlockCost && (
        <Pressable
          onPress={() => Alert.alert("Unlock", `Unlock for ${profile.unlockCost} coins?`, [{ text: "Cancel", style: "cancel" }, { text: "Unlock" }])}
          style={{
            marginTop: 14,
            flexDirection: "row",
            alignItems: "center",
            gap: 6,
            paddingHorizontal: 20,
            paddingVertical: 10,
          }}
        >
          <View style={{ width: 20, height: 20, borderRadius: 10, backgroundColor: "#f59e0b", alignItems: "center", justifyContent: "center" }}>
            <Ionicons name="star" size={11} color="#fff" />
          </View>
          <Text style={{ fontFamily: "Poppins-Medium", fontSize: 14, color: colors.textMuted }}>
            or unlock with {profile.unlockCost} coins
          </Text>
        </Pressable>
      )}
    </View>
  );
};

// ─── Full profile view ────────────────────────────────────────────────────────

const FullProfileView: React.FC<{
  profile: DiscoverProfile;
  onBack: () => void;
  onSettings: () => void;
  isDark: boolean;
  colors: ReturnType<typeof useTheme>["colors"];
  insetTop: number;
}> = ({ profile, onBack, onSettings, isDark, colors, insetTop }) => {
  const [liked, setLiked] = useState(false);
  const heartScale = useSharedValue(1);
  const heartAnim = useAnimatedStyle(() => ({ transform: [{ scale: heartScale.value }] }));

  const handleLike = () => {
    heartScale.value = withSpring(1.3, { damping: 8 }, () => {
      heartScale.value = withSpring(1, { damping: 10 });
    });
    setLiked((p) => !p);
  };

  const handleMessage = () => {
    router.push("/matches" as any);
  };

  return (
    <ScrollView style={{ flex: 1, backgroundColor: colors.background }} showsVerticalScrollIndicator={false}>
      {/* Top bar */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 20,
          paddingTop: insetTop + 10,
          paddingBottom: 12,
          backgroundColor: colors.background,
        }}
      >
        <Pressable onPress={onBack} style={{ padding: 4 }}>
          <Ionicons name="arrow-back" size={24} color={colors.icon} />
        </Pressable>
        <Pressable onPress={onSettings} style={{ padding: 4 }}>
          <Ionicons name="settings-outline" size={22} color={colors.icon} />
        </Pressable>
      </View>

      {/* Circular avatar */}
      <View style={{ alignItems: "center", marginTop: 8 }}>
        <View style={{ position: "relative" }}>
          <View
            style={{
              width: 130,
              height: 130,
              borderRadius: 65,
              overflow: "hidden",
              borderWidth: 3,
              borderColor: BRAND.primary + "55",
            }}
          >
            <Image
              source={profile.photo}
              style={{ width: "100%", height: "100%" }}
              contentFit="cover"
            />
          </View>
          {/* Small action icon at bottom-right of avatar */}
          <View
            style={{
              position: "absolute",
              bottom: 2,
              right: 2,
              width: 34,
              height: 34,
              borderRadius: 17,
              backgroundColor: BRAND.primary,
              alignItems: "center",
              justifyContent: "center",
              borderWidth: 2,
              borderColor: colors.background,
              shadowColor: BRAND.primary,
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.4,
              shadowRadius: 4,
              elevation: 4,
            }}
          >
            <Ionicons name="chatbubble-ellipses" size={16} color="#fff" />
          </View>
        </View>
      </View>

      {/* Name + verified */}
      <View style={{ alignItems: "center", marginTop: 16, gap: 4 }}>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
          <Text style={{ fontFamily: "Poppins-Bold", fontSize: 24, color: colors.text }}>
            {profile.name}, {profile.age}
          </Text>
          <Ionicons name="checkmark-circle" size={22} color="#3b82f6" />
        </View>

        {/* Pronouns | Sexuality */}
        {(profile.pronouns || profile.sexuality) && (
          <Text style={{ fontFamily: "Poppins-Regular", fontSize: 14, color: colors.textMuted }}>
            {[profile.pronouns, profile.sexuality].filter(Boolean).join("  |  ")}
          </Text>
        )}

        {/* Online + location + distance */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 5, marginTop: 2 }}>
          {profile.isOnline && (
            <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: "#22c55e" }} />
          )}
          <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: colors.textMuted, fontStyle: "italic" }}>
            {[profile.isOnline ? "Online" : null, profile.location, profile.distance].filter(Boolean).join(" • ")}
          </Text>
        </View>
      </View>

      {/* Quick interest tags — horizontal scroll */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{ paddingHorizontal: 20, paddingTop: 18, gap: 8 }}
      >
        {profile.interests.map((interest) => (
          <View
            key={interest}
            style={{
              paddingHorizontal: 14,
              paddingVertical: 8,
              borderRadius: 20,
              backgroundColor: colors.surface,
              borderWidth: 1,
              borderColor: colors.border,
            }}
          >
            <Text style={{ fontFamily: "Poppins-Regular", fontSize: 13, color: colors.text }}>
              {interest}
            </Text>
          </View>
        ))}
      </ScrollView>

      {/* Action buttons: Like + Message */}
      <View style={{ flexDirection: "row", gap: 12, paddingHorizontal: 20, marginTop: 20 }}>
        {/* Like */}
        <AnimatedPressable
          style={[
            {
              flex: 1,
              height: 50,
              borderRadius: 25,
              backgroundColor: liked ? BRAND.primary : colors.surface,
              borderWidth: 1.5,
              borderColor: liked ? BRAND.primary : colors.border,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "center",
              gap: 8,
            },
            heartAnim,
          ]}
          onPress={handleLike}
        >
          <Ionicons name={liked ? "heart" : "heart-outline"} size={20} color={liked ? "#fff" : BRAND.primary} />
          <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: liked ? "#fff" : BRAND.primary }}>
            {liked ? "Liked" : "Like"}
          </Text>
        </AnimatedPressable>

        {/* Message */}
        <Pressable
          onPress={handleMessage}
          style={{
            flex: 1,
            height: 50,
            borderRadius: 25,
            backgroundColor: BRAND.primary,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            shadowColor: BRAND.primary,
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: 0.35,
            shadowRadius: 10,
            elevation: 6,
          }}
        >
          <Ionicons name="chatbubble-ellipses-outline" size={20} color="#fff" />
          <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: "#fff" }}>Message</Text>
        </Pressable>
      </View>

      {/* About me */}
      {profile.bio && (
        <View style={{ marginHorizontal: 20, marginTop: 24, padding: 18, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}>
          <Text style={{ fontFamily: "Poppins-Bold", fontSize: 15, color: colors.text, marginBottom: 8 }}>
            About me
          </Text>
          <Text style={{ fontFamily: "Poppins-Regular", fontSize: 14, color: colors.text, lineHeight: 22 }}>
            {profile.bio}
          </Text>
        </View>
      )}

      {/* Interests */}
      <View style={{ marginHorizontal: 20, marginTop: 20, marginBottom: 32 }}>
        <Text style={{ fontFamily: "Poppins-Bold", fontSize: 15, color: colors.text, marginBottom: 12 }}>
          Interests
        </Text>
        <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 10 }}>
          {profile.interests.map((interest) => (
            <View
              key={interest}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 6,
                paddingHorizontal: 14,
                paddingVertical: 8,
                borderRadius: 20,
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <Ionicons
                name={(INTEREST_ICONS[interest] ?? "ellipse-outline") as any}
                size={14}
                color={BRAND.primary}
              />
              <Text style={{ fontFamily: "Poppins-Regular", fontSize: 13, color: colors.text }}>
                {interest}
              </Text>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
};

// ─── Main screen ──────────────────────────────────────────────────────────────

export default function UserProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { colors, isDark } = useTheme();
  const { top } = useSafeAreaInsets();
  const [settingsVisible, setSettingsVisible] = useState(false);

  const profile = useMemo((): DiscoverProfile | undefined => {
    // Check discover profiles first
    const fromDiscover = MOCK_DISCOVER_PROFILES.find((p) => p.id === id);
    if (fromDiscover) return fromDiscover;

    // Fall back to legacy mock profiles — wrap them into DiscoverProfile shape
    const fromProfiles = MOCK_PROFILES.find((p) => p.id === id);
    if (fromProfiles) {
      return {
        id: fromProfiles.id,
        name: fromProfiles.first_name,
        age: fromProfiles.age ?? 25,
        isOnline: true,
        isLocked: false,
        badge: null,
        interests: (fromProfiles.pets ?? []).concat(["Travel", "Coffee"]),
        location: fromProfiles.neighborhood ?? "Unknown",
        photo: fromProfiles.photos?.[0]?.photo_url ?? "",
        pronouns: "She/Her",
        sexuality: fromProfiles.sexuality ?? undefined,
        bio: fromProfiles.answers?.[0]?.answer_text ?? undefined,
        distance: "nearby",
      };
    }

    const fromLikes = MOCK_LIKES.find((l) => l.profile.id === id);
    if (fromLikes) {
      const p = fromLikes.profile;
      return {
        id: p.id,
        name: p.first_name,
        age: p.age ?? 25,
        isOnline: false,
        isLocked: false,
        badge: null,
        interests: (p.pets ?? []).concat(["Photography"]),
        location: p.neighborhood ?? "Unknown",
        photo: fromLikes.photo_url ?? p.photos?.[0]?.photo_url ?? "",
        bio: fromLikes.answer_text ?? undefined,
        distance: "nearby",
      };
    }

    return undefined;
  }, [id]);

  if (!profile) {
    return (
      <View style={{ flex: 1, backgroundColor: colors.background, alignItems: "center", justifyContent: "center" }}>
        <Text style={{ fontFamily: "Poppins-Regular", color: colors.textMuted }}>Profile not found</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      {profile.isLocked ? (
        <LockedProfileView
          profile={profile}
          onBack={() => router.back()}
          onSettings={() => setSettingsVisible(true)}
          isDark={isDark}
          colors={colors}
          insetTop={top}
        />
      ) : (
        <FullProfileView
          profile={profile}
          onBack={() => router.back()}
          onSettings={() => setSettingsVisible(true)}
          isDark={isDark}
          colors={colors}
          insetTop={top}
        />
      )}

      <FloatingCrownBtn />

      <SettingsSheet
        visible={settingsVisible}
        name={profile.name}
        onClose={() => setSettingsVisible(false)}
      />
    </View>
  );
}
