import { BRAND, useTheme } from "@/context/theme";
import { supabase } from "@/lib/supabase";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Modal,
  Pressable,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

// ─── Hamburger Menu Sheet ─────────────────────────────────────────────────────

const HamburgerSheet: React.FC<{
  visible: boolean;
  onClose: () => void;
}> = ({ visible, onClose }) => {
  const { colors } = useTheme();

  const handleLogout = () => {
    onClose();
    setTimeout(() => {
      Alert.alert("Logout", "Are you sure you want to logout?", [
        { text: "Cancel", style: "cancel" },
        {
          text: "Logout",
          style: "destructive",
          onPress: async () => {
            await supabase.auth.signOut();
            router.replace("/sign-in" as any);
          },
        },
      ]);
    }, 350);
  };

  const OPTIONS = [
    {
      key: "profile",
      icon: "person-circle-outline",
      label: "Account / Profile",
      subtitle: "Edit your profile and settings",
      color: colors.primary,
      onPress: () => { onClose(); setTimeout(() => router.push("/hinge" as any), 250); },
    },
    {
      key: "premium",
      icon: "star-outline",
      label: "Go Premium",
      subtitle: "Unlock exclusive features",
      color: "#f59e0b",
      onPress: () => { onClose(); setTimeout(() => router.push("/premium" as any), 250); },
    },
    {
      key: "settings",
      icon: "settings-outline",
      label: "Settings",
      subtitle: "Notifications, privacy & more",
      color: colors.textMuted,
      onPress: () => { onClose(); setTimeout(() => router.push("/settings" as any), 250); },
    },
    {
      key: "logout",
      icon: "log-out-outline",
      label: "Logout",
      subtitle: "Sign out of your account",
      color: "#ef4444",
      onPress: handleLogout,
    },
  ];

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      {/* Backdrop — tap to close */}
      <TouchableOpacity
        activeOpacity={1}
        style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.55)", justifyContent: "flex-end" }}
        onPress={onClose}
      >
        {/* Sheet — stop propagation */}
        <TouchableOpacity
          activeOpacity={1}
          style={{
            backgroundColor: colors.background,
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            paddingBottom: 44,
          }}
        >
          {/* Drag handle */}
          <View style={{ alignItems: "center", paddingTop: 14, paddingBottom: 10 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border }} />
          </View>

          <Text style={{
            fontFamily: "Poppins-SemiBold",
            fontSize: 16,
            color: colors.text,
            paddingHorizontal: 24,
            paddingBottom: 8,
          }}>
            Menu
          </Text>

          {OPTIONS.map((opt, i) => (
            <View key={opt.key}>
              <TouchableOpacity
                activeOpacity={0.7}
                style={{ flexDirection: "row", alignItems: "center", gap: 14, paddingHorizontal: 20, paddingVertical: 16 }}
                onPress={opt.onPress}
              >
                <View style={{
                  width: 48,
                  height: 48,
                  borderRadius: 14,
                  backgroundColor: opt.color + "18",
                  alignItems: "center",
                  justifyContent: "center",
                }}>
                  <Ionicons name={opt.icon as any} size={22} color={opt.color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{
                    fontFamily: "Poppins-Medium",
                    fontSize: 15,
                    color: opt.key === "logout" ? "#ef4444" : colors.text,
                  }}>
                    {opt.label}
                  </Text>
                  <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>
                    {opt.subtitle}
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={16} color={colors.iconMuted} />
              </TouchableOpacity>
              {i < OPTIONS.length - 1 && (
                <View style={{ height: 1, backgroundColor: colors.border, marginLeft: 82 }} />
              )}
            </View>
          ))}
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
};

// ─── TopNav ───────────────────────────────────────────────────────────────────

interface Props {
  showNotification?: boolean;
  showCoins?: boolean;
  onNotificationPress?: () => void;
}

export const TopNav: React.FC<Props> = ({
  showNotification = true,
  showCoins = true,
  onNotificationPress,
}) => {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const [coins] = useState(1542);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <>
      <View style={{
        paddingTop: insets.top,
        backgroundColor: colors.background,
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
      }}>
        <View style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 16,
          paddingVertical: 10,
        }}>
          {/* Logo */}
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <Ionicons name="heart" size={20} color={BRAND.primary} />
            <Text style={{
              fontFamily: "Poppins-Bold",
              fontSize: 20,
              color: colors.text,
              letterSpacing: -0.3,
            }}>
              lup tup
            </Text>
          </View>

          {/* Right controls */}
          <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>

            {/* Coins pill */}
            {showCoins && (
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => router.push("/premium" as any)}
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 5,
                  backgroundColor: colors.surface,
                  borderRadius: 20,
                  paddingHorizontal: 10,
                  paddingVertical: 5,
                  borderWidth: 1,
                  borderColor: colors.border,
                }}
              >
                <View style={{
                  width: 20,
                  height: 20,
                  borderRadius: 10,
                  backgroundColor: "#f59e0b",
                  alignItems: "center",
                  justifyContent: "center",
                }}>
                  <Ionicons name="star" size={11} color="#fff" />
                </View>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: colors.text }}>
                  {coins.toLocaleString()}
                </Text>
                <View style={{
                  width: 18,
                  height: 18,
                  borderRadius: 9,
                  backgroundColor: BRAND.primary,
                  alignItems: "center",
                  justifyContent: "center",
                }}>
                  <Ionicons name="add" size={12} color="#fff" />
                </View>
              </TouchableOpacity>
            )}

            {/* Notification bell */}
            {showNotification && (
              <View style={{ position: "relative" }}>
                <TouchableOpacity
                  activeOpacity={0.8}
                  onPress={onNotificationPress ?? (() => router.push("/notifications" as any))}
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 18,
                    backgroundColor: colors.surface,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Ionicons name="notifications-outline" size={18} color={colors.icon} />
                </TouchableOpacity>
                {/* Red dot */}
                <View style={{
                  position: "absolute",
                  top: 5,
                  right: 5,
                  width: 8,
                  height: 8,
                  borderRadius: 4,
                  backgroundColor: "#ef4444",
                  borderWidth: 1.5,
                  borderColor: colors.background,
                  pointerEvents: "none",
                }} />
              </View>
            )}

            {/* Hamburger ≡ */}
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => setMenuOpen(true)}
              style={{
                width: 36,
                height: 36,
                borderRadius: 18,
                backgroundColor: colors.surface,
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Ionicons name="menu" size={20} color={colors.icon} />
            </TouchableOpacity>

          </View>
        </View>
      </View>

      <HamburgerSheet visible={menuOpen} onClose={() => setMenuOpen(false)} />
    </>
  );
};
