import { VideoBackground } from "@/components/video-background";
import { Logo } from "@/components/logo";
import { AntDesign, Ionicons } from "@expo/vector-icons";
import { Stack, router } from "expo-router";
import { Pressable, StatusBar, Text, TouchableOpacity, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import Svg, {
  Defs,
  LinearGradient as SvgGradient,
  Rect,
  Stop,
} from "react-native-svg";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export default function Page() {
  const phoneScale = useSharedValue(1);
  const googleScale = useSharedValue(1);

  const phoneAnim = useAnimatedStyle(() => ({ transform: [{ scale: phoneScale.value }] }));
  const googleAnim = useAnimatedStyle(() => ({ transform: [{ scale: googleScale.value }] }));

  return (
    <View style={{ flex: 1 }}>
      <Stack.Screen options={{ headerShown: false }} />
      <StatusBar barStyle="light-content" />

      <VideoBackground source={require("~/assets/images/background.mp4")}>
        {/* Full-screen dark gradient overlay */}
        <Svg
          style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}
          width="100%"
          height="100%"
        >
          <Defs>
            <SvgGradient id="signInGrad" x1="0" y1="0" x2="0" y2="1">
              <Stop offset="0%" stopColor="#000" stopOpacity="0.2" />
              <Stop offset="45%" stopColor="#000" stopOpacity="0.35" />
              <Stop offset="100%" stopColor="#0d0d1a" stopOpacity="0.95" />
            </SvgGradient>
          </Defs>
          <Rect x="0" y="0" width="100%" height="100%" fill="url(#signInGrad)" />
        </Svg>

        <SafeAreaView style={{ flex: 1 }}>
          <View style={{ flex: 1, paddingHorizontal: 28 }}>

            {/* Logo area */}
            <View style={{ flex: 1, alignItems: "center", justifyContent: "center", gap: 14 }}>
              <View style={{ alignItems: "center", gap: 10 }}>
                {/* Logo image — white version for dark video background */}
                <Logo variant="white" height={72} />
                <Text
                  style={{
                    fontFamily: "Poppins-Light",
                    fontSize: 14,
                    color: "rgba(255,255,255,0.7)",
                    letterSpacing: 0.4,
                    textAlign: "center",
                  }}
                >
                  Find your real connection
                </Text>
              </View>

              {/* Feature pills */}
              <View
                style={{
                  flexDirection: "row",
                  flexWrap: "wrap",
                  justifyContent: "center",
                  gap: 8,
                  marginTop: 16,
                }}
              >
                {["Privacy First", "Real Matches", "Safe Space"].map((tag) => (
                  <View
                    key={tag}
                    style={{
                      paddingHorizontal: 14,
                      paddingVertical: 6,
                      borderRadius: 20,
                      backgroundColor: "rgba(255,255,255,0.1)",
                      borderWidth: 1,
                      borderColor: "rgba(255,255,255,0.18)",
                    }}
                  >
                    <Text
                      style={{
                        fontFamily: "Poppins-Medium",
                        fontSize: 12,
                        color: "rgba(255,255,255,0.85)",
                      }}
                    >
                      {tag}
                    </Text>
                  </View>
                ))}
              </View>
            </View>

            {/* CTA section */}
            <View style={{ gap: 12, paddingBottom: 12 }}>

              {/* Phone button */}
              <AnimatedPressable
                style={[
                  {
                    height: 56,
                    borderRadius: 30,
                    alignItems: "center",
                    justifyContent: "center",
                    flexDirection: "row",
                    gap: 10,
                    overflow: "hidden",
                    shadowColor: "#692ce3",
                    shadowOffset: { width: 0, height: 8 },
                    shadowOpacity: 0.55,
                    shadowRadius: 16,
                    elevation: 10,
                  },
                  phoneAnim,
                ]}
                onPressIn={() => { phoneScale.value = withSpring(0.96, { damping: 14 }); }}
                onPressOut={() => { phoneScale.value = withSpring(1, { damping: 14 }); }}
                onPress={() => router.push("/phone")}
              >
                <Svg
                  style={{ position: "absolute", top: 0, left: 0, right: 0, bottom: 0 }}
                  width="100%"
                  height="100%"
                >
                  <Defs>
                    <SvgGradient id="phoneGrad" x1="0" y1="0" x2="1" y2="0">
                      <Stop offset="0%" stopColor="#692ce3" stopOpacity="1" />
                      <Stop offset="100%" stopColor="#c35de6" stopOpacity="1" />
                    </SvgGradient>
                  </Defs>
                  <Rect x="0" y="0" width="100%" height="100%" fill="url(#phoneGrad)" rx="30" />
                </Svg>
                <Ionicons name="call-outline" size={20} color="#fff" />
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: "#fff", letterSpacing: 0.2 }}>
                  Sign in with Phone Number
                </Text>
              </AnimatedPressable>

              {/* Divider */}
              <View style={{ flexDirection: "row", alignItems: "center", gap: 12, marginVertical: 2 }}>
                <View style={{ flex: 1, height: 1, backgroundColor: "rgba(255,255,255,0.18)" }} />
                <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: "rgba(255,255,255,0.45)" }}>
                  or
                </Text>
                <View style={{ flex: 1, height: 1, backgroundColor: "rgba(255,255,255,0.18)" }} />
              </View>

              {/* Google button */}
              <AnimatedPressable
                style={[
                  {
                    height: 56,
                    borderRadius: 30,
                    alignItems: "center",
                    justifyContent: "center",
                    flexDirection: "row",
                    gap: 10,
                    backgroundColor: "rgba(255,255,255,0.1)",
                    borderWidth: 1.5,
                    borderColor: "rgba(255,255,255,0.25)",
                  },
                  googleAnim,
                ]}
                onPressIn={() => { googleScale.value = withSpring(0.96, { damping: 14 }); }}
                onPressOut={() => { googleScale.value = withSpring(1, { damping: 14 }); }}
                onPress={() => router.push("/email" as any)}
              >
                {/* Google G icon using AntDesign */}
                <View
                  style={{
                    width: 24,
                    height: 24,
                    borderRadius: 12,
                    backgroundColor: "#fff",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <AntDesign name="google" size={15} color="#EA4335" />
                </View>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: "#fff", letterSpacing: 0.2 }}>
                  Continue with Google
                </Text>
              </AnimatedPressable>

              {/* Already have an account */}
              <View style={{ flexDirection: "row", justifyContent: "center", alignItems: "center", gap: 4, marginTop: 6 }}>
                <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: "rgba(255,255,255,0.55)" }}>
                  Already have an account?
                </Text>
                <TouchableOpacity
                  activeOpacity={0.7}
                  onPress={() => router.push("/phone")}
                >
                  <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: "#692ce3" }}>
                    Log in
                  </Text>
                </TouchableOpacity>
              </View>

              {/* Terms */}
              <Text
                style={{
                  fontFamily: "Poppins-Light",
                  fontSize: 11,
                  color: "rgba(255,255,255,0.35)",
                  textAlign: "center",
                  lineHeight: 16,
                  marginTop: 4,
                  paddingBottom: 4,
                }}
              >
                By continuing you agree to our Terms of Service{"\n"}and Privacy Policy
              </Text>
            </View>
          </View>
        </SafeAreaView>
      </VideoBackground>
    </View>
  );
}
