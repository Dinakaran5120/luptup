/**
 * Onboarding flow — shown once after first sign-in.
 * Three steps: Welcome Slides → Terms & Conditions → Create Profile
 *
 * IMAGE FILES REQUIRED in assets/images/:
 *   slide-lesbian.jpg  — lesbian couple (blue hair) photo
 *   slide-gay.jpg      — gay couple (glasses) photo
 *   slide-sunset.jpg   — sunset couple silhouette photo
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { router } from "expo-router";
import React, { useRef, useState } from "react";
import {
  Alert,
  Dimensions,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import Svg, { Defs, LinearGradient as SvgGradient, Rect, Stop } from "react-native-svg";
import { Logo } from "@/components/logo";

export const ONBOARDING_KEY = "luptup_onboarding_done";

const { width, height } = Dimensions.get("window");

// ─── Brand colors ─────────────────────────────────────────────────────────────
const PRIMARY  = "#692ce3";
const BG       = "#0d0d1a";
const CARD_BG  = "rgba(255,255,255,0.06)";
const TEXT     = "#ffffff";
const MUTED    = "rgba(255,255,255,0.55)";
const BORDER   = "rgba(255,255,255,0.12)";

// ─── Slide data (full-background photos) ─────────────────────────────────────
const SLIDES = [
  {
    headline: "Find someone",
    highlight: "who gets you",
    subtitle: "Lup Tup is a safe space for\nmeaningful connections.",
    image: require("../../assets/images/slide-lesbian.jpg"),
  },
  {
    headline: "Love in all",
    highlight: "its beautiful forms",
    subtitle: "We celebrate every kind of\nlove — you belong here.",
    image: require("../../assets/images/slide-gay.jpg"),
  },
  {
    headline: "Your perfect",
    highlight: "connection awaits",
    subtitle: "Thousands of real people are\nwaiting to connect with you.",
    image: require("../../assets/images/slide-sunset.jpg"),
  },
];

// ─── Terms content ────────────────────────────────────────────────────────────
const TERMS = [
  {
    title: "1. Acceptance of Terms",
    body: "By accessing or using Lup Tup, you agree to be bound by these Terms and Conditions.",
  },
  {
    title: "2. User Conduct",
    body: "You agree to use Lup Tup respectfully and lawfully. Harassment, spam, or any abusive behavior is not allowed.",
  },
  {
    title: "3. Privacy",
    body: "Your privacy is important to us. Please review our Privacy Policy to understand how we collect, use, and protect your data.",
  },
  {
    title: "4. Content",
    body: "You are responsible for the content you share. We reserve the right to remove any content that violates our policies.",
  },
  {
    title: "5. Termination",
    body: "We may suspend or terminate your account if you violate these Terms.",
  },
];

// ─── Step 0 — Welcome Slides (full-background swipeable photos) ───────────────
function SlidesStep({ onNext }: { onNext: () => void }) {
  const [slide, setSlide] = useState(0);
  const scrollRef = useRef<ScrollView>(null);

  const goToSlide = (index: number) => {
    scrollRef.current?.scrollTo({ x: index * width, animated: true });
    setSlide(index);
  };

  const handleNext = () => {
    if (slide < SLIDES.length - 1) {
      goToSlide(slide + 1);
    } else {
      onNext();
    }
  };

  const current = SLIDES[slide];

  return (
    <View style={{ flex: 1, backgroundColor: "#000" }}>
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      {/* ── Swipeable full-background photos ── */}
      <ScrollView
        ref={scrollRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        scrollEventThrottle={16}
        onMomentumScrollEnd={(e) => {
          const newSlide = Math.round(e.nativeEvent.contentOffset.x / width);
          setSlide(newSlide);
        }}
        style={StyleSheet.absoluteFillObject}
        contentContainerStyle={{ width: width * SLIDES.length }}
      >
        {SLIDES.map((s, i) => (
          <Image
            key={i}
            source={s.image}
            style={{ width, height: "100%" }}
            contentFit="cover"
          />
        ))}
      </ScrollView>

      {/* ── Top dark gradient ── */}
      <Svg
        style={{ position: "absolute", top: 0, left: 0, right: 0 }}
        width="100%"
        height={220}
      >
        <Defs>
          <SvgGradient id="topG" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0%"   stopColor="#000" stopOpacity="0.72" />
            <Stop offset="100%" stopColor="#000" stopOpacity="0"   />
          </SvgGradient>
        </Defs>
        <Rect width="100%" height={220} fill="url(#topG)" />
      </Svg>

      {/* ── Bottom dark gradient ── */}
      <Svg
        style={{ position: "absolute", bottom: 0, left: 0, right: 0 }}
        width="100%"
        height={420}
      >
        <Defs>
          <SvgGradient id="botG" x1="0" y1="0" x2="0" y2="1">
            <Stop offset="0%"   stopColor="#0d0d1a" stopOpacity="0"   />
            <Stop offset="45%"  stopColor="#0d0d1a" stopOpacity="0.82" />
            <Stop offset="100%" stopColor="#0d0d1a" stopOpacity="1"   />
          </SvgGradient>
        </Defs>
        <Rect width="100%" height={420} fill="url(#botG)" />
      </Svg>

      {/* ── UI overlay ── */}
      <SafeAreaView style={{ flex: 1 }}>
        {/* Top row: Logo + Skip */}
        <View style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
          paddingHorizontal: 24,
          paddingTop: 6,
        }}>
          <Logo variant="white" height={44} />
          <TouchableOpacity activeOpacity={0.7} onPress={onNext} style={{ padding: 8 }}>
            <Text style={{ fontFamily: "Poppins-Medium", fontSize: 15, color: PRIMARY }}>
              Skip
            </Text>
          </TouchableOpacity>
        </View>

        {/* Spacer */}
        <View style={{ flex: 1 }} />

        {/* Bottom text + dots + button */}
        <View style={{ paddingHorizontal: 28, paddingBottom: 36 }}>
          <Text style={{
            fontFamily: "Poppins-Bold",
            fontSize: 32,
            color: TEXT,
            lineHeight: 38,
          }}>
            {current.headline}
          </Text>
          <Text style={{
            fontFamily: "Poppins-Bold",
            fontSize: 32,
            color: PRIMARY,
            lineHeight: 38,
            marginBottom: 10,
          }}>
            {current.highlight}
          </Text>
          <Text style={{
            fontFamily: "Poppins-Light",
            fontSize: 14,
            color: "rgba(255,255,255,0.7)",
            lineHeight: 22,
            marginBottom: 28,
          }}>
            {current.subtitle}
          </Text>

          {/* Dots */}
          <View style={{ flexDirection: "row", justifyContent: "center", gap: 8, marginBottom: 28 }}>
            {SLIDES.map((_, i) => (
              <TouchableOpacity key={i} onPress={() => goToSlide(i)} activeOpacity={0.8}>
                <View style={{
                  width: i === slide ? 24 : 8,
                  height: 8,
                  borderRadius: 4,
                  backgroundColor: i === slide ? PRIMARY : "rgba(255,255,255,0.3)",
                }} />
              </TouchableOpacity>
            ))}
          </View>

          {/* Next / Get Started button */}
          <TouchableOpacity
            activeOpacity={0.88}
            onPress={handleNext}
            style={{
              height: 56,
              borderRadius: 30,
              backgroundColor: PRIMARY,
              alignItems: "center",
              justifyContent: "center",
              shadowColor: PRIMARY,
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.55,
              shadowRadius: 14,
              elevation: 8,
            }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
              {slide === SLIDES.length - 1 ? "Get Started" : "Next"}
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

// ─── Step 1 — Terms & Conditions ─────────────────────────────────────────────
function TermsStep({ onBack, onNext }: { onBack: () => void; onNext: () => void }) {
  const [agreed, setAgreed] = useState(false);

  return (
    <View style={{ flex: 1, backgroundColor: BG }}>
      <StatusBar barStyle="light-content" />
      <SafeAreaView style={{ flex: 1 }}>
        {/* Header */}
        <View style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingVertical: 14,
        }}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={onBack}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          >
            <Ionicons name="chevron-back" size={26} color={PRIMARY} />
          </TouchableOpacity>
          <Text style={{
            flex: 1,
            fontFamily: "Poppins-SemiBold",
            fontSize: 18,
            color: TEXT,
            textAlign: "center",
          }}>
            Terms &amp; Conditions
          </Text>
          <View style={{ width: 26 }} />
        </View>

        {/* Scrollable terms */}
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: 16 }}
          showsVerticalScrollIndicator={false}
        >
          <View style={{
            backgroundColor: CARD_BG,
            borderRadius: 18,
            borderWidth: 1,
            borderColor: BORDER,
            padding: 20,
            gap: 20,
          }}>
            {TERMS.map((section, i) => (
              <View key={i}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: TEXT, marginBottom: 6 }}>
                  {section.title}
                </Text>
                <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: MUTED, lineHeight: 20 }}>
                  {section.body}
                </Text>
                {i < TERMS.length - 1 && (
                  <View style={{ height: 1, backgroundColor: BORDER, marginTop: 20 }} />
                )}
              </View>
            ))}
          </View>
        </ScrollView>

        {/* Footer: checkbox + button */}
        <View style={{
          paddingHorizontal: 20,
          paddingTop: 16,
          paddingBottom: Platform.OS === "ios" ? 24 : 20,
          borderTopWidth: 1,
          borderTopColor: BORDER,
        }}>
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => setAgreed((v) => !v)}
            style={{ flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 16 }}
          >
            <View style={{
              width: 22, height: 22, borderRadius: 6,
              borderWidth: 2,
              borderColor: agreed ? PRIMARY : BORDER,
              backgroundColor: agreed ? PRIMARY : "transparent",
              alignItems: "center", justifyContent: "center",
            }}>
              {agreed && <Ionicons name="checkmark" size={14} color="#fff" />}
            </View>
            <Text style={{ fontFamily: "Poppins-Regular", fontSize: 13, color: MUTED, flex: 1 }}>
              I agree to the{" "}
              <Text style={{ color: PRIMARY, fontFamily: "Poppins-Medium" }}>
                Terms &amp; Conditions
              </Text>
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            activeOpacity={agreed ? 0.85 : 0.5}
            onPress={() => agreed && onNext()}
            style={{
              height: 56,
              borderRadius: 30,
              backgroundColor: agreed ? PRIMARY : "rgba(105,44,227,0.3)",
              alignItems: "center",
              justifyContent: "center",
              shadowColor: agreed ? PRIMARY : "transparent",
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.5,
              shadowRadius: 14,
              elevation: agreed ? 8 : 0,
            }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
              I Agree
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

// ─── Step 2 — Create Profile ──────────────────────────────────────────────────
function CreateProfileStep({ onBack }: { onBack: () => void }) {
  const [bio, setBio] = useState("");
  const MAX_BIO = 500;

  const handleFinish = async () => {
    await AsyncStorage.setItem(ONBOARDING_KEY, "true");
    router.replace("/(app)/(tabs)" as any);
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: BG }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <StatusBar barStyle="light-content" />
      <SafeAreaView style={{ flex: 1 }}>
        {/* Header */}
        <View style={{
          flexDirection: "row",
          alignItems: "center",
          paddingHorizontal: 16,
          paddingVertical: 14,
        }}>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={onBack}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          >
            <Ionicons name="chevron-back" size={26} color={PRIMARY} />
          </TouchableOpacity>
          <View style={{ width: 26 }} />
        </View>

        <ScrollView
          contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 24 }}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Text style={{
            fontFamily: "Poppins-Bold",
            fontSize: 26,
            color: TEXT,
            textAlign: "center",
            marginBottom: 8,
          }}>
            Create your profile
          </Text>
          <Text style={{
            fontFamily: "Poppins-Light",
            fontSize: 13,
            color: MUTED,
            textAlign: "center",
            lineHeight: 20,
            marginBottom: 36,
          }}>
            Add photos and a bio to help others{"\n"}know the real you.
          </Text>

          {/* Photo upload circle */}
          <View style={{ alignItems: "center", marginBottom: 36 }}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => Alert.alert("Add Photos", "Photo upload coming soon!")}
              style={{
                width: 150, height: 150, borderRadius: 75,
                borderWidth: 2.5, borderColor: PRIMARY, borderStyle: "dashed",
                alignItems: "center", justifyContent: "center",
                backgroundColor: "rgba(105,44,227,0.08)",
                gap: 6,
              }}
            >
              <Ionicons name="add" size={40} color={PRIMARY} />
              <Text style={{ fontFamily: "Poppins-Medium", fontSize: 14, color: TEXT }}>
                Add photos
              </Text>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: MUTED }}>
                0 / 6
              </Text>
            </TouchableOpacity>
          </View>

          {/* About me */}
          <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: TEXT, marginBottom: 12 }}>
            About me
          </Text>
          <View style={{
            backgroundColor: CARD_BG,
            borderRadius: 16,
            borderWidth: 1,
            borderColor: BORDER,
            padding: 16,
            minHeight: 120,
          }}>
            <TextInput
              value={bio}
              onChangeText={(t) => setBio(t.slice(0, MAX_BIO))}
              placeholder="Write something about yourself..."
              placeholderTextColor={MUTED}
              multiline
              style={{
                fontFamily: "Poppins-Regular",
                fontSize: 14,
                color: TEXT,
                flex: 1,
                minHeight: 80,
                textAlignVertical: "top",
              }}
            />
            <Text style={{
              fontFamily: "Poppins-Light",
              fontSize: 11,
              color: MUTED,
              textAlign: "right",
              marginTop: 8,
            }}>
              {bio.length}/{MAX_BIO}
            </Text>
          </View>
          <View style={{ height: 32 }} />
        </ScrollView>

        {/* Let's go button */}
        <View style={{
          paddingHorizontal: 24,
          paddingBottom: Platform.OS === "ios" ? 24 : 20,
          paddingTop: 12,
          borderTopWidth: 1,
          borderTopColor: BORDER,
        }}>
          <TouchableOpacity
            activeOpacity={0.85}
            onPress={handleFinish}
            style={{
              height: 56,
              borderRadius: 30,
              backgroundColor: PRIMARY,
              alignItems: "center",
              justifyContent: "center",
              shadowColor: PRIMARY,
              shadowOffset: { width: 0, height: 8 },
              shadowOpacity: 0.5,
              shadowRadius: 14,
              elevation: 8,
            }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
              Let's go!
            </Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </KeyboardAvoidingView>
  );
}

// ─── Root Onboarding Screen ───────────────────────────────────────────────────
type Step = "slides" | "terms" | "profile";

export default function OnboardingScreen() {
  const [step, setStep] = useState<Step>("slides");

  if (step === "slides") return <SlidesStep onNext={() => setStep("terms")} />;
  if (step === "terms")  return <TermsStep  onBack={() => setStep("slides")} onNext={() => setStep("profile")} />;
  return <CreateProfileStep onBack={() => setStep("terms")} />;
}
