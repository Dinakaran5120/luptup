import { useTheme } from "@/context/theme";
import { Logo } from "@/components/logo";
import { supabase } from "@/lib/supabase";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  TouchableOpacity,
  View,
} from "react-native";
import { Text } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

// ─── TopNav ───────────────────────────────────────────────────────────────────

interface Props {
  showNotification?: boolean;
  showCoins?: boolean;
  onNotificationPress?: () => void;
}

export const TopNav: React.FC<Props> = ({
  showNotification = true,
  showCoins = true,
  onNotificationPress,
}) => {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const [coins] = useState(1542);

  return (
    <View style={{
      paddingTop: insets.top,
      backgroundColor: colors.background,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    }}>
      <View style={{
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingHorizontal: 16,
        paddingVertical: 10,
      }}>
        {/* Logo image — switches between color/white based on theme */}
        <Logo variant="auto" height={38} />

        {/* Right controls */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>

          {/* Coins pill */}
          {showCoins && (
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => router.push("/premium" as any)}
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 5,
                backgroundColor: colors.surface,
                borderRadius: 20,
                paddingHorizontal: 10,
                paddingVertical: 5,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <View style={{
                width: 20,
                height: 20,
                borderRadius: 10,
                backgroundColor: "#f59e0b",
                alignItems: "center",
                justifyContent: "center",
              }}>
                <Ionicons name="star" size={11} color="#fff" />
              </View>
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: colors.text }}>
                {coins.toLocaleString()}
              </Text>
              <View style={{
                width: 18,
                height: 18,
                borderRadius: 9,
                backgroundColor: "#692ce3",
                alignItems: "center",
                justifyContent: "center",
              }}>
                <Ionicons name="add" size={12} color="#fff" />
              </View>
            </TouchableOpacity>
          )}

          {/* Notification bell */}
          {showNotification && (
            <View style={{ position: "relative" }}>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={onNotificationPress ?? (() => router.push("/notifications" as any))}
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: 18,
                  backgroundColor: colors.surface,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Ionicons name="notifications-outline" size={18} color={colors.icon} />
              </TouchableOpacity>
              {/* Red dot */}
              <View style={{
                position: "absolute",
                top: 5,
                right: 5,
                width: 8,
                height: 8,
                borderRadius: 4,
                backgroundColor: "#ef4444",
                borderWidth: 1.5,
                borderColor: colors.background,
                pointerEvents: "none",
              }} />
            </View>
          )}

          {/* Account icon — navigates directly to profile/account screen */}
          <TouchableOpacity
            activeOpacity={0.8}
            onPress={() => router.push("/hinge" as any)}
            style={{
              width: 36,
              height: 36,
              borderRadius: 18,
              backgroundColor: colors.surface,
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Ionicons name="person-circle-outline" size={22} color={colors.icon} />
          </TouchableOpacity>

        </View>
      </View>
    </View>
  );
};
