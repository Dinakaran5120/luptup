/**
 * Reusable Logo component.
 * - variant="auto"  → purple-gradient logo on light theme, white logo on dark theme
 * - variant="color" → always purple-gradient logo
 * - variant="white" → always white logo (use on dark/photo backgrounds)
 *
 * IMAGE FILES REQUIRED in assets/images/:
 *   logo-color.png  — the purple gradient "Lup Tup" logo (use on light bg)
 *   logo-white.png  — the white outline "Lup Tup" logo (use on dark bg)
 */
import { useTheme } from "@/context/theme";
import { Image } from "expo-image";
import React from "react";
import { View } from "react-native";

const LOGO_COLOR = require("../../assets/images/logo-color.png");
const LOGO_WHITE = require("../../assets/images/logo-white.png");

interface LogoProps {
  /** Rendered height in dp; width scales automatically (aspect ratio ~2.8:1) */
  height?: number;
  variant?: "auto" | "color" | "white";
}

export const Logo: React.FC<LogoProps> = ({ height = 42, variant = "auto" }) => {
  const { isDark } = useTheme();

  const source =
    variant === "color"
      ? LOGO_COLOR
      : variant === "white"
      ? LOGO_WHITE
      : isDark
      ? LOGO_WHITE
      : LOGO_COLOR;

  return (
    <View style={{ height, width: Math.round(height * 2.85), justifyContent: "center" }}>
      <Image
        source={source}
        style={{ width: "100%", height: "100%" }}
        contentFit="contain"
        transition={200}
      />
    </View>
  );
};
