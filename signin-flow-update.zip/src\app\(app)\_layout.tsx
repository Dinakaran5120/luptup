import { useAuth } from "@/store/auth";
import { EditProvider } from "@/store/edit";
import { Loader } from "@/components/loader";
import { Redirect, Stack } from "expo-router";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useState } from "react";

export const ONBOARDING_KEY = "luptup_onboarding_done";

export default function Layout() {
  const { session, isLoading } = useAuth();
  const [onboardingDone, setOnboardingDone] = useState<boolean | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(ONBOARDING_KEY).then((val) => {
      setOnboardingDone(!!val);
    });
  }, []);

  if (isLoading || onboardingDone === null) {
    return <Loader />;
  }

  if (!session) {
    return <Redirect href={"/sign-in"} />;
  }

  if (!onboardingDone) {
    return <Redirect href={"/onboarding" as any} />;
  }

  return (
    <EditProvider>
      <Stack
        screenOptions={{
          headerShown: false,
        }}
      >
        <Stack.Screen name="(tabs)" options={{ animation: "none" }} />
        <Stack.Screen
          name="settings"
          options={{ animation: "slide_from_bottom" }}
        />
        <Stack.Screen
          name="profile"
          options={{ animation: "slide_from_bottom" }}
        />
        <Stack.Screen
          name="write-answer"
          options={{ animation: "slide_from_bottom" }}
        />
        <Stack.Screen
          name="prompts"
          options={{ animation: "slide_from_bottom" }}
        />
        <Stack.Screen
          name="preferences"
          options={{ animation: "slide_from_bottom" }}
        />
        <Stack.Screen
          name="user"
          options={{ animation: "slide_from_right" }}
        />
        <Stack.Screen
          name="notifications"
          options={{ animation: "slide_from_right" }}
        />
        <Stack.Screen
          name="premium"
          options={{ animation: "slide_from_bottom" }}
        />
      </Stack>
    </EditProvider>
  );
}
