import { supabase } from "@/lib/supabase";
import { useMutation } from "@tanstack/react-query";

export const useSignInWithOtp = () => {
  return useMutation({
    mutationFn: async (phone: string) => {
      let { error } = await supabase.auth.signInWithOtp({
        phone,
      });

      if (error) {
        let message = "Something went wrong, please try again later.";

        switch (error.code) {
          case "sms_send_failed":
            message =
              "Please ensure your phone number is correct and try again.";
            break;
          case "over_sms_send_rate_limit":
            message = "Too many attempts. Please try again later.";
            break;
        }
        throw new Error(message);
      }
    },
  });
};

export const useVerifyOtp = () => {
  return useMutation({
    mutationFn: async ({ phone, token }: { phone: string; token: string }) => {
      let { error } = await supabase.auth.verifyOtp({
        phone,
        token,
        type: "sms",
      });

      if (error) {
        let message = "Something went wrong, please try again later.";

        switch (error.code) {
          case "otp_expired":
            message = "Your code is either invalid or expired.";
            break;
        }
        throw new Error(message);
      }
    },
  });
};

export const useSignInWithEmailOtp = () => {
  return useMutation({
    mutationFn: async (email: string) => {
      // Mock: simulate email sending delay
      await new Promise((r) => setTimeout(r, 1000));
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        throw new Error("Please enter a valid email address.");
      }
      return { error: null };
    },
  });
};

export const useVerifyEmailOtp = () => {
  return useMutation({
    mutationFn: async ({ email, token }: { email: string; token: string }) => {
      await new Promise((r) => setTimeout(r, 1000));
      if (token.length !== 6 || !/^\d{6}$/.test(token)) {
        throw new Error("Your code is either invalid or expired.");
      }
      // Build a mock session for email login
      const { supabase } = await import("@/lib/supabase");
      await (supabase as any).auth.verifyOtp({
        phone: email,
        token,
        type: "sms",
      });
      return { error: null };
    },
  });
};

export const useSignOut = () => {
  return useMutation({
    mutationFn: async () => {
      let { error } = await supabase.auth.signOut();

      if (error) {
        throw new Error(error.message);
      }
    },
  });
};
