import { useAuth } from "@/store/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Redirect, Stack } from "expo-router";
import { useEffect, useState } from "react";

const ONBOARDING_KEY = "luptup_onboarding_done";

export default function Layout() {
  const { session } = useAuth();
  const [onboardingDone, setOnboardingDone] = useState<boolean | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(ONBOARDING_KEY).then((val) => {
      setOnboardingDone(!!val);
    });
  }, []);

  if (session) {
    if (onboardingDone === null) return null;

    if (!onboardingDone) {
      return <Redirect href={"/onboarding" as any} />;
    }

    return <Redirect href={"/(app)/(tabs)" as any} />;
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="sign-in" options={{ headerShown: false }} />
      <Stack.Screen name="phone" options={{ headerShown: true, title: "" }} />
      <Stack.Screen name="otp" options={{ headerShown: true, title: "" }} />
      <Stack.Screen name="email" options={{ headerShown: true, title: "" }} />
      <Stack.Screen name="email-otp" options={{ headerShown: true, title: "" }} />
    </Stack>
  );
}
