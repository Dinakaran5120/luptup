import { useMyProfile } from "@/api/my-profile";
import { useTheme } from "@/context/theme";
import { supabase } from "@/lib/supabase";
import { Logo } from "@/components/logo";
import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { router, Stack } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Modal,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Svg, { Defs, LinearGradient as SvgGradient, Rect, Stop } from "react-native-svg";

const PRIMARY = "#692ce3";
const DARKER_PURPLE = "#3d1882";

// ─── Report Tags ───────────────────────────────────────────────────────────────
const REPORT_TAGS = [
  "Inappropriate Content",
  "Harassment",
  "Spam",
  "Fake Profile",
  "Scam",
  "Offensive Language",
  "Other",
];

// ─── Toggle Switch ─────────────────────────────────────────────────────────────
function Toggle({
  value,
  onToggle,
  colors,
}: {
  value: boolean;
  onToggle: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
}) {
  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onToggle}
      style={{
        width: 44,
        height: 24,
        borderRadius: 12,
        backgroundColor: value ? PRIMARY : colors.border,
        justifyContent: "center",
        paddingHorizontal: 2,
        alignItems: value ? "flex-end" : "flex-start",
      }}
    >
      <View
        style={{
          width: 20,
          height: 20,
          borderRadius: 10,
          backgroundColor: "#fff",
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.2,
          shadowRadius: 2,
          elevation: 2,
        }}
      />
    </TouchableOpacity>
  );
}

// ─── Menu Row ─────────────────────────────────────────────────────────────────
function MenuRow({
  icon,
  label,
  subtitle,
  onPress,
  colors,
  destructive,
}: {
  icon: string;
  label: string;
  subtitle?: string;
  onPress: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
  destructive?: boolean;
}) {
  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={onPress}
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 14,
        paddingVertical: 14,
        paddingHorizontal: 20,
      }}
    >
      <View
        style={{
          width: 44,
          height: 44,
          borderRadius: 14,
          backgroundColor: destructive ? "rgba(239,68,68,0.12)" : colors.surfaceAlt,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Ionicons
          name={icon as any}
          size={20}
          color={destructive ? "#ef4444" : colors.primary}
        />
      </View>
      <View style={{ flex: 1, gap: 1 }}>
        <Text
          style={{
            fontFamily: "Poppins-Medium",
            fontSize: 15,
            color: destructive ? "#ef4444" : colors.text,
          }}
        >
          {label}
        </Text>
        {subtitle && (
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 12,
              color: colors.textMuted,
            }}
          >
            {subtitle}
          </Text>
        )}
      </View>
      <Ionicons name="chevron-forward" size={16} color={colors.iconMuted} />
    </TouchableOpacity>
  );
}

// ─── Section Title ─────────────────────────────────────────────────────────────
function SectionTitle({
  label,
  colors,
}: {
  label: string;
  colors: ReturnType<typeof useTheme>["colors"];
}) {
  return (
    <Text
      style={{
        fontFamily: "Poppins-SemiBold",
        fontSize: 11,
        color: colors.textMuted,
        textTransform: "uppercase",
        letterSpacing: 1,
        paddingHorizontal: 20,
        paddingTop: 18,
        paddingBottom: 6,
      }}
    >
      {label}
    </Text>
  );
}

// ─── Card Divider ─────────────────────────────────────────────────────────────
function Divider({ colors }: { colors: ReturnType<typeof useTheme>["colors"] }) {
  return (
    <View
      style={{
        height: 1,
        backgroundColor: colors.border,
        marginLeft: 78,
      }}
    />
  );
}

// ─── Section Card ─────────────────────────────────────────────────────────────
function SectionCard({
  children,
  colors,
  marginTop,
}: {
  children: React.ReactNode;
  colors: ReturnType<typeof useTheme>["colors"];
  marginTop?: number;
}) {
  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        marginHorizontal: 16,
        marginTop: marginTop ?? 12,
        borderWidth: 1,
        borderColor: colors.border,
        overflow: "hidden",
      }}
    >
      {children}
    </View>
  );
}

// ─── Report Modal ─────────────────────────────────────────────────────────────
function ReportModal({
  visible,
  onClose,
  colors,
}: {
  visible: boolean;
  onClose: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
}) {
  const [reportTags, setReportTags] = useState<string[]>([]);

  const toggleTag = (tag: string) => {
    setReportTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = () => {
    Alert.alert("Thank you for your report.", "We'll look into this promptly.");
    setReportTags([]);
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent
      onRequestClose={onClose}
    >
      {/* Backdrop */}
      <TouchableOpacity
        activeOpacity={1}
        onPress={onClose}
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.5)",
          justifyContent: "flex-end",
        }}
      >
        {/* Sheet */}
        <TouchableOpacity
          activeOpacity={1}
          style={{
            backgroundColor: colors.surface,
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
            padding: 24,
            paddingBottom: 36,
          }}
        >
          <Text
            style={{
              fontFamily: "Poppins-Bold",
              fontSize: 18,
              color: colors.text,
              marginBottom: 16,
            }}
          >
            Report a Problem
          </Text>

          {/* Tags */}
          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
            {REPORT_TAGS.map((tag) => {
              const isSelected = reportTags.includes(tag);
              return (
                <TouchableOpacity
                  key={tag}
                  activeOpacity={0.75}
                  onPress={() => toggleTag(tag)}
                  style={{
                    backgroundColor: isSelected ? PRIMARY : colors.surfaceAlt,
                    borderWidth: 1,
                    borderColor: isSelected ? PRIMARY : colors.border,
                    borderRadius: 20,
                    paddingHorizontal: 14,
                    paddingVertical: 8,
                  }}
                >
                  <Text
                    style={{
                      fontFamily: "Poppins-Medium",
                      fontSize: 13,
                      color: isSelected ? "#fff" : colors.textMuted,
                    }}
                  >
                    {tag}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Submit */}
          <TouchableOpacity
            activeOpacity={reportTags.length > 0 ? 0.85 : 0.5}
            onPress={reportTags.length > 0 ? handleSubmit : undefined}
            style={{
              height: 52,
              borderRadius: 26,
              backgroundColor: reportTags.length > 0 ? PRIMARY : "rgba(105,44,227,0.3)",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
              Submit Report
            </Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

// ─── Main Page ─────────────────────────────────────────────────────────────────
export default function HingePage() {
  const { data: profile } = useMyProfile();
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const [showReport, setShowReport] = useState(false);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.replace("/sign-in" as any);
  };

  const handleDeactivate = () => {
    Alert.alert(
      "Deactivate Account",
      "Are you sure? You can reactivate anytime.",
      [
        { text: "Cancel", style: "cancel" },
        { text: "Deactivate", style: "destructive", onPress: () => {} },
      ]
    );
  };

  const INTERESTS_LIST = ["🌍 Travel", "🎵 Music", "💃 Dancing", "💪 Fitness", "🎬 Movies"];

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Stack.Screen options={{ headerShown: false }} />
      <StatusBar barStyle="light-content" translucent backgroundColor="transparent" />

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* ── Header with purple gradient ── */}
        <View style={{ height: 200 + insets.top }}>
          {/* SVG gradient background */}
          <Svg
            style={StyleSheet.absoluteFillObject}
            width="100%"
            height="100%"
          >
            <Defs>
              <SvgGradient id="headerGrad" x1="0" y1="0" x2="0" y2="1">
                <Stop offset="0%" stopColor={PRIMARY} stopOpacity="1" />
                <Stop offset="100%" stopColor={DARKER_PURPLE} stopOpacity="1" />
              </SvgGradient>
            </Defs>
            <Rect width="100%" height="100%" fill="url(#headerGrad)" />
          </Svg>

          {/* Nav row */}
          <View
            style={{
              position: "absolute",
              top: insets.top + 8,
              left: 0,
              right: 0,
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
              paddingHorizontal: 20,
            }}
          >
            <Logo variant="white" height={36} />
            <View style={{ flexDirection: "row", gap: 10 }}>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => router.push("/profile" as any)}
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 19,
                  backgroundColor: "rgba(255,255,255,0.2)",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Ionicons name="create-outline" size={19} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => router.push("/settings" as any)}
                style={{
                  width: 38,
                  height: 38,
                  borderRadius: 19,
                  backgroundColor: "rgba(255,255,255,0.2)",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Ionicons name="settings-outline" size={19} color="#fff" />
              </TouchableOpacity>
            </View>
          </View>
        </View>

        {/* ── Profile card (overlaps header by -24) ── */}
        <View
          style={{
            backgroundColor: colors.background,
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
            marginTop: -24,
            paddingHorizontal: 20,
            paddingTop: 24,
          }}
        >
          {/* Avatar */}
          <View style={{ alignItems: "center", marginTop: -72, marginBottom: 12 }}>
            <View
              style={{
                width: 96,
                height: 96,
                borderRadius: 48,
                borderWidth: 3,
                borderColor: PRIMARY,
                backgroundColor: colors.surface,
                shadowColor: PRIMARY,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.3,
                shadowRadius: 8,
                elevation: 6,
                overflow: "hidden",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              {profile?.avatar_url ? (
                <Image
                  source={profile.avatar_url}
                  style={{ width: "100%", height: "100%" }}
                  contentFit="cover"
                />
              ) : (
                <Ionicons name="person" size={48} color={colors.iconMuted} />
              )}
            </View>
          </View>

          {/* Name + location */}
          <View style={{ alignItems: "center", marginBottom: 12 }}>
            <Text
              style={{
                fontFamily: "Poppins-Bold",
                fontSize: 20,
                color: colors.text,
                marginBottom: 4,
              }}
            >
              {profile?.first_name ?? "Anaya"}
            </Text>
            <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
              <Ionicons name="location-outline" size={14} color={colors.textMuted} />
              <Text
                style={{
                  fontFamily: "Poppins-Light",
                  fontSize: 13,
                  color: colors.textMuted,
                }}
              >
                {profile?.neighborhood ?? "Mumbai, Maharashtra"}
              </Text>
            </View>
          </View>

          {/* Edit Profile button */}
          <View style={{ alignItems: "center", marginBottom: 20 }}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => router.push("/profile" as any)}
              style={{
                borderWidth: 1.5,
                borderColor: PRIMARY,
                borderRadius: 20,
                paddingHorizontal: 24,
                paddingVertical: 8,
              }}
            >
              <Text
                style={{
                  fontFamily: "Poppins-SemiBold",
                  fontSize: 14,
                  color: PRIMARY,
                }}
              >
                Edit Profile
              </Text>
            </TouchableOpacity>
          </View>

          {/* Stats row */}
          <View
            style={{
              flexDirection: "row",
              borderRadius: 18,
              backgroundColor: colors.surface,
              borderWidth: 1,
              borderColor: colors.border,
              overflow: "hidden",
              marginBottom: 8,
            }}
          >
            {[
              { label: "Likes", value: "12" },
              { label: "Matches", value: "4" },
              { label: "Views", value: "38" },
            ].map((stat, i, arr) => (
              <View
                key={stat.label}
                style={{
                  flex: 1,
                  alignItems: "center",
                  paddingVertical: 16,
                  borderRightWidth: i < arr.length - 1 ? 1 : 0,
                  borderRightColor: colors.border,
                }}
              >
                <Text
                  style={{
                    fontFamily: "Poppins-Bold",
                    fontSize: 22,
                    color: colors.primary,
                  }}
                >
                  {stat.value}
                </Text>
                <Text
                  style={{
                    fontFamily: "Poppins-Light",
                    fontSize: 12,
                    color: colors.textMuted,
                  }}
                >
                  {stat.label}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* ── Profile Details ── */}
        <SectionCard colors={colors} marginTop={16}>
          <SectionTitle label="MY PROFILE" colors={colors} />
          <View style={{ height: 1, backgroundColor: colors.border }} />
          {[
            { icon: "person-outline", label: "Looking For", subtitle: "Men, Women" },
            { icon: "heart-outline", label: "Orientation", subtitle: "Bisexual" },
            { icon: "body-outline", label: "Body Type", subtitle: "Athletic" },
            { icon: "calendar-outline", label: "Age Range", subtitle: "18 - 35" },
          ].map((row, i, arr) => (
            <React.Fragment key={row.label}>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 14,
                  paddingVertical: 14,
                  paddingHorizontal: 20,
                }}
              >
                <View
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 14,
                    backgroundColor: colors.surfaceAlt,
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Ionicons name={row.icon as any} size={20} color={colors.primary} />
                </View>
                <View style={{ flex: 1, gap: 1 }}>
                  <Text
                    style={{
                      fontFamily: "Poppins-Medium",
                      fontSize: 15,
                      color: colors.text,
                    }}
                  >
                    {row.label}
                  </Text>
                  <Text
                    style={{
                      fontFamily: "Poppins-Light",
                      fontSize: 12,
                      color: colors.textMuted,
                    }}
                  >
                    {row.subtitle}
                  </Text>
                </View>
              </View>
              {i < arr.length - 1 && <Divider colors={colors} />}
            </React.Fragment>
          ))}
        </SectionCard>

        {/* ── Interests ── */}
        <SectionCard colors={colors}>
          <SectionTitle label="INTERESTS" colors={colors} />
          <View
            style={{
              flexDirection: "row",
              flexWrap: "wrap",
              paddingHorizontal: 16,
              paddingBottom: 16,
              gap: 8,
            }}
          >
            {INTERESTS_LIST.map((interest) => (
              <View
                key={interest}
                style={{
                  backgroundColor: colors.surfaceAlt,
                  borderWidth: 1,
                  borderColor: colors.border,
                  borderRadius: 20,
                  paddingHorizontal: 12,
                  paddingVertical: 6,
                }}
              >
                <Text
                  style={{
                    fontFamily: "Poppins-Medium",
                    fontSize: 13,
                    color: colors.primary,
                  }}
                >
                  {interest}
                </Text>
              </View>
            ))}
          </View>
        </SectionCard>

        {/* ── About Me ── */}
        <SectionCard colors={colors}>
          <SectionTitle label="ABOUT ME" colors={colors} />
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 14,
              color: colors.textMuted,
              paddingHorizontal: 20,
              paddingBottom: 20,
              lineHeight: 22,
            }}
          >
            Living life one adventure at a time. Love exploring new places and connecting with genuine people. Let's see where this goes! ✨
          </Text>
        </SectionCard>

        {/* ── Privacy & Settings ── */}
        <SectionCard colors={colors}>
          <SectionTitle label="PRIVACY & SETTINGS" colors={colors} />
          <Divider colors={colors} />
          <MenuRow
            icon="shield-outline"
            label="Privacy Settings"
            subtitle="Notifications, theme, visibility"
            onPress={() => router.push("/settings" as any)}
            colors={colors}
          />
          <Divider colors={colors} />
          <MenuRow
            icon="ban-outline"
            label="Blocked Profiles"
            subtitle="Manage blocked users"
            onPress={() => router.push("/settings" as any)}
            colors={colors}
          />
          <Divider colors={colors} />
          <MenuRow
            icon="archive-outline"
            label="Archived Profiles"
            subtitle="View archived matches"
            onPress={() => router.push("/settings" as any)}
            colors={colors}
          />
        </SectionCard>

        {/* ── Support ── */}
        <SectionCard colors={colors}>
          <SectionTitle label="SUPPORT" colors={colors} />
          <Divider colors={colors} />
          <MenuRow
            icon="chatbubble-ellipses-outline"
            label="Contact Us"
            subtitle="We're here to help"
            onPress={() => Alert.alert("Coming soon")}
            colors={colors}
          />
          <Divider colors={colors} />
          <MenuRow
            icon="flag-outline"
            label="Report a Problem"
            onPress={() => setShowReport(true)}
            colors={colors}
          />
          <Divider colors={colors} />
          <MenuRow
            icon="help-circle-outline"
            label="Help Center"
            onPress={() =>
              Alert.alert("Help Center", "Choose a topic:", [
                { text: "Privacy Policy" },
                { text: "Safety & Reporting" },
                { text: "Community Guidelines" },
                { text: "Close", style: "cancel" },
              ])
            }
            colors={colors}
          />
          <Divider colors={colors} />
          <MenuRow
            icon="information-circle-outline"
            label="About Lup Tup"
            subtitle="Version 1.0.0 • Made with ❤️"
            onPress={() =>
              Alert.alert(
                "About Lup Tup",
                "Lup Tup is a safe, inclusive dating app built for everyone. Version 1.0.0 — Made with ❤️ in India."
              )
            }
            colors={colors}
          />
          <Divider colors={colors} />
          <MenuRow
            icon="star-outline"
            label="Feedback"
            subtitle="Share your thoughts"
            onPress={() => Alert.alert("Thank you for your feedback!")}
            colors={colors}
          />
        </SectionCard>

        {/* ── Deactivate ── */}
        <SectionCard colors={colors}>
          <MenuRow
            icon="power-outline"
            label="Deactivate Account"
            onPress={handleDeactivate}
            colors={colors}
            destructive
          />
        </SectionCard>

        {/* ── Logout button ── */}
        <TouchableOpacity
          activeOpacity={0.85}
          onPress={handleLogout}
          style={{
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            marginHorizontal: 16,
            marginTop: 12,
            height: 52,
            borderRadius: 26,
            backgroundColor: "#ef4444",
          }}
        >
          <Ionicons name="log-out-outline" size={20} color="#fff" />
          <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
            Log Out
          </Text>
        </TouchableOpacity>

        <View style={{ height: 120 }} />
      </ScrollView>

      {/* ── Report Modal ── */}
      <ReportModal
        visible={showReport}
        onClose={() => setShowReport(false)}
        colors={colors}
      />
    </View>
  );
}
