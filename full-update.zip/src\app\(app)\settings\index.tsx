import { useTheme } from "@/context/theme";
import { supabase } from "@/lib/supabase";
import { Ionicons } from "@expo/vector-icons";
import { router, Stack } from "expo-router";
import React, { useState } from "react";
import {
  Alert,
  Modal,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const PRIMARY = "#692ce3";

// ─── Report Tags ───────────────────────────────────────────────────────────────
const REPORT_TAGS = [
  "Inappropriate Content",
  "Harassment",
  "Spam",
  "Fake Profile",
  "Scam",
  "Offensive Language",
  "Other",
];

// ─── Custom Toggle ─────────────────────────────────────────────────────────────
function Toggle({
  value,
  onToggle,
  colors,
}: {
  value: boolean;
  onToggle: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
}) {
  return (
    <TouchableOpacity
      activeOpacity={0.8}
      onPress={onToggle}
      style={{
        width: 44,
        height: 24,
        borderRadius: 12,
        backgroundColor: value ? PRIMARY : colors.border,
        justifyContent: "center",
        paddingHorizontal: 2,
        alignItems: value ? "flex-end" : "flex-start",
      }}
    >
      <View
        style={{
          width: 20,
          height: 20,
          borderRadius: 10,
          backgroundColor: "#fff",
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.2,
          shadowRadius: 2,
          elevation: 2,
        }}
      />
    </TouchableOpacity>
  );
}

// ─── Toggle Row ────────────────────────────────────────────────────────────────
function ToggleRow({
  icon,
  label,
  subtitle,
  value,
  onToggle,
  colors,
}: {
  icon: string;
  label: string;
  subtitle?: string;
  value: boolean;
  onToggle: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
}) {
  return (
    <View
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 14,
        paddingVertical: 14,
        paddingHorizontal: 20,
      }}
    >
      <View
        style={{
          width: 44,
          height: 44,
          borderRadius: 14,
          backgroundColor: colors.surfaceAlt,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Ionicons name={icon as any} size={20} color={PRIMARY} />
      </View>
      <View style={{ flex: 1, gap: 1 }}>
        <Text
          style={{
            fontFamily: "Poppins-Medium",
            fontSize: 15,
            color: colors.text,
          }}
        >
          {label}
        </Text>
        {subtitle && (
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 12,
              color: colors.textMuted,
            }}
          >
            {subtitle}
          </Text>
        )}
      </View>
      <Toggle value={value} onToggle={onToggle} colors={colors} />
    </View>
  );
}

// ─── Nav Row ───────────────────────────────────────────────────────────────────
function NavRow({
  icon,
  label,
  subtitle,
  onPress,
  colors,
  destructive,
}: {
  icon: string;
  label: string;
  subtitle?: string;
  onPress: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
  destructive?: boolean;
}) {
  return (
    <TouchableOpacity
      activeOpacity={0.7}
      onPress={onPress}
      style={{
        flexDirection: "row",
        alignItems: "center",
        gap: 14,
        paddingVertical: 14,
        paddingHorizontal: 20,
      }}
    >
      <View
        style={{
          width: 44,
          height: 44,
          borderRadius: 14,
          backgroundColor: destructive ? "rgba(239,68,68,0.12)" : colors.surfaceAlt,
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Ionicons
          name={icon as any}
          size={20}
          color={destructive ? "#ef4444" : PRIMARY}
        />
      </View>
      <View style={{ flex: 1, gap: 1 }}>
        <Text
          style={{
            fontFamily: "Poppins-Medium",
            fontSize: 15,
            color: destructive ? "#ef4444" : colors.text,
          }}
        >
          {label}
        </Text>
        {subtitle && (
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 12,
              color: colors.textMuted,
            }}
          >
            {subtitle}
          </Text>
        )}
      </View>
      <Ionicons name="chevron-forward" size={16} color={colors.iconMuted} />
    </TouchableOpacity>
  );
}

// ─── Divider ───────────────────────────────────────────────────────────────────
function Divider({ colors }: { colors: ReturnType<typeof useTheme>["colors"] }) {
  return (
    <View
      style={{
        height: 1,
        backgroundColor: colors.border,
        marginLeft: 78,
      }}
    />
  );
}

// ─── Section Card ─────────────────────────────────────────────────────────────
function SectionCard({
  title,
  children,
  colors,
  marginTop,
}: {
  title?: string;
  children: React.ReactNode;
  colors: ReturnType<typeof useTheme>["colors"];
  marginTop?: number;
}) {
  return (
    <View
      style={{
        backgroundColor: colors.surface,
        borderRadius: 16,
        marginHorizontal: 16,
        marginTop: marginTop ?? 12,
        borderWidth: 1,
        borderColor: colors.border,
        overflow: "hidden",
      }}
    >
      {title && (
        <Text
          style={{
            fontFamily: "Poppins-SemiBold",
            fontSize: 11,
            color: colors.textMuted,
            textTransform: "uppercase",
            letterSpacing: 1,
            paddingHorizontal: 20,
            paddingTop: 18,
            paddingBottom: 6,
          }}
        >
          {title}
        </Text>
      )}
      {children}
    </View>
  );
}

// ─── Report Modal ─────────────────────────────────────────────────────────────
function ReportModal({
  visible,
  onClose,
  colors,
}: {
  visible: boolean;
  onClose: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
}) {
  const [reportTags, setReportTags] = useState<string[]>([]);

  const toggleTag = (tag: string) => {
    setReportTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = () => {
    Alert.alert("Thank you for your report.", "We'll look into this promptly.");
    setReportTags([]);
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent
      onRequestClose={onClose}
    >
      <TouchableOpacity
        activeOpacity={1}
        onPress={onClose}
        style={{
          flex: 1,
          backgroundColor: "rgba(0,0,0,0.5)",
          justifyContent: "flex-end",
        }}
      >
        <TouchableOpacity
          activeOpacity={1}
          style={{
            backgroundColor: colors.surface,
            borderTopLeftRadius: 24,
            borderTopRightRadius: 24,
            padding: 24,
            paddingBottom: 40,
          }}
        >
          <Text
            style={{
              fontFamily: "Poppins-Bold",
              fontSize: 18,
              color: colors.text,
              marginBottom: 16,
            }}
          >
            Report a Problem
          </Text>

          <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
            {REPORT_TAGS.map((tag) => {
              const isSelected = reportTags.includes(tag);
              return (
                <TouchableOpacity
                  key={tag}
                  activeOpacity={0.75}
                  onPress={() => toggleTag(tag)}
                  style={{
                    backgroundColor: isSelected ? PRIMARY : colors.surfaceAlt,
                    borderWidth: 1,
                    borderColor: isSelected ? PRIMARY : colors.border,
                    borderRadius: 20,
                    paddingHorizontal: 14,
                    paddingVertical: 8,
                  }}
                >
                  <Text
                    style={{
                      fontFamily: "Poppins-Medium",
                      fontSize: 13,
                      color: isSelected ? "#fff" : colors.textMuted,
                    }}
                  >
                    {tag}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </View>

          <TouchableOpacity
            activeOpacity={reportTags.length > 0 ? 0.85 : 0.5}
            onPress={reportTags.length > 0 ? handleSubmit : undefined}
            style={{
              height: 52,
              borderRadius: 26,
              backgroundColor: reportTags.length > 0 ? PRIMARY : "rgba(105,44,227,0.3)",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
              Submit Report
            </Text>
          </TouchableOpacity>
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );
}

// ─── Main Settings Page ────────────────────────────────────────────────────────
export default function SettingsPage() {
  const { colors, isDark, toggleTheme } = useTheme();
  const [notifications, setNotifications] = useState(true);
  const [introvertMode, setIntrovertMode] = useState(true);
  const [showOnline, setShowOnline] = useState(true);
  const [showReportModal, setShowReportModal] = useState(false);

  const handleDeactivate = () => {
    Alert.alert(
      "Deactivate Account",
      "Are you sure? You can reactivate anytime.",
      [
        { text: "Cancel", style: "cancel" },
        { text: "Deactivate", style: "destructive", onPress: () => {} },
      ]
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <Stack.Screen
        options={{
          headerShown: true,
          title: "Settings",
          headerStyle: { backgroundColor: colors.background },
          headerTintColor: colors.text,
          headerShadowVisible: false,
          headerTitleStyle: {
            fontFamily: "Poppins-SemiBold",
            fontSize: 18,
            color: colors.text,
          },
          headerLeft: () => (
            <TouchableOpacity
              activeOpacity={0.7}
              onPress={() => router.back()}
              style={{ marginLeft: 4, padding: 8 }}
            >
              <Ionicons name="arrow-back" size={22} color={colors.text} />
            </TouchableOpacity>
          ),
        }}
      />

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* ── Section 1: PRIVACY ── */}
        <SectionCard title="PRIVACY" colors={colors} marginTop={16}>
          <ToggleRow
            icon="notifications-outline"
            label="Notifications"
            subtitle="Get alerts for matches & messages"
            value={notifications}
            onToggle={() => setNotifications((v) => !v)}
            colors={colors}
          />
          <Divider colors={colors} />
          <ToggleRow
            icon={isDark ? "sunny-outline" : "moon-outline"}
            label="Dark Mode"
            subtitle="Switch app theme"
            value={isDark}
            onToggle={toggleTheme}
            colors={colors}
          />
          <Divider colors={colors} />
          <ToggleRow
            icon="moon-outline"
            label="Introvert Mode"
            subtitle="Fewer notifications, calmer experience"
            value={introvertMode}
            onToggle={() => setIntrovertMode((v) => !v)}
            colors={colors}
          />
          <Divider colors={colors} />
          <ToggleRow
            icon="eye-outline"
            label="Show Online Status"
            subtitle="Let others see when you're active"
            value={showOnline}
            onToggle={() => setShowOnline((v) => !v)}
            colors={colors}
          />
          <Divider colors={colors} />
          <NavRow
            icon="ban-outline"
            label="Blocked Profiles"
            subtitle="Manage people you've blocked"
            onPress={() => Alert.alert("No blocked profiles yet.")}
            colors={colors}
          />
          <Divider colors={colors} />
          <NavRow
            icon="archive-outline"
            label="Archived Profiles"
            subtitle="View your archived matches"
            onPress={() => Alert.alert("No archived profiles yet.")}
            colors={colors}
          />
        </SectionCard>

        {/* ── Section 2: SUPPORT ── */}
        <SectionCard title="SUPPORT" colors={colors}>
          <NavRow
            icon="chatbubble-ellipses-outline"
            label="Contact Us"
            subtitle="Email us at support@luptup.com"
            onPress={() =>
              Alert.alert("Contact Us", "Email us at support@luptup.com")
            }
            colors={colors}
          />
          <Divider colors={colors} />
          <NavRow
            icon="flag-outline"
            label="Report a Problem"
            subtitle="Help us improve"
            onPress={() => setShowReportModal(true)}
            colors={colors}
          />
          <Divider colors={colors} />
          <NavRow
            icon="help-circle-outline"
            label="Help Center"
            onPress={() =>
              Alert.alert("Help Center", "Choose a topic:", [
                { text: "Privacy Policy" },
                { text: "Safety & Reporting" },
                { text: "Community Guidelines" },
                { text: "Cancel", style: "cancel" },
              ])
            }
            colors={colors}
          />
          <Divider colors={colors} />
          <NavRow
            icon="document-text-outline"
            label="Privacy Policy"
            subtitle="How we use your data"
            onPress={() =>
              Alert.alert(
                "Privacy Policy",
                "We value your privacy. Lup Tup does not sell or share your personal data with third parties. Your data is used solely to improve your experience on our platform."
              )
            }
            colors={colors}
          />
          <Divider colors={colors} />
          <NavRow
            icon="shield-outline"
            label="Safety & Reporting"
            subtitle="Stay safe on Lup Tup"
            onPress={() =>
              Alert.alert(
                "Safety & Reporting",
                "Never share personal financial information. Report suspicious profiles immediately. Use our block feature if you feel unsafe. Your safety is our priority."
              )
            }
            colors={colors}
          />
        </SectionCard>

        {/* ── Section 3: ACCOUNT ── */}
        <SectionCard title="ACCOUNT" colors={colors}>
          <NavRow
            icon="star-outline"
            label="Feedback"
            subtitle="Share your thoughts with us"
            onPress={() => Alert.alert("Thank you!", "We appreciate your feedback.")}
            colors={colors}
          />
          <Divider colors={colors} />
          <NavRow
            icon="information-circle-outline"
            label="About Lup Tup"
            subtitle="Version 1.0.0 • Open source & privacy-first"
            onPress={() =>
              Alert.alert(
                "About Lup Tup",
                "Lup Tup is a safe, inclusive dating app built for everyone. Version 1.0.0 — Open source & privacy-first. Made with ❤️ in India."
              )
            }
            colors={colors}
          />
          <Divider colors={colors} />
          <NavRow
            icon="power-outline"
            label="Deactivate Account"
            subtitle="You can reactivate anytime"
            onPress={handleDeactivate}
            colors={colors}
            destructive
          />
        </SectionCard>

        <View style={{ height: 60 }} />
      </ScrollView>

      {/* ── Report Modal ── */}
      <ReportModal
        visible={showReportModal}
        onClose={() => setShowReportModal(false)}
        colors={colors}
      />
    </View>
  );
}
