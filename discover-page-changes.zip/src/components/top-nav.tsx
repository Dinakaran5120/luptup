import { useMyProfile } from "@/api/my-profile";
import { BRAND, useTheme } from "@/context/theme";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import { Pressable, Text, View } from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

const NavBtn: React.FC<{
  onPress: () => void;
  children: React.ReactNode;
  bgColor: string;
}> = ({ onPress, children, bgColor }) => {
  const scale = useSharedValue(1);
  const animStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));
  return (
    <AnimatedPressable
      style={[
        {
          width: 38,
          height: 38,
          borderRadius: 19,
          backgroundColor: bgColor,
          alignItems: "center",
          justifyContent: "center",
        },
        animStyle,
      ]}
      onPressIn={() => { scale.value = withSpring(0.88, { damping: 15 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 15 }); }}
      onPress={onPress}
    >
      {children}
    </AnimatedPressable>
  );
};

interface Props {
  showNotification?: boolean;
  showCoins?: boolean;
  onNotificationPress?: () => void;
}

export const TopNav: React.FC<Props> = ({
  showNotification = true,
  showCoins = true,
  onNotificationPress,
}) => {
  const { colors } = useTheme();
  const insets = useSafeAreaInsets();
  const [coins] = useState(1542);

  return (
    <View
      style={{
        paddingTop: insets.top,
        backgroundColor: colors.background,
        borderBottomWidth: 1,
        borderBottomColor: colors.border,
      }}
    >
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 16,
          paddingVertical: 10,
        }}
      >
        {/* Logo */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Ionicons name="heart" size={22} color={BRAND.primary} />
          <Text
            style={{
              fontFamily: "Poppins-Bold",
              fontSize: 20,
              color: colors.text,
              letterSpacing: -0.3,
            }}
          >
            lup tup
          </Text>
        </View>

        {/* Right side: coins + bell */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          {showCoins && (
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 6,
                backgroundColor: colors.surface,
                borderRadius: 20,
                paddingHorizontal: 10,
                paddingVertical: 6,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              {/* Gold coin */}
              <View
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 11,
                  backgroundColor: "#f59e0b",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Ionicons name="star" size={12} color="#fff" />
              </View>
              <Text
                style={{
                  fontFamily: "Poppins-SemiBold",
                  fontSize: 14,
                  color: colors.text,
                }}
              >
                {coins.toLocaleString()}
              </Text>
              <Pressable
                onPress={() => {}}
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 11,
                  backgroundColor: BRAND.primary,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Ionicons name="add" size={14} color="#fff" />
              </Pressable>
            </View>
          )}

          {showNotification && (
            <View style={{ position: "relative" }}>
              <NavBtn
                onPress={onNotificationPress ?? (() => router.push("/notifications" as any))}
                bgColor={colors.surface}
              >
                <Ionicons name="notifications-outline" size={20} color={colors.icon} />
              </NavBtn>
              {/* Red notification dot */}
              <View
                style={{
                  position: "absolute",
                  top: 4,
                  right: 4,
                  width: 9,
                  height: 9,
                  borderRadius: 5,
                  backgroundColor: "#ef4444",
                  borderWidth: 1.5,
                  borderColor: colors.background,
                }}
              />
            </View>
          )}
        </View>
      </View>
    </View>
  );
};
