import { useTheme } from "@/context/theme";
import { Ionicons } from "@expo/vector-icons";
import { Slider } from "@miblanchard/react-native-slider";
import React, { useEffect, useState } from "react";
import {
  Dimensions,
  Modal,
  Pressable,
  ScrollView,
  Switch,
  Text,
  View,
} from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);
const { width: SW } = Dimensions.get("window");

interface FilterState {
  online: boolean;
  minAge: number;
  maxAge: number;
  orientation: string;
}

type FilterKey = keyof FilterState | "filters";

const ORIENTATION_OPTIONS = [
  "All Orientations",
  "Straight",
  "Gay / Lesbian",
  "Bisexual",
  "Pansexual",
  "Other",
];

const defaultFilters: FilterState = {
  online: false,
  minAge: 18,
  maxAge: 30,
  orientation: "All Orientations",
};

/* ── Animated pill ── */
const Pill: React.FC<{
  label: string;
  active: boolean;
  hasDropdown?: boolean;
  leftIcon?: string;
  onPress: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
  greenDot?: boolean;
}> = ({ label, active, hasDropdown = true, leftIcon, onPress, colors, greenDot }) => {
  const scale = useSharedValue(1);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <AnimatedPressable
      style={[
        {
          paddingHorizontal: 12,
          paddingVertical: 7,
          borderRadius: 20,
          backgroundColor: active ? colors.primary : colors.surface,
          borderWidth: 1,
          borderColor: active ? colors.primary : colors.border,
          flexDirection: "row",
          alignItems: "center",
          gap: 5,
        },
        anim,
      ]}
      onPressIn={() => { scale.value = withSpring(0.93, { damping: 14 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 14 }); }}
      onPress={onPress}
    >
      {leftIcon && (
        <Ionicons name={leftIcon as any} size={14} color={active ? "#fff" : colors.textMuted} />
      )}
      {greenDot && (
        <View
          style={{
            width: 8,
            height: 8,
            borderRadius: 4,
            backgroundColor: "#22c55e",
          }}
        />
      )}
      <Text
        style={{
          fontFamily: "Poppins-Medium",
          fontSize: 13,
          color: active ? "#fff" : colors.textMuted,
        }}
      >
        {label}
      </Text>
      {hasDropdown && (
        <Ionicons
          name="chevron-down"
          size={11}
          color={active ? "#fff" : colors.textMuted}
        />
      )}
    </AnimatedPressable>
  );
};

/* ── Filter bottom sheet ── */
const FilterSheet: React.FC<{
  visible: boolean;
  activeKey: FilterKey | null;
  filters: FilterState;
  onClose: () => void;
  onApply: (patch: Partial<FilterState>) => void;
}> = ({ visible, activeKey, filters, onClose, onApply }) => {
  const { colors } = useTheme();
  const [local, setLocal] = useState<FilterState>(filters);

  useEffect(() => {
    if (visible) setLocal(filters);
  }, [visible]);

  const handleApply = () => {
    onApply(local);
    onClose();
  };

  const sliderTrack = {
    minimumTrackTintColor: colors.primary,
    maximumTrackTintColor: colors.border,
    thumbTintColor: colors.primary,
  };

  const renderBody = () => {
    switch (activeKey) {
      case "filters":
        return (
          <View style={{ padding: 24, gap: 20 }}>
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: colors.text }}>
              Filters
            </Text>
            <View style={{ gap: 16 }}>
              {/* Age range */}
              <View style={{ gap: 8 }}>
                <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center" }}>
                  <Text style={{ fontFamily: "Poppins-Medium", fontSize: 15, color: colors.text }}>Age Range</Text>
                  <View style={{ backgroundColor: colors.surfaceAlt, paddingHorizontal: 12, paddingVertical: 4, borderRadius: 16 }}>
                    <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: colors.primary }}>
                      {local.minAge} – {local.maxAge} yrs
                    </Text>
                  </View>
                </View>
                <Slider
                  value={[local.minAge, local.maxAge]}
                  minimumValue={18}
                  maximumValue={60}
                  step={1}
                  onValueChange={(vals: number[]) =>
                    setLocal({ ...local, minAge: vals[0], maxAge: vals[1] ?? vals[0] })
                  }
                  {...sliderTrack}
                />
              </View>
              {/* Online toggle */}
              <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", padding: 14, borderRadius: 12, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
                  <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: "#22c55e" }} />
                  <Text style={{ fontFamily: "Poppins-Medium", fontSize: 14, color: colors.text }}>
                    Online only
                  </Text>
                </View>
                <Switch
                  value={local.online}
                  onValueChange={(v) => setLocal({ ...local, online: v })}
                  trackColor={{ false: colors.border, true: colors.primary }}
                  thumbColor="#fff"
                />
              </View>
            </View>
          </View>
        );

      case "minAge":
        return (
          <View style={{ padding: 24, gap: 20 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: colors.text }}>
                Age Range
              </Text>
              <View style={{ backgroundColor: colors.surfaceAlt, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20 }}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: colors.primary }}>
                  {local.minAge} – {local.maxAge} yrs
                </Text>
              </View>
            </View>
            <View style={{ paddingHorizontal: 8 }}>
              <Slider
                value={[local.minAge, local.maxAge]}
                minimumValue={18}
                maximumValue={60}
                step={1}
                onValueChange={(vals: number[]) =>
                  setLocal({ ...local, minAge: vals[0], maxAge: vals[1] ?? vals[0] })
                }
                {...sliderTrack}
              />
            </View>
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>18 (min)</Text>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>60 (max)</Text>
            </View>
          </View>
        );

      case "online":
        return (
          <View style={{ padding: 24, gap: 20 }}>
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: colors.text }}>
              Online Status
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                padding: 16,
                borderRadius: 14,
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <View style={{ gap: 2 }}>
                <Text style={{ fontFamily: "Poppins-Medium", fontSize: 15, color: colors.text }}>
                  Show online users only
                </Text>
                <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>
                  Filter by active status
                </Text>
              </View>
              <Switch
                value={local.online}
                onValueChange={(v) => setLocal({ ...local, online: v })}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor="#fff"
              />
            </View>
          </View>
        );

      case "orientation":
        return (
          <View style={{ padding: 24, gap: 16 }}>
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: colors.text }}>
              Orientation
            </Text>
            <View style={{ gap: 10 }}>
              {ORIENTATION_OPTIONS.map((opt) => {
                const isSelected = local.orientation === opt;
                return (
                  <Pressable
                    key={opt}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: 14,
                      borderRadius: 12,
                      backgroundColor: isSelected ? colors.surfaceAlt : colors.surface,
                      borderWidth: 1.5,
                      borderColor: isSelected ? colors.primary : colors.border,
                    }}
                    onPress={() => setLocal({ ...local, orientation: opt })}
                  >
                    <Text style={{ fontFamily: "Poppins-Medium", fontSize: 14, color: isSelected ? colors.primary : colors.text }}>
                      {opt}
                    </Text>
                    {isSelected && (
                      <Ionicons name="checkmark-circle" size={20} color={colors.primary} />
                    )}
                  </Pressable>
                );
              })}
            </View>
          </View>
        );

      default:
        return null;
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      <Pressable
        style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)" }}
        onPress={onClose}
      >
        <Pressable
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            backgroundColor: colors.background,
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            paddingBottom: 44,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: -4 },
            shadowOpacity: 0.15,
            shadowRadius: 20,
            elevation: 20,
          }}
          onPress={() => {}}
        >
          <View style={{ alignItems: "center", paddingTop: 14, paddingBottom: 4 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border }} />
          </View>

          {renderBody()}

          <View style={{ paddingHorizontal: 24, marginTop: 8 }}>
            <Pressable
              style={{
                height: 52,
                borderRadius: 26,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: colors.primary,
                shadowColor: colors.primary,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.35,
                shadowRadius: 10,
                elevation: 6,
              }}
              onPress={handleApply}
            >
              <Text style={{ color: "#fff", fontFamily: "Poppins-SemiBold", fontSize: 16 }}>
                Apply
              </Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
};

/* ── Main FilterBar (matches image: Filters | Age | Orientation | Online | ⚙) ── */
export const FilterBar: React.FC = () => {
  const { colors } = useTheme();
  const [activeKey, setActiveKey] = useState<FilterKey | null>(null);
  const [filters, setFilters] = useState<FilterState>(defaultFilters);

  const ageLabel = `Age ${filters.minAge} – ${filters.maxAge}`;
  const orientationLabel = filters.orientation;
  const onlineActive = filters.online;

  const scaleSliders = useSharedValue(1);
  const slidersAnim = useAnimatedStyle(() => ({ transform: [{ scale: scaleSliders.value }] }));

  return (
    <>
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          paddingVertical: 8,
          borderBottomWidth: 1,
          borderBottomColor: colors.border,
        }}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{
            paddingHorizontal: 12,
            gap: 8,
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          {/* Filters pill */}
          <Pill
            label="Filters"
            active={false}
            hasDropdown={false}
            leftIcon="options-outline"
            onPress={() => setActiveKey("filters")}
            colors={colors}
          />

          {/* Age */}
          <Pill
            label={ageLabel}
            active={filters.minAge !== defaultFilters.minAge || filters.maxAge !== defaultFilters.maxAge}
            onPress={() => setActiveKey("minAge")}
            colors={colors}
          />

          {/* Orientation */}
          <Pill
            label={orientationLabel}
            active={filters.orientation !== defaultFilters.orientation}
            onPress={() => setActiveKey("orientation")}
            colors={colors}
          />

          {/* Online */}
          <Pill
            label="Online"
            active={onlineActive}
            greenDot
            onPress={() => setActiveKey("online")}
            colors={colors}
          />
        </ScrollView>

        {/* Sliders icon — fixed right */}
        <AnimatedPressable
          style={[
            {
              marginRight: 12,
              width: 36,
              height: 36,
              borderRadius: 18,
              backgroundColor: colors.surface,
              borderWidth: 1,
              borderColor: colors.border,
              alignItems: "center",
              justifyContent: "center",
            },
            slidersAnim,
          ]}
          onPressIn={() => { scaleSliders.value = withSpring(0.9, { damping: 14 }); }}
          onPressOut={() => { scaleSliders.value = withSpring(1, { damping: 14 }); }}
          onPress={() => setActiveKey("filters")}
        >
          <Ionicons name="options" size={18} color={colors.primary} />
        </AnimatedPressable>
      </View>

      <FilterSheet
        visible={activeKey !== null}
        activeKey={activeKey}
        filters={filters}
        onClose={() => setActiveKey(null)}
        onApply={(patch) => setFilters((prev) => ({ ...prev, ...patch }))}
      />
    </>
  );
};
