import { useTheme } from "@/context/theme";
import { Ionicons } from "@expo/vector-icons";
import { Tabs } from "expo-router";
import { Text, View } from "react-native";

const TAB_H = 70;
const CHAT_BADGE = 3;

export default function Layout() {
  const { colors } = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: true,
        tabBarStyle: {
          backgroundColor: colors.tabBar,
          borderTopColor: colors.tabBarBorder,
          borderTopWidth: 1,
          height: TAB_H,
          paddingBottom: 10,
          paddingTop: 8,
        },
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.iconMuted,
        tabBarLabelStyle: {
          fontFamily: "Poppins-Medium",
          fontSize: 11,
          marginTop: 2,
        },
      }}
    >
      {/* Discover */}
      <Tabs.Screen
        name="index"
        options={{
          title: "Discover",
          tabBarIcon: ({ color, focused }) => (
            <Ionicons name={focused ? "heart" : "heart-outline"} size={24} color={color} />
          ),
        }}
      />

      {/* Mood */}
      <Tabs.Screen
        name="post"
        options={{
          title: "Mood",
          tabBarIcon: ({ color, focused }) => (
            <Ionicons name={focused ? "happy" : "happy-outline"} size={24} color={color} />
          ),
        }}
      />

      {/* Matches */}
      <Tabs.Screen
        name="likes"
        options={{
          title: "Matches",
          tabBarIcon: ({ color, focused }) => (
            <Ionicons name={focused ? "flash" : "flash-outline"} size={24} color={color} />
          ),
        }}
      />

      {/* Chats — with badge */}
      <Tabs.Screen
        name="matches"
        options={{
          title: "Chats",
          tabBarIcon: ({ color, focused }) => (
            <View>
              <Ionicons
                name={focused ? "chatbubble" : "chatbubble-outline"}
                size={24}
                color={color}
              />
              <View
                style={{
                  position: "absolute",
                  top: -4,
                  right: -10,
                  backgroundColor: "#ef4444",
                  borderRadius: 8,
                  minWidth: 18,
                  height: 18,
                  alignItems: "center",
                  justifyContent: "center",
                  paddingHorizontal: 3,
                }}
              >
                <Text
                  style={{
                    color: "#fff",
                    fontSize: 10,
                    fontFamily: "Poppins-SemiBold",
                    lineHeight: 14,
                  }}
                >
                  {CHAT_BADGE}
                </Text>
              </View>
            </View>
          ),
        }}
      />

      {/* Profile */}
      <Tabs.Screen
        name="hinge"
        options={{
          title: "Profile",
          tabBarIcon: ({ color, focused }) => (
            <Ionicons name={focused ? "person" : "person-outline"} size={24} color={color} />
          ),
        }}
      />

      {/* Community — hidden from tab bar */}
      <Tabs.Screen
        name="community"
        options={{ href: null }}
      />
    </Tabs>
  );
}
