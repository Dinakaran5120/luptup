import { BRAND, useTheme } from "@/context/theme";
import { FilterBar } from "@/components/filter-bar";
import { TopNav } from "@/components/top-nav";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import { Image } from "expo-image";
import { router } from "expo-router";
import { useState } from "react";
import {
  Alert,
  FlatList,
  Pressable,
  StatusBar,
  Text,
  View,
} from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

// ─── Mock discover profiles matching the image ────────────────────────────────

type InterestIcon = {
  icon: string;
  label: string;
};

type DiscoverProfile = {
  id: string;
  name: string;
  age: number;
  isOnline: boolean;
  isLocked: boolean;
  badge: "Popular" | "New" | null;
  interests: InterestIcon[];
  location: string;
  photo: string;
  unlockCost?: number;
};

const INTEREST_ICONS: Record<string, string> = {
  "Book lover": "book-outline",
  Cats: "paw-outline",
  Travel: "airplane-outline",
  Coffee: "cafe-outline",
  Music: "musical-notes-outline",
  Fitness: "barbell-outline",
  Art: "color-palette-outline",
  Dogs: "paw-outline",
  Movies: "film-outline",
  "Road Trips": "car-outline",
  Cooking: "restaurant-outline",
  Photography: "camera-outline",
};

const DISCOVER_PROFILES: DiscoverProfile[] = [
  {
    id: "d-001",
    name: "Anaya",
    age: 24,
    isOnline: true,
    isLocked: false,
    badge: null,
    interests: [
      { icon: INTEREST_ICONS["Book lover"], label: "Book lover" },
      { icon: INTEREST_ICONS["Cats"], label: "Cats" },
    ],
    location: "Mumbai, India",
    photo: "https://picsum.photos/seed/anaya24/400/500",
  },
  {
    id: "d-002",
    name: "Riya",
    age: 25,
    isOnline: true,
    isLocked: false,
    badge: null,
    interests: [
      { icon: INTEREST_ICONS["Travel"], label: "Travel" },
      { icon: INTEREST_ICONS["Coffee"], label: "Coffee" },
    ],
    location: "Delhi, India",
    photo: "https://picsum.photos/seed/riya25/400/500",
  },
  {
    id: "d-003",
    name: "Kabir",
    age: 26,
    isOnline: false,
    isLocked: true,
    badge: "Popular",
    interests: [
      { icon: INTEREST_ICONS["Music"], label: "Music" },
      { icon: INTEREST_ICONS["Fitness"], label: "Fitness" },
    ],
    location: "Bangalore, India",
    photo: "https://picsum.photos/seed/kabir26/400/500",
    unlockCost: 50,
  },
  {
    id: "d-004",
    name: "Meera",
    age: 23,
    isOnline: false,
    isLocked: true,
    badge: "Popular",
    interests: [
      { icon: INTEREST_ICONS["Art"], label: "Art" },
      { icon: INTEREST_ICONS["Dogs"], label: "Dogs" },
    ],
    location: "Pune, India",
    photo: "https://picsum.photos/seed/meera23/400/500",
    unlockCost: 50,
  },
  {
    id: "d-005",
    name: "Arjun",
    age: 25,
    isOnline: false,
    isLocked: true,
    badge: "New",
    interests: [
      { icon: INTEREST_ICONS["Movies"], label: "Movies" },
      { icon: INTEREST_ICONS["Road Trips"], label: "Road Trips" },
    ],
    location: "Hyderabad, India",
    photo: "https://picsum.photos/seed/arjun25/400/500",
    unlockCost: 50,
  },
  {
    id: "d-006",
    name: "Simran",
    age: 24,
    isOnline: false,
    isLocked: true,
    badge: "New",
    interests: [
      { icon: INTEREST_ICONS["Cooking"], label: "Cooking" },
      { icon: INTEREST_ICONS["Photography"], label: "Photography" },
    ],
    location: "Chandigarh, India",
    photo: "https://picsum.photos/seed/simran24/400/500",
    unlockCost: 50,
  },
];

// ─── Heart button (unlocked profiles) ────────────────────────────────────────

const HeartButton: React.FC<{ liked: boolean; onPress: () => void; colors: ReturnType<typeof useTheme>["colors"] }> = ({ liked, onPress, colors }) => {
  const scale = useSharedValue(1);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <AnimatedPressable
      style={[
        {
          width: 46,
          height: 46,
          borderRadius: 23,
          backgroundColor: liked ? BRAND.primary + "20" : colors.surface,
          borderWidth: 1.5,
          borderColor: liked ? BRAND.primary : colors.border,
          alignItems: "center",
          justifyContent: "center",
          shadowColor: liked ? BRAND.primary : "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: liked ? 0.3 : 0.08,
          shadowRadius: 6,
          elevation: liked ? 4 : 2,
        },
        anim,
      ]}
      onPressIn={() => { scale.value = withSpring(0.88, { damping: 12 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 12 }); }}
      onPress={onPress}
    >
      <Ionicons
        name={liked ? "heart" : "heart-outline"}
        size={22}
        color={liked ? BRAND.primary : BRAND.primary}
      />
    </AnimatedPressable>
  );
};

// ─── Unlock button (locked profiles) ─────────────────────────────────────────

const UnlockButton: React.FC<{ cost: number; onPress: () => void; colors: ReturnType<typeof useTheme>["colors"] }> = ({ cost, onPress, colors }) => {
  const scale = useSharedValue(1);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <AnimatedPressable
      style={[
        {
          alignItems: "center",
          justifyContent: "center",
          gap: 3,
        },
        anim,
      ]}
      onPressIn={() => { scale.value = withSpring(0.9, { damping: 12 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 12 }); }}
      onPress={onPress}
    >
      <View style={{ flexDirection: "row", alignItems: "center", gap: 3 }}>
        <View
          style={{
            width: 18,
            height: 18,
            borderRadius: 9,
            backgroundColor: "#f59e0b",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <Ionicons name="star" size={10} color="#fff" />
        </View>
        <Text
          style={{
            fontFamily: "Poppins-SemiBold",
            fontSize: 14,
            color: colors.text,
          }}
        >
          {cost}
        </Text>
      </View>
      <Text
        style={{
          fontFamily: "Poppins-Medium",
          fontSize: 12,
          color: colors.textMuted,
        }}
      >
        Unlock
      </Text>
    </AnimatedPressable>
  );
};

// ─── Badge (Popular / New) ────────────────────────────────────────────────────

const ProfileBadge: React.FC<{ badge: "Popular" | "New" }> = ({ badge }) => (
  <View
    style={{
      position: "absolute",
      top: 8,
      left: 0,
      flexDirection: "row",
      alignItems: "center",
      gap: 3,
      backgroundColor: badge === "Popular" ? "#f59e0b" : BRAND.secondary,
      paddingHorizontal: 7,
      paddingVertical: 3,
      borderTopRightRadius: 8,
      borderBottomRightRadius: 8,
      zIndex: 10,
    }}
  >
    {badge === "Popular" && <Ionicons name="star" size={9} color="#fff" />}
    <Text
      style={{
        fontFamily: "Poppins-SemiBold",
        fontSize: 10,
        color: "#fff",
        letterSpacing: 0.2,
      }}
    >
      {badge}
    </Text>
  </View>
);

// ─── Single profile card ──────────────────────────────────────────────────────

const ProfileCard: React.FC<{
  item: DiscoverProfile;
  colors: ReturnType<typeof useTheme>["colors"];
  isDark: boolean;
}> = ({ item, colors, isDark }) => {
  const [liked, setLiked] = useState(false);

  const handleLike = () => {
    setLiked((prev) => !prev);
  };

  const handleUnlock = () => {
    Alert.alert(
      "Unlock Profile",
      `Unlock ${item.name}'s profile for ${item.unlockCost} coins?`,
      [
        { text: "Cancel", style: "cancel" },
        { text: "Unlock", style: "default", onPress: () => {} },
      ]
    );
  };

  return (
    <Pressable
      onPress={() => {}}
      style={{
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: colors.card,
        marginHorizontal: 14,
        marginVertical: 5,
        borderRadius: 16,
        overflow: "hidden",
        borderWidth: 1,
        borderColor: colors.border,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: isDark ? 0 : 0.07,
        shadowRadius: 8,
        elevation: 3,
        padding: 12,
        gap: 12,
      }}
    >
      {/* Photo thumbnail */}
      <View
        style={{
          width: 82,
          height: 96,
          borderRadius: 12,
          overflow: "hidden",
          flexShrink: 0,
        }}
      >
        <Image
          source={item.photo}
          style={{ width: "100%", height: "100%" }}
          contentFit="cover"
        />
        {item.isLocked && (
          <>
            <BlurView
              intensity={50}
              tint={isDark ? "dark" : "light"}
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
              }}
            />
            {/* Dark overlay */}
            <View
              style={{
                position: "absolute",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: "rgba(0,0,0,0.35)",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <View
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 16,
                  backgroundColor: "rgba(255,255,255,0.15)",
                  alignItems: "center",
                  justifyContent: "center",
                  borderWidth: 1.5,
                  borderColor: "rgba(255,255,255,0.4)",
                }}
              >
                <Ionicons name="lock-closed" size={16} color="#fff" />
              </View>
            </View>
          </>
        )}
        {item.badge && <ProfileBadge badge={item.badge} />}
      </View>

      {/* Info column */}
      <View style={{ flex: 1, gap: 4 }}>
        {/* Name + verified */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
          <Text
            style={{
              fontFamily: "Poppins-SemiBold",
              fontSize: 16,
              color: colors.text,
            }}
          >
            {item.name}, {item.age}
          </Text>
          <Ionicons name="checkmark-circle" size={16} color="#3b82f6" />
        </View>

        {/* Online / unlock text */}
        {item.isOnline ? (
          <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
            <View
              style={{
                width: 7,
                height: 7,
                borderRadius: 4,
                backgroundColor: "#22c55e",
              }}
            />
            <Text
              style={{
                fontFamily: "Poppins-Regular",
                fontSize: 12,
                color: "#22c55e",
              }}
            >
              Online
            </Text>
          </View>
        ) : item.isLocked ? (
          <Text
            style={{
              fontFamily: "Poppins-Medium",
              fontSize: 12,
              color: BRAND.primary,
            }}
          >
            Unlock to see profile
          </Text>
        ) : null}

        {/* Interests */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
          {item.interests.map((interest) => (
            <View
              key={interest.label}
              style={{ flexDirection: "row", alignItems: "center", gap: 4 }}
            >
              <Ionicons name={interest.icon as any} size={13} color={colors.textMuted} />
              <Text
                style={{
                  fontFamily: "Poppins-Regular",
                  fontSize: 12,
                  color: colors.textMuted,
                }}
              >
                {interest.label}
              </Text>
            </View>
          ))}
        </View>

        {/* Location */}
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4 }}>
          <Ionicons name="location-outline" size={13} color={colors.textMuted} />
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 12,
              color: colors.textMuted,
            }}
          >
            {item.location}
          </Text>
        </View>
      </View>

      {/* Action column */}
      <View style={{ alignItems: "center", justifyContent: "center" }}>
        {!item.isLocked ? (
          <HeartButton liked={liked} onPress={handleLike} colors={colors} />
        ) : (
          <UnlockButton cost={item.unlockCost!} onPress={handleUnlock} colors={colors} />
        )}
      </View>
    </Pressable>
  );
};

// ─── Main Discover Screen ─────────────────────────────────────────────────────

export default function DiscoverPage() {
  const { colors, isDark } = useTheme();

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      {/* Header */}
      <TopNav />

      {/* Page title */}
      <View
        style={{
          paddingHorizontal: 16,
          paddingTop: 14,
          paddingBottom: 4,
          backgroundColor: colors.background,
        }}
      >
        <Text
          style={{
            fontFamily: "Poppins-Bold",
            fontSize: 26,
            color: colors.text,
            letterSpacing: -0.3,
          }}
        >
          Discover
        </Text>
      </View>

      {/* Filter bar */}
      <FilterBar />

      {/* Profile list */}
      <FlatList
        data={DISCOVER_PROFILES}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <ProfileCard item={item} colors={colors} isDark={isDark} />
        )}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: 8, paddingBottom: 100 }}
      />
    </View>
  );
}
