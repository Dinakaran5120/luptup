/**
 * All static/dummy data for the mock app.
 * Profiles use public Picsum photos so no real images are needed.
 */

import { PrivateProfile } from "@/api/my-profile/types";
import { Like, PublicProfile } from "@/api/profiles/types";

// ─── My Profile ──────────────────────────────────────────────────────────────

export const MOCK_MY_PROFILE: PrivateProfile = {
  id: "mock-user-id-001",
  first_name: "Alex",
  last_name: "Morgan",
  dob: "1995-06-15",
  height_cm: 175,
  neighborhood: "Brooklyn",
  latitude: 40.6782,
  longitude: -73.9442,
  max_distance_km: 50,
  min_age: 25,
  max_age: 35,
  phone: "+10000000000",
  children: { id: 2, name: "No children" },
  family_plan: { id: 1, name: "Open to children" },
  covid_vaccine: { id: 1, name: "Vaccinated" },
  zodiac_sign: { id: 6, name: "Gemini" },
  sexuality: { id: 1, name: "Straight" },
  gender: { id: 1, name: "Man", plural_name: "Men" },
  ethnicities: [{ id: 3, name: "White / Caucasian" }],
  pets: [{ id: 1, name: "Dog", plural_name: "Dogs" }],
  pronouns: [{ id: 1, name: "He/Him" }],
  ethnicity_preferences: [],
  gender_preferences: [{ id: 2, name: "Woman", plural_name: "Women" }],
  answers: [
    {
      id: "ans-001",
      prompt_id: 1,
      question: "I go crazy for",
      answer_text: "Live music, rooftop bars, and spontaneous road trips.",
      answer_order: 0,
    },
    {
      id: "ans-002",
      prompt_id: 2,
      question: "My most controversial opinion",
      answer_text: "Pineapple on pizza is actually great.",
      answer_order: 1,
    },
  ],
  photos: [
    {
      id: "photo-001",
      photo_url: "https://picsum.photos/seed/alex1/400/600",
      photo_order: 0,
    },
    {
      id: "photo-002",
      photo_url: "https://picsum.photos/seed/alex2/400/600",
      photo_order: 1,
    },
  ],
  avatar_url: "https://picsum.photos/seed/alex1/400/600",
};

// ─── Public Profiles (Discover feed) ─────────────────────────────────────────

const makeProfile = (
  id: string,
  firstName: string,
  seed: string,
  age: number,
  hood: string
): PublicProfile => ({
  id,
  first_name: firstName,
  age,
  neighborhood: hood,
  height_cm: 165 + Math.floor(Math.random() * 20),
  gender: "Woman",
  sexuality: "Straight",
  children: "No children",
  family_plan: "Open to children",
  covid_vaccine: "Vaccinated",
  zodiac_sign: "Libra",
  ethnicities: ["White / Caucasian"],
  pets: ["Cat"],
  pronouns: ["She/Her"],
  photos: [
    { id: `${id}-p1`, photo_url: `https://picsum.photos/seed/${seed}a/400/600`, photo_order: 0 },
    { id: `${id}-p2`, photo_url: `https://picsum.photos/seed/${seed}b/400/600`, photo_order: 1 },
    { id: `${id}-p3`, photo_url: `https://picsum.photos/seed/${seed}c/400/600`, photo_order: 2 },
  ],
  answers: [
    {
      id: `${id}-ans1`,
      question: "A life goal of mine",
      answer_text: "Travel to every continent before 40.",
      answer_order: 0,
    },
    {
      id: `${id}-ans2`,
      question: "I'm looking for",
      answer_text: "Someone who can make me laugh every day.",
      answer_order: 1,
    },
  ],
});

export const MOCK_PROFILES: PublicProfile[] = [
  makeProfile("p-001", "Sophie", "sophie", 28, "Manhattan"),
  makeProfile("p-002", "Emma", "emma", 26, "Brooklyn"),
  makeProfile("p-003", "Olivia", "olivia", 30, "Queens"),
  makeProfile("p-004", "Isabella", "isabella", 27, "Hoboken"),
  makeProfile("p-005", "Mia", "mia", 29, "Jersey City"),
  makeProfile("p-006", "Charlotte", "charlotte", 25, "Astoria"),
  makeProfile("p-007", "Amelia", "amelia", 31, "Williamsburg"),
  makeProfile("p-008", "Harper", "harper", 27, "SoHo"),
];

// ─── Likes ───────────────────────────────────────────────────────────────────

export const MOCK_LIKES: Like[] = [
  {
    id: "like-001",
    photo_url: "https://picsum.photos/seed/likeralice/400/600",
    answer_text: null,
    question: null,
    profile: makeProfile("liker-001", "Alice", "likeralice", 27, "Chelsea"),
  },
  {
    id: "like-002",
    photo_url: null,
    answer_text: "Travel to every continent before 40.",
    question: "A life goal of mine",
    profile: makeProfile("liker-002", "Grace", "likergrace", 29, "Upper East Side"),
  },
  {
    id: "like-003",
    photo_url: "https://picsum.photos/seed/likereva/400/600",
    answer_text: null,
    question: null,
    profile: makeProfile("liker-003", "Eva", "likereva", 25, "Tribeca"),
  },
];

// ─── Matches (for chat list) ─────────────────────────────────────────────────

export const MOCK_MATCHES = [
  {
    id: "match-001",
    name: "Sophie",
    avatar: "https://picsum.photos/seed/sophie/100/100",
    lastMessage: "Hey! How's your week going?",
    timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString(),
    messages: [
      { id: "m1", text: "Hey! How's your week going?", fromMe: false, timestamp: new Date(Date.now() - 1000 * 60 * 5).toISOString() },
      { id: "m2", text: "Pretty good! Just got back from a hike 🏔️", fromMe: true, timestamp: new Date(Date.now() - 1000 * 60 * 3).toISOString() },
      { id: "m3", text: "Oh nice! Where did you go?", fromMe: false, timestamp: new Date(Date.now() - 1000 * 60 * 1).toISOString() },
    ],
  },
  {
    id: "match-002",
    name: "Emma",
    avatar: "https://picsum.photos/seed/emma/100/100",
    lastMessage: "That sounds like so much fun!",
    timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(),
    messages: [
      { id: "m1", text: "I loved your answer about road trips!", fromMe: false, timestamp: new Date(Date.now() - 1000 * 60 * 65).toISOString() },
      { id: "m2", text: "Thank you! I love spontaneous adventures 😊", fromMe: true, timestamp: new Date(Date.now() - 1000 * 60 * 62).toISOString() },
      { id: "m3", text: "That sounds like so much fun!", fromMe: false, timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString() },
    ],
  },
];

// ─── Types ───────────────────────────────────────────────────────────────────

export type PostMood = "happy" | "broken_heart" | "sexy" | "vibing";
export type GroupCategory = "adventure" | "health_fitness" | "18plus" | "party_club" | "events";
export type NotifType = "profile_like" | "post_like" | "comment" | "message";

export interface MockPost {
  id: string;
  user_name: string;
  user_avatar: string;
  mood: PostMood;
  media_url: string;
  media_type: "image" | "video";
  caption: string;
  likes_count: number;
  comments_count: number;
  created_at: string;
  liked: boolean;
}

export interface MockGroup {
  id: string;
  name: string;
  description: string;
  cover_url: string;
  category: GroupCategory;
  type: "open" | "private";
  members_count: number;
  is_member: boolean;
  is_pending: boolean;
  owner: string;
}

export interface MockNotification {
  id: string;
  type: NotifType;
  user_name: string;
  user_avatar: string;
  preview: string;
  created_at: string;
  read: boolean;
}

// ─── Explore Posts ────────────────────────────────────────────────────────────

export const MOCK_POSTS: MockPost[] = [
  { id: "post-001", user_name: "Sophie", user_avatar: "https://picsum.photos/seed/sophie/100/100", mood: "happy", media_url: "https://picsum.photos/seed/post1/400/600", media_type: "image", caption: "Best day ever at Central Park 🌸 life is beautiful!", likes_count: 142, comments_count: 23, created_at: new Date(Date.now() - 1000 * 60 * 15).toISOString(), liked: false },
  { id: "post-002", user_name: "Emma", user_avatar: "https://picsum.photos/seed/emma/100/100", mood: "vibing", media_url: "https://picsum.photos/seed/post2/400/600", media_type: "video", caption: "Friday night energy hits different 🎶✨", likes_count: 89, comments_count: 11, created_at: new Date(Date.now() - 1000 * 60 * 45).toISOString(), liked: true },
  { id: "post-003", user_name: "Alice", user_avatar: "https://picsum.photos/seed/likeralice/100/100", mood: "broken_heart", media_url: "https://picsum.photos/seed/post3/400/600", media_type: "image", caption: "Sometimes you just need a rainy Sunday and a good book 💔📖", likes_count: 214, comments_count: 47, created_at: new Date(Date.now() - 1000 * 60 * 90).toISOString(), liked: false },
  { id: "post-004", user_name: "Olivia", user_avatar: "https://picsum.photos/seed/olivia/100/100", mood: "sexy", media_url: "https://picsum.photos/seed/post4/400/600", media_type: "image", caption: "Feeling myself today 💜🔥", likes_count: 376, comments_count: 64, created_at: new Date(Date.now() - 1000 * 60 * 120).toISOString(), liked: false },
  { id: "post-005", user_name: "Grace", user_avatar: "https://picsum.photos/seed/likergrace/100/100", mood: "happy", media_url: "https://picsum.photos/seed/post5/400/600", media_type: "video", caption: "Sunset hikes always win 🌅🏔️", likes_count: 98, comments_count: 19, created_at: new Date(Date.now() - 1000 * 60 * 180).toISOString(), liked: true },
  { id: "post-006", user_name: "Mia", user_avatar: "https://picsum.photos/seed/mia/100/100", mood: "vibing", media_url: "https://picsum.photos/seed/post6/400/600", media_type: "image", caption: "Coffee, good music, no plans. This is the life 🎵☕", likes_count: 167, comments_count: 31, created_at: new Date(Date.now() - 1000 * 60 * 240).toISOString(), liked: false },
  { id: "post-007", user_name: "Isabella", user_avatar: "https://picsum.photos/seed/isabella/100/100", mood: "broken_heart", media_url: "https://picsum.photos/seed/post7/400/600", media_type: "image", caption: "Missing someone who doesn't think of you 💔", likes_count: 531, comments_count: 89, created_at: new Date(Date.now() - 1000 * 60 * 300).toISOString(), liked: false },
  { id: "post-008", user_name: "Charlotte", user_avatar: "https://picsum.photos/seed/charlotte/100/100", mood: "sexy", media_url: "https://picsum.photos/seed/post8/400/600", media_type: "video", caption: "Rooftop views got nothing on me tonight 🌃💋", likes_count: 289, comments_count: 52, created_at: new Date(Date.now() - 1000 * 60 * 360).toISOString(), liked: true },
];

// ─── Community Groups ─────────────────────────────────────────────────────────

export const MOCK_GROUPS: MockGroup[] = [
  { id: "grp-001", name: "NYC Hikers", description: "Weekend trails, sunrise hikes, and outdoor adventures across the tri-state area.", cover_url: "https://picsum.photos/seed/hikersnyc/400/200", category: "adventure", type: "open", members_count: 847, is_member: true, is_pending: false, owner: "Alex M." },
  { id: "grp-002", name: "Friday Night Club", description: "The best parties, clubs, and rooftop events every weekend. 21+ only.", cover_url: "https://picsum.photos/seed/clubfriday/400/200", category: "party_club", type: "private", members_count: 312, is_member: false, is_pending: true, owner: "DJ Nova" },
  { id: "grp-003", name: "FitFam NYC", description: "Morning workouts, gym sessions, yoga classes. Accountability partners welcome!", cover_url: "https://picsum.photos/seed/fitfam/400/200", category: "health_fitness", type: "open", members_count: 1204, is_member: false, is_pending: false, owner: "Coach Ria" },
  { id: "grp-004", name: "Adults Only 🔞", description: "Private community for adults 18+. Requires approval.", cover_url: "https://picsum.photos/seed/adults18/400/200", category: "18plus", type: "private", members_count: 562, is_member: false, is_pending: false, owner: "Anonymous" },
  { id: "grp-005", name: "NYC Events & Meetups", description: "Art shows, food festivals, pop-ups, concerts — your local NYC guide.", cover_url: "https://picsum.photos/seed/nycevents/400/200", category: "events", type: "open", members_count: 2341, is_member: true, is_pending: false, owner: "CityGuide" },
  { id: "grp-006", name: "Solo Travellers", description: "Connect with fellow adventurers. Share tips, find travel buddies.", cover_url: "https://picsum.photos/seed/solotravel/400/200", category: "adventure", type: "open", members_count: 718, is_member: false, is_pending: false, owner: "WanderlustKai" },
  { id: "grp-007", name: "Mental Wellness Circle", description: "A safe space for mindfulness, mental health talks, and mutual support.", cover_url: "https://picsum.photos/seed/wellness/400/200", category: "health_fitness", type: "private", members_count: 233, is_member: false, is_pending: false, owner: "Dr. Sage" },
  { id: "grp-008", name: "Club Nights Underground", description: "Exclusive underground club events and after-parties. Request to join.", cover_url: "https://picsum.photos/seed/clubunder/400/200", category: "party_club", type: "private", members_count: 188, is_member: false, is_pending: false, owner: "Nox" },
];

// ─── Notifications ─────────────────────────────────────────────────────────────

export const MOCK_NOTIFICATIONS: MockNotification[] = [
  { id: "notif-001", type: "profile_like", user_name: "Alice", user_avatar: "https://picsum.photos/seed/likeralice/100/100", preview: "liked your profile 💜", created_at: new Date(Date.now() - 1000 * 60 * 3).toISOString(), read: false },
  { id: "notif-002", type: "message", user_name: "Sophie", user_avatar: "https://picsum.photos/seed/sophie/100/100", preview: "sent you a message: \"Hey! How's your week...\"", created_at: new Date(Date.now() - 1000 * 60 * 10).toISOString(), read: false },
  { id: "notif-003", type: "post_like", user_name: "Emma", user_avatar: "https://picsum.photos/seed/emma/100/100", preview: "liked your post ❤️", created_at: new Date(Date.now() - 1000 * 60 * 30).toISOString(), read: false },
  { id: "notif-004", type: "comment", user_name: "Olivia", user_avatar: "https://picsum.photos/seed/olivia/100/100", preview: "commented: \"This is so relatable 😍\"", created_at: new Date(Date.now() - 1000 * 60 * 60).toISOString(), read: true },
  { id: "notif-005", type: "profile_like", user_name: "Grace", user_avatar: "https://picsum.photos/seed/likergrace/100/100", preview: "liked your profile 💜", created_at: new Date(Date.now() - 1000 * 60 * 90).toISOString(), read: true },
  { id: "notif-006", type: "message", user_name: "Emma", user_avatar: "https://picsum.photos/seed/emma/100/100", preview: "sent you a message: \"That sounds like so...\"", created_at: new Date(Date.now() - 1000 * 60 * 120).toISOString(), read: true },
  { id: "notif-007", type: "post_like", user_name: "Mia", user_avatar: "https://picsum.photos/seed/mia/100/100", preview: "liked your post ❤️", created_at: new Date(Date.now() - 1000 * 60 * 180).toISOString(), read: true },
  { id: "notif-008", type: "comment", user_name: "Charlotte", user_avatar: "https://picsum.photos/seed/charlotte/100/100", preview: "commented: \"You're stunning! 🔥\"", created_at: new Date(Date.now() - 1000 * 60 * 240).toISOString(), read: true },
  { id: "notif-009", type: "profile_like", user_name: "Isabella", user_avatar: "https://picsum.photos/seed/isabella/100/100", preview: "liked your profile 💜", created_at: new Date(Date.now() - 1000 * 60 * 60 * 3).toISOString(), read: true },
];

// ─── Discover Profiles (list view + profile detail) ──────────────────────────

export type DiscoverProfile = {
  id: string;
  name: string;
  age: number;
  isOnline: boolean;
  isLocked: boolean;
  badge: "Popular" | "New" | null;
  interests: string[];
  location: string;
  photo: string;
  unlockCost?: number;
  pronouns?: string;
  sexuality?: string;
  bio?: string;
  distance?: string;
};

export const MOCK_DISCOVER_PROFILES: DiscoverProfile[] = [
  {
    id: "d-001",
    name: "Anaya",
    age: 24,
    isOnline: true,
    isLocked: false,
    badge: null,
    interests: ["Travel", "Coffee", "Music", "Photography", "Dogs"],
    location: "Delhi, India",
    photo: "https://picsum.photos/seed/anaya24/400/500",
    pronouns: "She/Her",
    sexuality: "Bisexual",
    bio: "I love deep talks, spontaneous trips, and kind people. Let's create some memories ✨",
    distance: "3 km away",
  },
  {
    id: "d-002",
    name: "Riya",
    age: 25,
    isOnline: true,
    isLocked: false,
    badge: null,
    interests: ["Travel", "Coffee", "Art", "Music", "Books"],
    location: "Delhi, India",
    photo: "https://picsum.photos/seed/riya25/400/500",
    pronouns: "She/Her",
    sexuality: "Straight",
    bio: "Chai lover, wanderer, and a sucker for good sunsets. Let's explore the world together ☕",
    distance: "5 km away",
  },
  {
    id: "d-003",
    name: "Kabir",
    age: 26,
    isOnline: false,
    isLocked: true,
    badge: "Popular",
    interests: ["Music", "Fitness"],
    location: "Bangalore, India",
    photo: "https://picsum.photos/seed/kabir26/400/500",
    unlockCost: 50,
  },
  {
    id: "d-004",
    name: "Meera",
    age: 23,
    isOnline: false,
    isLocked: true,
    badge: "Popular",
    interests: ["Art", "Dogs"],
    location: "Pune, India",
    photo: "https://picsum.photos/seed/meera23/400/500",
    unlockCost: 50,
  },
  {
    id: "d-005",
    name: "Arjun",
    age: 25,
    isOnline: false,
    isLocked: true,
    badge: "New",
    interests: ["Movies", "Road Trips"],
    location: "Hyderabad, India",
    photo: "https://picsum.photos/seed/arjun25/400/500",
    unlockCost: 50,
  },
  {
    id: "d-006",
    name: "Simran",
    age: 24,
    isOnline: false,
    isLocked: true,
    badge: "New",
    interests: ["Cooking", "Photography"],
    location: "Chandigarh, India",
    photo: "https://picsum.photos/seed/simran24/400/500",
    unlockCost: 50,
  },
];

// ─── Options (dropdowns / pickers) ───────────────────────────────────────────

export const MOCK_OPTIONS = {
  prompts: [
    { id: 1, question: "I go crazy for" },
    { id: 2, question: "My most controversial opinion" },
    { id: 3, question: "A life goal of mine" },
    { id: 4, question: "I'm looking for" },
    { id: 5, question: "The way to my heart is" },
    { id: 6, question: "My love language is" },
    { id: 7, question: "A perfect day for me" },
    { id: 8, question: "I'm convinced that" },
    { id: 9, question: "Green flags I look for" },
    { id: 10, question: "I want someone who" },
  ],
  children: [
    { id: 1, name: "Have children" },
    { id: 2, name: "No children" },
    { id: 3, name: "Not specified" },
  ],
  covid_vaccine: [
    { id: 1, name: "Vaccinated" },
    { id: 2, name: "Unvaccinated" },
    { id: 3, name: "Prefer not to say" },
  ],
  ethnicities: [
    { id: 1, name: "Asian / Pacific Islander" },
    { id: 2, name: "Black / African Descent" },
    { id: 3, name: "White / Caucasian" },
    { id: 4, name: "Hispanic / Latino" },
    { id: 5, name: "Middle Eastern" },
    { id: 6, name: "Native American" },
    { id: 7, name: "South Asian" },
    { id: 8, name: "Other" },
  ],
  family_plans: [
    { id: 1, name: "Open to children" },
    { id: 2, name: "Want children" },
    { id: 3, name: "Don't want children" },
    { id: 4, name: "Not sure yet" },
  ],
  genders: [
    { id: 1, name: "Man", plural_name: "Men" },
    { id: 2, name: "Woman", plural_name: "Women" },
    { id: 3, name: "Non-binary", plural_name: "Non-binary people" },
    { id: 4, name: "Other", plural_name: "Others" },
  ],
  pets: [
    { id: 1, name: "Dog", plural_name: "Dogs" },
    { id: 2, name: "Cat", plural_name: "Cats" },
    { id: 3, name: "Bird", plural_name: "Birds" },
    { id: 4, name: "Fish", plural_name: "Fish" },
    { id: 5, name: "No pets", plural_name: "No pets" },
  ],
  pronouns: [
    { id: 1, name: "He/Him" },
    { id: 2, name: "She/Her" },
    { id: 3, name: "They/Them" },
    { id: 4, name: "Other" },
  ],
  sexualities: [
    { id: 1, name: "Straight" },
    { id: 2, name: "Gay" },
    { id: 3, name: "Lesbian" },
    { id: 4, name: "Bisexual" },
    { id: 5, name: "Pansexual" },
    { id: 6, name: "Asexual" },
    { id: 7, name: "Other" },
  ],
  zodiac_signs: [
    { id: 1, name: "Aries" },
    { id: 2, name: "Taurus" },
    { id: 3, name: "Gemini" },
    { id: 4, name: "Cancer" },
    { id: 5, name: "Leo" },
    { id: 6, name: "Virgo" },
    { id: 7, name: "Libra" },
    { id: 8, name: "Scorpio" },
    { id: 9, name: "Sagittarius" },
    { id: 10, name: "Capricorn" },
    { id: 11, name: "Aquarius" },
    { id: 12, name: "Pisces" },
  ],
};
