import { useAuth } from "@/store/auth";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Redirect, Stack } from "expo-router";
import { useEffect, useState } from "react";

const ONBOARDING_KEY = "luptup_onboarding_done";

export default function Layout() {
  const { session } = useAuth();
  const [onboardingDone, setOnboardingDone] = useState<boolean | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(ONBOARDING_KEY).then((val) => {
      setOnboardingDone(!!val);
    });
  }, []);

  if (session) {
    // Onboarding check not loaded yet — wait
    if (onboardingDone === null) return null;

    if (!onboardingDone) {
      return <Redirect href={"/onboarding" as any} />;
    }

    return <Redirect href={"/(app)/(tabs)" as any} />;
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="sign-in" />
      <Stack.Screen name="phone" />
      <Stack.Screen name="otp" />
    </Stack>
  );
}
