import { Stack } from "expo-router";

// No routing logic here — NavigationGuard in root _layout.tsx handles all navigation.
// Screens set their own header options via <Stack.Screen> inside each file.
export default function Layout() {
  return (
    <Stack screenOptions={{ headerShown: false }} />
  );
}
