﻿import { useSignInWithOtp } from "@/api/auth";
import { Fab } from "@/components/fab";
import { StackHeader } from "@/components/stack-header";
import { useTheme } from "@/context/theme";
import { router, Stack, useFocusEffect } from "expo-router";
import { useMemo, useRef, useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  StatusBar,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

export default function Page() {
  // Default to Indian country code +91
  const [digits, setDigits] = useState("");

  const inputRef = useRef<TextInput>(null);
  const { colors, isDark } = useTheme();
  const {
    mutate: signInWithOtp,
    isPending,
    isError,
    error,
    reset,
  } = useSignInWithOtp();

  const handleChange = (text: string) => {
    if (isError) reset();
    // Allow only digits, max 10
    const cleaned = text.replace(/\D/g, "").slice(0, 10);
    setDigits(cleaned);
  };

  // Full phone number: +91 + 10 digits
  const phone = `+91${digits}`;
  // Indian mobile numbers start with 6-9
  const isValid = useMemo(() => /^[6-9]\d{9}$/.test(digits), [digits]);

  const handleSubmit = () => {
    signInWithOtp(phone, {
      onSuccess: () => router.push({ pathname: "/otp", params: { phone } }),
    });
  };

  useFocusEffect(() => {
    inputRef.current?.focus();
  });

  return (
    <>
      <Stack.Screen options={{ headerShown: true, title: "" }} />
    <KeyboardAvoidingView
      style={{
        flex: 1,
        backgroundColor: colors.background,
        padding: 20,
      }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={100}
    >
      <StackHeader />
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      <View style={{ flex: 1, justifyContent: "center", paddingTop: 112 }}>
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "PlayfairDisplay-SemiBold",
              fontSize: 32,
              color: colors.text,
              lineHeight: 42,
            }}
          >
            What's your{"\n"}phone number?
          </Text>
          <View style={{ height: 8 }} />
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 13,
              color: colors.textMuted,
              marginBottom: 32,
            }}
          >
            We'll send a 6-digit code to verify your number
          </Text>

          {/* Phone input row: +91 prefix + digit input */}
          <View
            style={{
              flexDirection: "row",
              alignItems: "flex-end",
              borderBottomWidth: 2,
              borderBottomColor: isValid ? colors.primary : colors.border,
              paddingBottom: 6,
            }}
          >
            {/* Country code pill */}
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                gap: 4,
                backgroundColor: colors.surface,
                borderRadius: 10,
                paddingHorizontal: 10,
                paddingVertical: 8,
                marginRight: 12,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              {/* India flag emoji */}
              <Text style={{ fontSize: 18 }}>🇮🇳</Text>
              <Text
                style={{
                  fontFamily: "Poppins-SemiBold",
                  fontSize: 16,
                  color: colors.text,
                }}
              >
                +91
              </Text>
            </View>

            {/* 10-digit input */}
            <TextInput
              ref={inputRef}
              style={[
                {
                  flex: 1,
                  fontSize: 28,
                  fontFamily: "Poppins-SemiBold",
                  color: colors.text,
                  paddingBottom: 4,
                  letterSpacing: 2,
                },
                Platform.OS === "ios" && { lineHeight: undefined },
              ]}
              selectionColor={colors.primary}
              keyboardType="number-pad"
              textContentType="telephoneNumber"
              autoFocus
              value={digits}
              onChangeText={handleChange}
              maxLength={10}
              placeholder="00000 00000"
              placeholderTextColor={colors.textMuted}
            />
          </View>

          {/* Helper text */}
          <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 8 }}>
            <Text
              style={{
                fontFamily: "Poppins-Light",
                fontSize: 12,
                color: colors.textMuted,
              }}
            >
              Enter 10-digit mobile number
            </Text>
            <Text
              style={{
                fontFamily: "Poppins-Light",
                fontSize: 12,
                color: digits.length === 10 ? colors.primary : colors.textMuted,
              }}
            >
              {digits.length}/10
            </Text>
          </View>

          {isError && (
            <Text
              style={{
                fontFamily: "Poppins-Regular",
                fontSize: 13,
                color: colors.danger,
                marginTop: 12,
                textAlign: "center",
              }}
            >
              {error.message}
            </Text>
          )}
        </View>

        <View style={{ alignItems: "flex-end", paddingBottom: 16 }}>
          <Fab
            disabled={!isValid || isPending}
            onPress={handleSubmit}
            loading={isPending}
          />
        </View>
      </View>
    </KeyboardAvoidingView>
    </>
  );
}
