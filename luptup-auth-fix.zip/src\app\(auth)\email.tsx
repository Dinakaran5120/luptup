import { useSignInWithEmailOtp } from "@/api/auth";
import { Fab } from "@/components/fab";
import { StackHeader } from "@/components/stack-header";
import { useTheme } from "@/context/theme";
import { router, Stack, useFocusEffect } from "expo-router";
import { useMemo, useRef, useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  StatusBar,
  Text,
  TextInput,
  View,
} from "react-native";

export default function Page() {
  const [email, setEmail] = useState("");
  const emailRef = useRef<TextInput>(null);
  const { colors, isDark } = useTheme();
  const {
    mutate: signInWithEmailOtp,
    isPending,
    isError,
    error,
    reset,
  } = useSignInWithEmailOtp();

  const handleEmailChange = (text: string) => {
    if (isError) reset();
    setEmail(text.trim());
  };

  const isValid = useMemo(
    () => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email),
    [email]
  );

  const handleSubmit = () => {
    signInWithEmailOtp(email, {
      onSuccess: () =>
        router.push({ pathname: "/email-otp" as any, params: { email } }),
    });
  };

  useFocusEffect(() => {
    emailRef.current?.focus();
  });

  return (
    <>
      <Stack.Screen options={{ headerShown: true, title: "" }} />
    <KeyboardAvoidingView
      style={{
        flex: 1,
        backgroundColor: colors.background,
        padding: 20,
      }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={100}
    >
      <StackHeader />
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      <View style={{ flex: 1, justifyContent: "center", paddingTop: 112 }}>
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "PlayfairDisplay-SemiBold",
              fontSize: 32,
              color: colors.text,
              lineHeight: 42,
            }}
          >
            What's your{"\n"}email address?
          </Text>
          <View style={{ height: 12 }} />
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 13,
              color: colors.textMuted,
              marginBottom: 24,
            }}
          >
            We'll send a verification code to your email
          </Text>

          <TextInput
            ref={emailRef}
            style={[
              {
                borderBottomWidth: 2,
                borderBottomColor: isValid ? colors.primary : colors.border,
                height: 56,
                fontSize: 20,
                fontFamily: "Poppins-Medium",
                color: colors.text,
                paddingBottom: 8,
              },
              Platform.OS === "ios" && { lineHeight: undefined },
            ]}
            selectionColor={colors.primary}
            keyboardType="email-address"
            textContentType="emailAddress"
            autoCapitalize="none"
            autoCorrect={false}
            autoFocus
            value={email}
            onChangeText={handleEmailChange}
            placeholderTextColor={colors.textMuted}
            placeholder="you@example.com"
          />

          {isError && (
            <Text
              style={{
                fontFamily: "Poppins-Regular",
                fontSize: 13,
                color: colors.danger,
                marginTop: 12,
                textAlign: "center",
              }}
            >
              {error.message}
            </Text>
          )}
        </View>

        <View style={{ alignItems: "flex-end", paddingBottom: 16 }}>
          <Fab
            disabled={!isValid || isPending}
            onPress={handleSubmit}
            loading={isPending}
          />
        </View>
      </View>
    </KeyboardAvoidingView>
    </>
  );
}
