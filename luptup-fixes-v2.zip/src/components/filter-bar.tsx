import { useTheme } from "@/context/theme";
import { Ionicons } from "@expo/vector-icons";
import { Slider } from "@miblanchard/react-native-slider";
import React, { useEffect, useState } from "react";
import {
  Dimensions,
  Modal,
  Pressable,
  ScrollView,
  Switch,
  Text,
  View,
} from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from "react-native-reanimated";

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);
const { width: SW } = Dimensions.get("window");

interface FilterState {
  online: boolean;
  minAge: number;
  maxAge: number;
  distance: number;
  lookingFor: string;
}

type FilterKey = keyof FilterState;

const LOOKING_FOR_OPTIONS = ["Relationship", "Casual", "Friendship", "Not Sure"];

const defaultFilters: FilterState = {
  online: false,
  minAge: 18,
  maxAge: 40,
  distance: 50,
  lookingFor: "Relationship",
};

/* ── Individual pill button ── */
const Pill: React.FC<{
  label: string;
  active: boolean;
  onPress: () => void;
  colors: ReturnType<typeof useTheme>["colors"];
}> = ({ label, active, onPress, colors }) => {
  const scale = useSharedValue(1);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));

  return (
    <AnimatedPressable
      style={[
        {
          paddingHorizontal: 14,
          paddingVertical: 7,
          borderRadius: 20,
          backgroundColor: active ? colors.primary : colors.surface,
          borderWidth: 1.5,
          borderColor: active ? colors.primary : colors.border,
          flexDirection: "row",
          alignItems: "center",
          gap: 5,
          shadowColor: active ? colors.primary : "transparent",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: active ? 0.3 : 0,
          shadowRadius: 5,
          elevation: active ? 3 : 0,
        },
        anim,
      ]}
      onPressIn={() => { scale.value = withSpring(0.93, { damping: 14 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 14 }); }}
      onPress={onPress}
    >
      <Text
        style={{
          fontFamily: "Poppins-Medium",
          fontSize: 13,
          color: active ? "#fff" : colors.textMuted,
        }}
      >
        {label}
      </Text>
      {!active && (
        <Ionicons name="chevron-down" size={11} color={colors.textMuted} />
      )}
    </AnimatedPressable>
  );
};

/* ── Filter bottom sheet ── */
const FilterSheet: React.FC<{
  visible: boolean;
  activeKey: FilterKey | null;
  filters: FilterState;
  onClose: () => void;
  onApply: (patch: Partial<FilterState>) => void;
}> = ({ visible, activeKey, filters, onClose, onApply }) => {
  const { colors } = useTheme();
  const [local, setLocal] = useState<FilterState>(filters);

  // Sync local state whenever the sheet opens
  useEffect(() => {
    if (visible) setLocal(filters);
  }, [visible]);

  const handleApply = () => {
    onApply(local);
    onClose();
  };

  const sliderTrack = {
    minimumTrackTintColor: colors.primary,
    maximumTrackTintColor: colors.border,
    thumbTintColor: colors.primary,
  };

  const renderBody = () => {
    switch (activeKey) {
      case "online":
        return (
          <View style={{ padding: 24, gap: 20 }}>
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: colors.text }}>
              Online Only
            </Text>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                justifyContent: "space-between",
                padding: 16,
                borderRadius: 14,
                backgroundColor: colors.surface,
                borderWidth: 1,
                borderColor: colors.border,
              }}
            >
              <View style={{ gap: 2 }}>
                <Text style={{ fontFamily: "Poppins-Medium", fontSize: 15, color: colors.text }}>
                  Show online users only
                </Text>
                <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>
                  Filter by active status
                </Text>
              </View>
              <Switch
                value={local.online}
                onValueChange={(v) => setLocal({ ...local, online: v })}
                trackColor={{ false: colors.border, true: colors.primary }}
                thumbColor="#fff"
              />
            </View>
          </View>
        );

      case "minAge":
      case "maxAge":
        return (
          <View style={{ padding: 24, gap: 20 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: colors.text }}>
                Age Range
              </Text>
              <View style={{ backgroundColor: colors.surfaceAlt, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20 }}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: colors.primary }}>
                  {local.minAge} – {local.maxAge} yrs
                </Text>
              </View>
            </View>
            <View style={{ paddingHorizontal: 8 }}>
              <Slider
                value={[local.minAge, local.maxAge]}
                minimumValue={18}
                maximumValue={100}
                step={1}
                onValueChange={(vals: number[]) =>
                  setLocal({ ...local, minAge: vals[0], maxAge: vals[1] ?? vals[0] })
                }
                {...sliderTrack}
              />
            </View>
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>18 (min)</Text>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>100 (max)</Text>
            </View>
          </View>
        );

      case "distance":
        return (
          <View style={{ padding: 24, gap: 20 }}>
            <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between" }}>
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: colors.text }}>
                Max Distance
              </Text>
              <View style={{ backgroundColor: colors.surfaceAlt, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20 }}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: colors.primary }}>
                  {local.distance} km
                </Text>
              </View>
            </View>
            <View style={{ paddingHorizontal: 8 }}>
              <Slider
                value={local.distance}
                minimumValue={1}
                maximumValue={200}
                step={1}
                onValueChange={(v: number[]) => setLocal({ ...local, distance: v[0] })}
                {...sliderTrack}
              />
            </View>
            <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>1 km</Text>
              <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>200 km</Text>
            </View>
          </View>
        );

      case "lookingFor":
        return (
          <View style={{ padding: 24, gap: 16 }}>
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: colors.text }}>
              Looking For
            </Text>
            <View style={{ gap: 10 }}>
              {LOOKING_FOR_OPTIONS.map((opt) => {
                const isSelected = local.lookingFor === opt;
                return (
                  <Pressable
                    key={opt}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      justifyContent: "space-between",
                      padding: 16,
                      borderRadius: 14,
                      backgroundColor: isSelected ? colors.surfaceAlt : colors.surface,
                      borderWidth: 1.5,
                      borderColor: isSelected ? colors.primary : colors.border,
                    }}
                    onPress={() => setLocal({ ...local, lookingFor: opt })}
                  >
                    <Text style={{ fontFamily: "Poppins-Medium", fontSize: 15, color: isSelected ? colors.primary : colors.text }}>
                      {opt}
                    </Text>
                    {isSelected && (
                      <Ionicons name="checkmark-circle" size={22} color={colors.primary} />
                    )}
                  </Pressable>
                );
              })}
            </View>
          </View>
        );

      default:
        return null;
    }
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="slide"
      statusBarTranslucent
      onRequestClose={onClose}
    >
      {/* Backdrop — tap to dismiss */}
      <Pressable
        style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)" }}
        onPress={onClose}
      >
        {/* Sheet — stop tap propagation */}
        <Pressable
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            backgroundColor: colors.background,
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            paddingBottom: 44,
            shadowColor: "#000",
            shadowOffset: { width: 0, height: -4 },
            shadowOpacity: 0.15,
            shadowRadius: 20,
            elevation: 20,
          }}
          onPress={() => {}}
        >
          {/* Drag handle */}
          <View style={{ alignItems: "center", paddingTop: 14, paddingBottom: 4 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border }} />
          </View>

          {renderBody()}

          {/* Apply button */}
          <View style={{ paddingHorizontal: 24, marginTop: 8 }}>
            <Pressable
              style={{
                height: 52,
                borderRadius: 26,
                alignItems: "center",
                justifyContent: "center",
                backgroundColor: colors.primary,
                shadowColor: colors.primary,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.35,
                shadowRadius: 10,
                elevation: 6,
              }}
              onPress={handleApply}
            >
              <Text style={{ color: "#fff", fontFamily: "Poppins-SemiBold", fontSize: 16 }}>
                Apply Filter
              </Text>
            </Pressable>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
};

/* ── Main FilterBar ── */
export const FilterBar: React.FC = () => {
  const { colors } = useTheme();
  const [activeKey, setActiveKey] = useState<FilterKey | null>(null);
  const [filters, setFilters] = useState<FilterState>(defaultFilters);

  const isActive = (key: FilterKey) => {
    if (key === "online") return filters.online;
    if (key === "minAge" || key === "maxAge")
      return filters.minAge !== defaultFilters.minAge || filters.maxAge !== defaultFilters.maxAge;
    if (key === "distance") return filters.distance !== defaultFilters.distance;
    if (key === "lookingFor") return filters.lookingFor !== defaultFilters.lookingFor;
    return false;
  };

  const pills: { key: FilterKey; label: string }[] = [
    { key: "online",    label: filters.online ? "🟢 Online" : "Online" },
    { key: "minAge",    label: `${filters.minAge}–${filters.maxAge} yrs` },
    { key: "distance",  label: `${filters.distance} km` },
    { key: "lookingFor", label: filters.lookingFor },
  ];

  return (
    <>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={{
          paddingHorizontal: 16,
          paddingVertical: 8,
          gap: 8,
          flexDirection: "row",
          alignItems: "center",
        }}
      >
        {pills.map((p) => (
          <Pill
            key={p.key}
            label={p.label}
            active={isActive(p.key)}
            onPress={() => setActiveKey(p.key)}
            colors={colors}
          />
        ))}
      </ScrollView>

      <FilterSheet
        visible={activeKey !== null}
        activeKey={activeKey}
        filters={filters}
        onClose={() => setActiveKey(null)}
        onApply={(patch) => setFilters((prev) => ({ ...prev, ...patch }))}
      />
    </>
  );
};
