import { BRAND, useTheme } from "@/context/theme";
import { MOCK_GROUPS, MockGroup, GroupCategory } from "@/lib/mock-data";
import { Ionicons } from "@expo/vector-icons";
import { Image } from "expo-image";
import { useState } from "react";
import {
  Alert,
  Dimensions,
  FlatList,
  Modal,
  Pressable,
  ScrollView,
  StatusBar,
  Text,
  TextInput,
  View,
} from "react-native";
import Animated, { useAnimatedStyle, useSharedValue, withSpring } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const { width: SW } = Dimensions.get("window");
const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

type CatFilter = "all" | GroupCategory;

const CATEGORIES: { key: CatFilter; label: string; emoji: string; color: string }[] = [
  { key: "all",            label: "All",          emoji: "🌐", color: BRAND.primary },
  { key: "adventure",      label: "Adventure",    emoji: "🧗", color: "#10b981" },
  { key: "health_fitness", label: "Fitness",      emoji: "💪", color: "#f59e0b" },
  { key: "18plus",         label: "18+",          emoji: "🔞", color: "#ef4444" },
  { key: "party_club",     label: "Party & Club", emoji: "🎉", color: "#8b5cf6" },
  { key: "events",         label: "Events",       emoji: "📅", color: "#3b82f6" },
];

const CAT_META: Record<GroupCategory, { emoji: string; color: string; label: string }> = {
  adventure:      { emoji: "🧗", color: "#10b981", label: "Adventure" },
  health_fitness: { emoji: "💪", color: "#f59e0b", label: "Fitness" },
  "18plus":       { emoji: "🔞", color: "#ef4444", label: "18+" },
  party_club:     { emoji: "🎉", color: "#8b5cf6", label: "Party & Club" },
  events:         { emoji: "📅", color: "#3b82f6", label: "Events" },
};

// ─── Group Detail Modal ───────────────────────────────────────────────────────
function GroupDetailModal({
  group,
  onClose,
}: {
  group: MockGroup | null;
  onClose: () => void;
}) {
  const { colors } = useTheme();
  const [joined, setJoined] = useState(group?.is_member ?? false);
  const [pending, setPending] = useState(group?.is_pending ?? false);

  if (!group) return null;
  const cat = CAT_META[group.category];
  const btnLabel = joined ? "Leave Group" : pending ? "Request Pending" : group.type === "private" ? "Request to Join" : "Join Group";
  const btnBg = joined ? colors.danger : pending ? "#f59e0b" : BRAND.primary;

  const handleJoin = () => {
    if (joined) {
      setJoined(false);
      return;
    }
    if (group.type === "private") {
      setPending(true);
      Alert.alert("Request Sent", `Your request to join "${group.name}" has been sent to the owner.`);
    } else {
      setJoined(true);
    }
  };

  return (
    <Modal visible={!!group} transparent animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      <Pressable style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)" }} onPress={onClose}>
        <Pressable
          style={{
            position: "absolute",
            bottom: 0,
            left: 0,
            right: 0,
            backgroundColor: colors.background,
            borderTopLeftRadius: 28,
            borderTopRightRadius: 28,
            maxHeight: "90%",
            paddingBottom: 40,
          }}
          onPress={() => {}}
        >
          {/* Handle */}
          <View style={{ alignItems: "center", paddingTop: 12, marginBottom: 4 }}>
            <View style={{ width: 40, height: 4, borderRadius: 2, backgroundColor: colors.border }} />
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            {/* Cover image */}
            <View style={{ marginHorizontal: 20, borderRadius: 20, overflow: "hidden", height: 180 }}>
              <Image source={group.cover_url} style={{ width: "100%", height: 180 }} contentFit="cover" />
              {/* Category badge */}
              <View style={{ position: "absolute", top: 12, left: 12, flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: cat.color + "dd", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 }}>
                <Text style={{ fontSize: 12 }}>{cat.emoji}</Text>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 11, color: "#fff" }}>{cat.label}</Text>
              </View>
              {/* Type badge */}
              <View style={{ position: "absolute", top: 12, right: 12, flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: group.type === "private" ? "rgba(0,0,0,0.7)" : "rgba(16,185,129,0.85)", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 }}>
                <Ionicons name={group.type === "private" ? "lock-closed" : "earth"} size={11} color="#fff" />
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 11, color: "#fff" }}>
                  {group.type === "private" ? "Private" : "Open"}
                </Text>
              </View>
            </View>

            {/* Group info */}
            <View style={{ paddingHorizontal: 20, paddingTop: 18, gap: 10 }}>
              <Text style={{ fontFamily: "PlayfairDisplay-Bold", fontSize: 24, color: colors.text }}>
                {group.name}
              </Text>
              <Text style={{ fontFamily: "Poppins-Regular", fontSize: 14, color: colors.textMuted, lineHeight: 22 }}>
                {group.description}
              </Text>

              {/* Stats row */}
              <View style={{ flexDirection: "row", gap: 20, marginTop: 4 }}>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
                  <Ionicons name="people-outline" size={16} color={colors.primary} />
                  <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: colors.text }}>
                    {group.members_count.toLocaleString()} members
                  </Text>
                </View>
                <View style={{ flexDirection: "row", alignItems: "center", gap: 5 }}>
                  <Ionicons name="person-outline" size={16} color={colors.textMuted} />
                  <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: colors.textMuted }}>
                    by {group.owner}
                  </Text>
                </View>
              </View>

              {/* Join button */}
              <Pressable
                onPress={handleJoin}
                style={{
                  marginTop: 8,
                  height: 50,
                  borderRadius: 25,
                  backgroundColor: btnBg,
                  alignItems: "center",
                  justifyContent: "center",
                  shadowColor: btnBg,
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.3,
                  shadowRadius: 8,
                  elevation: 5,
                }}
              >
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: "#fff" }}>
                  {btnLabel}
                </Text>
              </Pressable>

              {/* Posts placeholder */}
              <View style={{ marginTop: 20 }}>
                <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: colors.text, marginBottom: 12 }}>
                  Posts
                </Text>
                <View style={{ alignItems: "center", paddingVertical: 32, borderRadius: 16, backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, gap: 8 }}>
                  <Text style={{ fontSize: 36 }}>📝</Text>
                  <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 15, color: colors.text }}>No posts yet</Text>
                  <Text style={{ fontFamily: "Poppins-Light", fontSize: 13, color: colors.textMuted }}>
                    {joined ? "Be the first to post!" : "Join to see and create posts."}
                  </Text>
                </View>
              </View>
            </View>

            <View style={{ height: 24 }} />
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

// ─── Create Group Modal ───────────────────────────────────────────────────────
function CreateGroupModal({
  visible,
  onClose,
  onCreate,
}: {
  visible: boolean;
  onClose: () => void;
  onCreate: (group: MockGroup) => void;
}) {
  const { colors } = useTheme();
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [type, setType] = useState<"open" | "private">("open");
  const [category, setCategory] = useState<GroupCategory>("adventure");

  const handleCreate = () => {
    if (!name.trim()) {
      Alert.alert("Name required", "Please enter a group name.");
      return;
    }
    const cat = CAT_META[category];
    const newGroup: MockGroup = {
      id: `created_${Date.now()}`,
      name: name.trim(),
      description: desc.trim() || "No description provided.",
      cover_url: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=400",
      category,
      type,
      members_count: 1,
      is_member: true,
      is_pending: false,
      owner: "You",
    };
    onCreate(newGroup);
    setName("");
    setDesc("");
    setType("open");
    setCategory("adventure");
    Alert.alert("Group Created! 🎉", `"${newGroup.name}" is now live!`, [
      { text: "OK", onPress: onClose },
    ]);
  };

  const CARD_BTN_W = SW - 48 - 2; // 24px padding each side + 2 for border

  return (
    <Modal visible={visible} transparent animationType="slide" statusBarTranslucent onRequestClose={onClose}>
      <Pressable
        style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}
        onPress={onClose}
      >
        <Pressable
          style={{ backgroundColor: colors.background, borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingBottom: 40, maxHeight: "92%" }}
          onPress={() => {}}
        >
          {/* Handle */}
          <View style={{ width: 36, height: 4, borderRadius: 2, backgroundColor: colors.border, alignSelf: "center", marginTop: 12, marginBottom: 4 }} />

          <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 24, paddingVertical: 12 }}>
            <Text style={{ fontFamily: "PlayfairDisplay-Bold", fontSize: 22, color: colors.text }}>
              Create Group
            </Text>
            <Pressable
              onPress={onClose}
              style={{ width: 34, height: 34, borderRadius: 17, backgroundColor: colors.surface, alignItems: "center", justifyContent: "center" }}
            >
              <Ionicons name="close" size={20} color={colors.icon} />
            </Pressable>
          </View>

          <ScrollView contentContainerStyle={{ paddingHorizontal: 24, paddingBottom: 16, gap: 20 }} showsVerticalScrollIndicator={false}>
            {/* Name */}
            <View>
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: colors.text, marginBottom: 8 }}>
                Group Name *
              </Text>
              <TextInput
                style={{ backgroundColor: colors.surface, borderWidth: 1.5, borderColor: colors.border, borderRadius: 14, padding: 14, fontFamily: "Poppins-Regular", fontSize: 15, color: colors.text }}
                placeholder="e.g. NYC Hikers"
                placeholderTextColor={colors.textMuted}
                selectionColor={BRAND.primary}
                value={name}
                onChangeText={setName}
              />
            </View>

            {/* Description */}
            <View>
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: colors.text, marginBottom: 8 }}>
                Description
              </Text>
              <TextInput
                style={{ backgroundColor: colors.surface, borderWidth: 1.5, borderColor: colors.border, borderRadius: 14, padding: 14, fontFamily: "Poppins-Regular", fontSize: 15, color: colors.text, height: 90, textAlignVertical: "top" }}
                placeholder="What's this group about?"
                placeholderTextColor={colors.textMuted}
                selectionColor={BRAND.primary}
                multiline
                value={desc}
                onChangeText={setDesc}
              />
            </View>

            {/* Category */}
            <View>
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: colors.text, marginBottom: 10 }}>
                Category
              </Text>
              <View style={{ flexDirection: "row", flexWrap: "wrap", gap: 8 }}>
                {(CATEGORIES.filter((c) => c.key !== "all") as { key: GroupCategory; label: string; emoji: string; color: string }[]).map((cat) => (
                  <Pressable
                    key={cat.key}
                    onPress={() => setCategory(cat.key)}
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 6,
                      paddingHorizontal: 12,
                      paddingVertical: 8,
                      borderRadius: 16,
                      backgroundColor: category === cat.key ? cat.color : colors.surface,
                      borderWidth: 1.5,
                      borderColor: category === cat.key ? cat.color : colors.border,
                    }}
                  >
                    <Text style={{ fontSize: 14 }}>{cat.emoji}</Text>
                    <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 12, color: category === cat.key ? "#fff" : colors.text }}>
                      {cat.label}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>

            {/* Type */}
            <View>
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 14, color: colors.text, marginBottom: 10 }}>
                Group Type
              </Text>
              <View style={{ flexDirection: "row", gap: 12 }}>
                {(["open", "private"] as const).map((t) => (
                  <Pressable
                    key={t}
                    onPress={() => setType(t)}
                    style={{
                      flex: 1,
                      alignItems: "center",
                      gap: 6,
                      paddingVertical: 16,
                      borderRadius: 16,
                      backgroundColor: type === t ? BRAND.primary : colors.surface,
                      borderWidth: 1.5,
                      borderColor: type === t ? BRAND.primary : colors.border,
                    }}
                  >
                    <Ionicons name={t === "open" ? "earth-outline" : "lock-closed-outline"} size={22} color={type === t ? "#fff" : colors.icon} />
                    <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: type === t ? "#fff" : colors.text }}>
                      {t === "open" ? "Open" : "Private"}
                    </Text>
                    <Text style={{ fontFamily: "Poppins-Light", fontSize: 11, color: type === t ? "rgba(255,255,255,0.8)" : colors.textMuted, textAlign: "center", paddingHorizontal: 8 }}>
                      {t === "open" ? "Anyone can join" : "Requires approval"}
                    </Text>
                  </Pressable>
                ))}
              </View>
            </View>

            {/* Create button — plain Pressable (no SVG width issue) */}
            <Pressable
              onPress={handleCreate}
              style={{
                height: 54,
                borderRadius: 16,
                backgroundColor: BRAND.primary,
                alignItems: "center",
                justifyContent: "center",
                marginTop: 4,
                shadowColor: BRAND.primary,
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.35,
                shadowRadius: 10,
                elevation: 6,
              }}
            >
              <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: "#fff" }}>
                Create Group
              </Text>
            </Pressable>
          </ScrollView>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

// ─── Group card ───────────────────────────────────────────────────────────────
function GroupCard({ group, onPress }: { group: MockGroup; onPress: () => void }) {
  const { colors } = useTheme();
  const [joined, setJoined] = useState(group.is_member);
  const [pending, setPending] = useState(group.is_pending);
  const scale = useSharedValue(1);
  const anim = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  const cat = CAT_META[group.category];

  const handleJoinBtn = (e: any) => {
    e.stopPropagation?.();
    if (joined) { setJoined(false); return; }
    if (group.type === "private") {
      setPending(true);
      Alert.alert("Request Sent", `Your request to join "${group.name}" has been sent to the owner.`);
    } else {
      setJoined(true);
    }
  };

  const btnLabel = joined ? "Joined" : pending ? "Pending" : group.type === "private" ? "Request" : "Join";
  const btnBg = joined ? colors.surface : pending ? "#f59e0b" : BRAND.primary;
  const btnColor = joined ? colors.text : "#fff";

  return (
    <AnimatedPressable
      style={[{ backgroundColor: colors.surface, borderRadius: 20, overflow: "hidden", marginBottom: 14, borderWidth: 1, borderColor: colors.border }, anim]}
      onPressIn={() => { scale.value = withSpring(0.97, { damping: 14 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 14 }); }}
      onPress={onPress}
    >
      {/* Cover */}
      <View style={{ height: 130 }}>
        <Image source={group.cover_url} style={{ width: "100%", height: 130 }} contentFit="cover" />
        {/* Type badge */}
        <View style={{ position: "absolute", top: 10, right: 10, flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: group.type === "private" ? "rgba(0,0,0,0.65)" : "rgba(16,185,129,0.85)", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 }}>
          <Ionicons name={group.type === "private" ? "lock-closed" : "earth"} size={11} color="#fff" />
          <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 10, color: "#fff" }}>
            {group.type === "private" ? "Private" : "Open"}
          </Text>
        </View>
        {/* Category badge */}
        <View style={{ position: "absolute", top: 10, left: 10, flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: cat.color + "cc", paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10 }}>
          <Text style={{ fontSize: 11 }}>{cat.emoji}</Text>
          <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 10, color: "#fff" }}>{cat.label}</Text>
        </View>
      </View>

      {/* Info */}
      <View style={{ padding: 16 }}>
        <View style={{ flexDirection: "row", alignItems: "flex-start", justifyContent: "space-between", gap: 12 }}>
          <View style={{ flex: 1 }}>
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 16, color: colors.text }} numberOfLines={1}>
              {group.name}
            </Text>
            <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted, marginTop: 3 }} numberOfLines={2}>
              {group.description}
            </Text>
          </View>
          <Pressable
            onPress={handleJoinBtn}
            style={{ paddingHorizontal: 16, paddingVertical: 9, borderRadius: 14, backgroundColor: btnBg, borderWidth: joined ? 1 : 0, borderColor: colors.border, minWidth: 72, alignItems: "center" }}
          >
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: btnColor }}>{btnLabel}</Text>
          </Pressable>
        </View>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 4, marginTop: 10 }}>
          <Ionicons name="people-outline" size={14} color={colors.textMuted} />
          <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>
            {group.members_count.toLocaleString()} members
          </Text>
          <Text style={{ color: colors.border, marginHorizontal: 4 }}>•</Text>
          <Text style={{ fontFamily: "Poppins-Light", fontSize: 12, color: colors.textMuted }}>by {group.owner}</Text>
        </View>
      </View>
    </AnimatedPressable>
  );
}

// ─── Filter pill ──────────────────────────────────────────────────────────────
function CatPill({ cat, active, onPress }: { cat: (typeof CATEGORIES)[0]; active: boolean; onPress: () => void }) {
  const { colors } = useTheme();
  const scale = useSharedValue(1);
  const aStyle = useAnimatedStyle(() => ({ transform: [{ scale: scale.value }] }));
  return (
    <AnimatedPressable
      style={[{
        flexDirection: "row",
        alignItems: "center",
        gap: 6,
        paddingHorizontal: 14,
        paddingVertical: 8,
        borderRadius: 20,
        backgroundColor: active ? cat.color : colors.surface,
        borderWidth: active ? 0 : 1,
        borderColor: colors.border,
        marginRight: 8,
      }, aStyle]}
      onPressIn={() => { scale.value = withSpring(0.92, { damping: 12 }); }}
      onPressOut={() => { scale.value = withSpring(1, { damping: 12 }); }}
      onPress={onPress}
    >
      <Text style={{ fontSize: 14 }}>{cat.emoji}</Text>
      <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 13, color: active ? "#fff" : colors.text }}>
        {cat.label}
      </Text>
    </AnimatedPressable>
  );
}

// ─── Main ─────────────────────────────────────────────────────────────────────
export default function CommunityPage() {
  const { colors, isDark } = useTheme();
  const { top } = useSafeAreaInsets();
  const [activeCategory, setActiveCategory] = useState<CatFilter>("all");
  const [createVisible, setCreateVisible] = useState(false);
  const [groups, setGroups] = useState<MockGroup[]>(MOCK_GROUPS);
  const [selectedGroup, setSelectedGroup] = useState<MockGroup | null>(null);

  const filtered = activeCategory === "all" ? groups : groups.filter((g) => g.category === activeCategory);

  const handleGroupCreated = (newGroup: MockGroup) => {
    setGroups((prev) => [newGroup, ...prev]);
  };

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />

      {/* Header */}
      <View style={{ paddingTop: top, backgroundColor: colors.background, borderBottomWidth: 1, borderBottomColor: colors.border }}>
        <View style={{ flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingVertical: 12 }}>
          <Text style={{ fontFamily: "PlayfairDisplay-Bold", fontSize: 26, color: colors.text }}>Community</Text>
          <Pressable
            onPress={() => setCreateVisible(true)}
            style={{
              width: 42,
              height: 42,
              borderRadius: 21,
              backgroundColor: BRAND.primary,
              alignItems: "center",
              justifyContent: "center",
              shadowColor: BRAND.primary,
              shadowOffset: { width: 0, height: 3 },
              shadowOpacity: 0.35,
              shadowRadius: 6,
              elevation: 5,
            }}
          >
            <Ionicons name="add" size={24} color="#fff" />
          </Pressable>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 12 }}>
          {CATEGORIES.map((c) => (
            <CatPill key={c.key} cat={c} active={activeCategory === c.key} onPress={() => setActiveCategory(c.key)} />
          ))}
        </ScrollView>
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <GroupCard group={item} onPress={() => setSelectedGroup(item)} />
        )}
        contentContainerStyle={{ padding: 16, paddingBottom: 100 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingTop: 60, gap: 12 }}>
            <Text style={{ fontSize: 48 }}>👥</Text>
            <Text style={{ fontFamily: "Poppins-SemiBold", fontSize: 18, color: colors.text }}>No groups yet</Text>
            <Text style={{ fontFamily: "Poppins-Light", fontSize: 14, color: colors.textMuted, textAlign: "center" }}>
              Be the first to create a group in this category!
            </Text>
          </View>
        }
      />

      <CreateGroupModal
        visible={createVisible}
        onClose={() => setCreateVisible(false)}
        onCreate={handleGroupCreated}
      />

      <GroupDetailModal
        group={selectedGroup}
        onClose={() => setSelectedGroup(null)}
      />
    </View>
  );
}
