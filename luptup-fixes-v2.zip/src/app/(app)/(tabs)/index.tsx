import {
  useLikeProfile,
  useProfiles,
  useReviewProfiles,
  useSkipProfile,
} from "@/api/profiles";
import { ActionButtons } from "@/components/action-buttons";
import { Empty } from "@/components/empty";
import { FilterBar } from "@/components/filter-bar";
import { Loader } from "@/components/loader";
import { PremiumCard } from "@/components/premium-card";
import { TopNav } from "@/components/top-nav";
import { useTheme } from "@/context/theme";
import { useRefreshOnFocus } from "@/hooks/refetch";
import { transformPublicProfile } from "@/utils/profile";
import { useQueryClient } from "@tanstack/react-query";
import { router } from "expo-router";
import { useState } from "react";
import { Alert, View } from "react-native";

export default function Page() {
  const { data, isFetching, error, refetch } = useProfiles();
  useRefreshOnFocus(refetch);
  const { colors } = useTheme();

  const [currentIndex, setCurrentIndex] = useState(0);
  const { mutate: skip, isPending: skipPending } = useSkipProfile();
  const { mutate: review, isPending: reviewPending } = useReviewProfiles();
  const { mutate: like, isPending: likePending } = useLikeProfile();
  const queryClient = useQueryClient();

  const hasProfiles = data && data.length > 0;
  const profile = hasProfiles ? transformPublicProfile(data[currentIndex]) : null;
  const rawProfile = hasProfiles ? data[currentIndex] : null;

  const advance = () => {
    if (hasProfiles && currentIndex < data.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else if (hasProfiles) {
      queryClient.invalidateQueries({ queryKey: ["profiles"] });
      setCurrentIndex(0);
    }
  };

  const handleSkip = () => {
    if (!profile) return;
    skip(profile.id, {
      onSuccess: advance,
      onError: () =>
        Alert.alert("Error", "Something went wrong, please try again later"),
    });
  };

  const handleReview = () => {
    review(undefined, {
      onSuccess: () =>
        queryClient.invalidateQueries({ queryKey: ["profiles"] }),
      onError: () =>
        Alert.alert("Error", "Something went wrong, please try again later"),
    });
  };

  const handleLike = () => {
    if (!profile || !rawProfile?.photos?.[0]) return;
    like(
      { profile: profile.id, photo: rawProfile.photos[0].id },
      {
        onSuccess: advance,
        onError: () =>
          Alert.alert("Error", "Something went wrong, please try again later"),
      }
    );
  };

  const isLoading = isFetching || skipPending || reviewPending || likePending;

  if (isLoading) return <Loader />;

  if (error) {
    return (
      <Empty
        title="Something went wrong"
        subTitle="We ran into a problem loading new people, sorry about that!"
        onPrimaryPress={refetch}
        primaryText="Try again"
      />
    );
  }

  if (!hasProfiles) {
    return (
      <Empty
        title="You've seen everyone"
        subTitle="Try changing your filters or check back later!"
        primaryText="Change filters"
        secondaryText="Review skipped"
        onPrimaryPress={() => router.push("/preferences")}
        onSecondaryPress={handleReview}
      />
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <TopNav />
      <FilterBar />

      {/* Card area — centered in the space between FilterBar and ActionButtons */}
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          paddingHorizontal: 16,
          overflow: "hidden",
        }}
      >
        {profile && (
          <PremiumCard
            profile={profile}
            age={rawProfile?.age}
            neighborhood={rawProfile?.neighborhood ?? undefined}
            isOnline={
              /* mock: alternate online status per index */
              currentIndex % 3 !== 0
            }
            isPrivate={false}
            onSkip={handleSkip}
            onLike={handleLike}
          />
        )}
      </View>

      {/* Action row */}
      <ActionButtons
        onSkip={handleSkip}
        onLike={handleLike}
        onMessage={() => router.push("/matches")}
        disabled={isLoading}
      />
    </View>
  );
}
