import { EditProvider } from "@/store/edit";
import { Stack } from "expo-router";

// No routing logic here — NavigationGuard in root _layout.tsx handles all navigation.
export default function Layout() {
  return (
    <EditProvider>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)"      options={{ animation: "none" }} />
        <Stack.Screen name="settings"    options={{ animation: "slide_from_bottom" }} />
        <Stack.Screen name="profile"     options={{ animation: "slide_from_bottom" }} />
        <Stack.Screen name="write-answer" options={{ animation: "slide_from_bottom" }} />
        <Stack.Screen name="prompts"     options={{ animation: "slide_from_bottom" }} />
        <Stack.Screen name="preferences" options={{ animation: "slide_from_bottom" }} />
        <Stack.Screen name="user"        options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="notifications" options={{ animation: "slide_from_right" }} />
        <Stack.Screen name="premium"     options={{ animation: "slide_from_bottom" }} />
      </Stack>
    </EditProvider>
  );
}
