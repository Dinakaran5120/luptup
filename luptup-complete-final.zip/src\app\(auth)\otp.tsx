import { useVerifyOtp } from "@/api/auth";
import { Fab } from "@/components/fab";
import { StackHeader } from "@/components/stack-header";
import { useTheme } from "@/context/theme";
import { useLocalSearchParams } from "expo-router";
import { useMemo, useState } from "react";
import {
  KeyboardAvoidingView,
  Platform,
  StatusBar,
  Text,
  TextInput,
  View,
} from "react-native";

export default function Page() {
  const [otp, setOtp] = useState("");
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const { colors, isDark } = useTheme();
  const {
    mutate: verifyOtp,
    isPending,
    isError,
    error,
    reset,
  } = useVerifyOtp();

  const handleOtpChange = (text: string) => {
    if (isError) reset();
    setOtp(text);
  };

  const isValid = useMemo(() => otp.length === 6, [otp]);

  const handleSubmit = () => {
    // NavigationGuard in root _layout.tsx detects the new session
    // and routes to /onboarding or /(app)/(tabs) automatically.
    verifyOtp({ phone, token: otp });
  };

  return (
    <KeyboardAvoidingView
      style={{
        flex: 1,
        backgroundColor: colors.background,
        padding: 20,
      }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={100}
    >
      <StackHeader />
      <StatusBar barStyle={isDark ? "light-content" : "dark-content"} />
      <View style={{ flex: 1, justifyContent: "center", paddingTop: 112 }}>
        <View style={{ flex: 1 }}>
          <Text
            style={{
              fontFamily: "PlayfairDisplay-SemiBold",
              fontSize: 32,
              color: colors.text,
              lineHeight: 42,
            }}
          >
            Enter your verification code
          </Text>
          <View style={{ height: 12 }} />
          <Text
            style={{
              fontFamily: "Poppins-Light",
              fontSize: 13,
              color: colors.textMuted,
            }}
          >
            Sent to {phone}
          </Text>
          <View style={{ height: 48 }} />

          {/* OTP boxes */}
          <View style={{ flexDirection: "row", gap: 10, height: 64 }}>
            {Array.from({ length: 6 }).map((_, index) => (
              <View
                key={index}
                style={{
                  flex: 1,
                  borderBottomWidth: 2,
                  borderBottomColor:
                    otp[index] !== undefined ? colors.primary : colors.border,
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Text
                  style={{
                    fontFamily: "Poppins-SemiBold",
                    fontSize: 32,
                    color: colors.text,
                  }}
                >
                  {otp[index] ?? ""}
                </Text>
              </View>
            ))}
          </View>

          {/* Hidden input */}
          <TextInput
            style={[
              { position: "absolute", height: 1, width: 1, opacity: 0 },
              Platform.OS === "ios" && { lineHeight: undefined },
            ]}
            selectionColor={colors.primary}
            keyboardType="numeric"
            textContentType="oneTimeCode"
            autoFocus
            value={otp}
            onChangeText={handleOtpChange}
            maxLength={6}
          />

          {isError && (
            <Text
              style={{
                fontFamily: "Poppins-Regular",
                fontSize: 13,
                color: colors.danger,
                marginTop: 16,
                textAlign: "center",
              }}
            >
              {error.message}
            </Text>
          )}
        </View>
        <View style={{ alignItems: "flex-end", paddingBottom: 16 }}>
          <Fab
            disabled={!isValid || isPending}
            onPress={handleSubmit}
            loading={isPending}
          />
        </View>
      </View>
    </KeyboardAvoidingView>
  );
}
