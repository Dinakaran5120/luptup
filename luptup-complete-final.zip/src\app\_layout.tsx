import { fonts } from "@/constants/fonts";
import { ThemeProvider } from "@/context/theme";
import { AuthProvider, useAuth } from "@/store/auth";
import { AppStateProvider, useAppState } from "@/store/app-state";
import { Ionicons } from "@expo/vector-icons";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Checkbox from "expo-checkbox";
import { useFonts } from "expo-font";
import { Image } from "expo-image";
import { SplashScreen, Stack, useRouter, useSegments } from "expo-router";
import { VideoView } from "expo-video";
import LottieView from "lottie-react-native";
import { cssInterop } from "nativewind";
import { useEffect, useRef } from "react";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import MapView from "react-native-maps";
import "../../global.css";

cssInterop(VideoView, { className: { target: "style" } });
cssInterop(Ionicons, { className: { target: "style" } });
cssInterop(Image, { className: { target: "style" } });
cssInterop(MapView, { className: { target: "style" } });
cssInterop(Checkbox, { className: { target: "style" } });
cssInterop(LottieView, { className: { target: "style" } });

SplashScreen.preventAutoHideAsync();

const queryClient = new QueryClient();

// ─── Navigation Guard ─────────────────────────────────────────────────────────
// Single source of routing truth. Lives at root so it can react immediately
// to session changes AND onboarding completion (via shared AppState context).
function NavigationGuard() {
  const { session, isLoading: authLoading } = useAuth();
  const { onboardingDone } = useAppState();
  const segments = useSegments();
  const router = useRouter();
  const lastNav = useRef<string | null>(null);

  useEffect(() => {
    // Wait until both auth and onboarding state are resolved
    if (authLoading || onboardingDone === null) return;

    const root = (segments[0] as string) ?? "";
    const inAuth       = root === "(auth)";
    const inOnboarding = root === "onboarding";
    const inApp        = root === "(app)";

    let target: string | null = null;

    if (!session) {
      // ① No session → sign-in
      if (!inAuth) target = "/sign-in";
    } else if (!onboardingDone) {
      // ② Signed in but first time → onboarding
      if (!inOnboarding) target = "/onboarding";
    } else {
      // ③ Fully set up → main app
      if (!inApp) target = "/(app)/(tabs)";
    }

    if (target && target !== lastNav.current) {
      lastNav.current = target;
      router.replace(target as any);
    }
  }, [session, authLoading, onboardingDone, segments]);

  return null;
}

// ─── Root Layout ──────────────────────────────────────────────────────────────
export default function Layout() {
  const [loaded, error] = useFonts(fonts);

  useEffect(() => {
    if (loaded || error) {
      SplashScreen.hideAsync();
    }
  }, [loaded, error]);

  if (!loaded && !error) {
    return null;
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <ThemeProvider>
            <AppStateProvider>
              <Stack screenOptions={{ headerShown: false }}>
                <Stack.Screen name="(app)"        options={{ animation: "none" }} />
                <Stack.Screen name="(auth)"       options={{ animation: "none" }} />
                <Stack.Screen name="onboarding"   options={{ animation: "fade", headerShown: false }} />
              </Stack>
              {/* Single navigation controller — no routing logic elsewhere */}
              <NavigationGuard />
            </AppStateProvider>
          </ThemeProvider>
        </AuthProvider>
      </QueryClientProvider>
    </GestureHandlerRootView>
  );
}
