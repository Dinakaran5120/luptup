/**
 * Global app state — tracks onboarding completion.
 * Single source of truth, shared between NavigationGuard and onboarding screens.
 */
import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

export const ONBOARDING_KEY = "luptup_onboarding_done";

interface AppStateContextType {
  onboardingDone: boolean | null; // null = still loading from AsyncStorage
  markOnboardingDone: () => Promise<void>;
}

const AppStateContext = createContext<AppStateContextType>({
  onboardingDone: null,
  markOnboardingDone: async () => {},
});

export const AppStateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [onboardingDone, setOnboardingDone] = useState<boolean | null>(null);

  useEffect(() => {
    AsyncStorage.getItem(ONBOARDING_KEY).then((val) => {
      setOnboardingDone(!!val);
    });
  }, []);

  const markOnboardingDone = async () => {
    await AsyncStorage.setItem(ONBOARDING_KEY, "true");
    setOnboardingDone(true); // immediate state update — NavigationGuard reacts instantly
  };

  return (
    <AppStateContext.Provider value={{ onboardingDone, markOnboardingDone }}>
      {children}
    </AppStateContext.Provider>
  );
};

export const useAppState = () => useContext(AppStateContext);
