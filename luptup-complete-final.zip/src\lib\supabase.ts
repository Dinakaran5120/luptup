/**
 * MOCK SUPABASE — no real backend, no env vars needed.
 * Drop-in replacement for @supabase/supabase-js.
 */

import AsyncStorage from "@react-native-async-storage/async-storage";
import { MOCK_LIKES, MOCK_MY_PROFILE, MOCK_OPTIONS, MOCK_PROFILES } from "@/lib/mock-data";

// ─── Mock session / user ───────────────────────────────────────────────────

const MOCK_USER = {
  id: "mock-user-id-001",
  phone: "+10000000000",
  email: null,
  role: "authenticated",
  aud: "authenticated",
  created_at: new Date().toISOString(),
};

const buildSession = (phone: string) => ({
  access_token: "mock-access-token",
  refresh_token: "mock-refresh-token",
  expires_in: 3600,
  token_type: "bearer",
  user: { ...MOCK_USER, phone },
});

const SESSION_KEY = "mock_supabase_session";

// ─── Auth listeners ────────────────────────────────────────────────────────

type AuthChangeCallback = (event: string, session: any) => void;
const authListeners: AuthChangeCallback[] = [];

const notifyListeners = (event: string, session: any) => {
  authListeners.forEach((cb) => cb(event, session));
};

// ─── Auth module ───────────────────────────────────────────────────────────

const auth = {
  getSession: async () => {
    try {
      const raw = await AsyncStorage.getItem(SESSION_KEY);
      if (raw) return { data: { session: JSON.parse(raw) }, error: null };
    } catch {}
    // No session — user must sign in through the auth flow
    return { data: { session: null }, error: null };
  },

  signInWithOtp: async (_params: { phone: string }) => {
    await new Promise((r) => setTimeout(r, 1000));
    return { error: null };
  },

  verifyOtp: async ({ phone, token }: { phone: string; token: string; type: string }) => {
    await new Promise((r) => setTimeout(r, 1000));
    if (token.length !== 6 || !/^\d{6}$/.test(token)) {
      return { error: { code: "otp_expired", message: "Your code is either invalid or expired." } };
    }
    const session = buildSession(phone);
    await AsyncStorage.setItem(SESSION_KEY, JSON.stringify(session));
    notifyListeners("SIGNED_IN", session);
    return { error: null };
  },

  signOut: async () => {
    await AsyncStorage.removeItem(SESSION_KEY);
    notifyListeners("SIGNED_OUT", null);
    return { error: null };
  },

  onAuthStateChange: (callback: AuthChangeCallback) => {
    authListeners.push(callback);
    const subscription = {
      unsubscribe: () => {
        const idx = authListeners.indexOf(callback);
        if (idx > -1) authListeners.splice(idx, 1);
      },
    };
    return { data: { subscription }, error: null };
  },
};

// ─── Storage module ────────────────────────────────────────────────────────

const storage = {
  from: (_bucket: string) => ({
    upload: async (_path: string, _data: any, _opts?: any) => ({ error: null }),
    getPublicUrl: (path: string) => ({
      data: {
        publicUrl: `https://picsum.photos/seed/${encodeURIComponent(path)}/400/600`,
      },
    }),
  }),
};

// ─── RPC handlers ──────────────────────────────────────────────────────────

const rpcHandlers: Record<string, (params?: any) => any> = {
  get_profile:                  () => MOCK_MY_PROFILE,
  update_profile:               () => null,
  update_age_range:             () => null,
  update_distance:              () => null,
  update_ethnicity_preferences: () => null,
  update_gender_preferences:    () => null,
  update_location:              () => null,
  get_profiles:                 () => MOCK_PROFILES,
  skip_profile:                 () => null,
  like_profile:                 () => null,
  review_profiles:              () => null,
  get_likes:                    () => MOCK_LIKES,
  remove_like:                  () => null,
  match:                        () => null,
  unmatch:                      () => null,
};

// ─── from() table handlers ─────────────────────────────────────────────────

const fromHandlers: Record<string, any[]> = {
  prompts:      MOCK_OPTIONS.prompts,
  children:     MOCK_OPTIONS.children,
  covid_vaccine: MOCK_OPTIONS.covid_vaccine,
  ethnicities:  MOCK_OPTIONS.ethnicities,
  family_plans: MOCK_OPTIONS.family_plans,
  genders:      MOCK_OPTIONS.genders,
  pets:         MOCK_OPTIONS.pets,
  pronouns:     MOCK_OPTIONS.pronouns,
  sexualities:  MOCK_OPTIONS.sexualities,
  zodiac_signs: MOCK_OPTIONS.zodiac_signs,
};

// ─── Chainable query builder ───────────────────────────────────────────────

class QueryBuilder {
  private _data: any;

  constructor(data: any) {
    this._data = data;
  }

  returns<T>() {
    return this as unknown as QueryBuilder;
  }

  single() {
    return { data: this._data, error: null };
  }

  select(_cols?: string) {
    return { data: this._data, error: null };
  }

  // Make `await supabase.rpc(...)` work without calling .single()
  then(resolve: (v: { data: any; error: null }) => void, _reject?: any) {
    resolve({ data: this._data, error: null });
  }
}

// ─── Exported mock client ──────────────────────────────────────────────────

export const supabase = {
  auth,
  storage,

  rpc: (name: string, params?: any) => {
    const handler = rpcHandlers[name];
    const data = handler ? handler(params) : null;
    return new QueryBuilder(data);
  },

  from: (table: string) => {
    const data = fromHandlers[table] ?? [];
    return new QueryBuilder(data);
  },
} as any;
