import { Stack } from "expo-router";

// No routing logic here — NavigationGuard in root _layout.tsx handles all navigation.
export default function Layout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="sign-in"   options={{ headerShown: false }} />
      <Stack.Screen name="phone"     options={{ headerShown: true,  title: "" }} />
      <Stack.Screen name="otp"       options={{ headerShown: true,  title: "" }} />
      <Stack.Screen name="email"     options={{ headerShown: true,  title: "" }} />
      <Stack.Screen name="email-otp" options={{ headerShown: true,  title: "" }} />
    </Stack>
  );
}
